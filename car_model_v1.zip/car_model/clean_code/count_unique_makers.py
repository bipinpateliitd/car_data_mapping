import json

# Load the improved clean makers file
try:
    with open('improved_clean_makers.json', 'r') as f:
        clean_makers = json.load(f)
except Exception as e:
    print(f"Error loading improved_clean_makers.json: {e}")
    exit(1)

# Count unique values
unique_makers = set(clean_makers)

# Display results
print(f"Total entries in improved_clean_makers.json: {len(clean_makers)}")
print(f"Number of unique manufacturer names: {len(unique_makers)}")
print(f"Reduction percentage: {(1 - len(unique_makers)/len(clean_makers))*100:.1f}%")

# Display the top 20 most common manufacturers
maker_counts = {}
for maker in clean_makers:
    maker_counts[maker] = maker_counts.get(maker, 0) + 1

sorted_makers = sorted(maker_counts.items(), key=lambda x: x[1], reverse=True)

print("\nTop 20 most common manufacturer names:")
for i, (maker, count) in enumerate(sorted_makers[:20]):
    print(f"{i+1}. {maker}: {count} occurrences")

print("\nAll unique manufacturer names (sorted alphabetically):")
print(", ".join(sorted(unique_makers)))
