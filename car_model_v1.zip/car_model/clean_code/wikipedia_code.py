import wikipedia

# List of entries to map
data = [
    "SRI LAXMI ENGINEERING & MOTOR WORKS",
    "0",
    "10.90 RHD F CAB DSD BS3",
    "10.90 RHD H CAB HSD BS3",
]

mapping = {}

for entry in data:
    try:
        # search Wikipedia for the entry
        results = wikipedia.search(entry)
        if results:
            page = wikipedia.page(results[0])
            # assume manufacturer is in the page title or summary
            summary = page.summary.lower()
            # simple heuristic: first proper noun in title
            manufacturer = page.title.split()[0]
            mapping[entry] = manufacturer
        else:
            mapping[entry] = "Unknown"
    except Exception as e:
        mapping[entry] = "Error: " + str(e)

# Print mapping
for k, v in mapping.items():
    print(f"{k!r}: {v!r}")