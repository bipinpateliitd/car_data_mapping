import json
import re
import time

def enhanced_clean_manufacturer(text):
    """
    Enhanced cleaning of manufacturer names with additional standardization rules
    """
    if not isinstance(text, str):
        return "UNKNOWN"
    
    # Convert to uppercase for consistency
    text = text.upper().strip()
    
    # Remove common prefixes like M/S (Manufacturer/Supplier)
    text = re.sub(r'^M/S\s+', '', text)
    
    # Replace HTML encoded ampersands and normalize ampersand usage
    text = text.replace('&AMP;', '&')
    text = text.replace('&amp;', '&')
    text = text.replace(' AND ', ' & ')
    
    # Remove trailing asterisks, hyphens, etc.
    text = re.sub(r'[*\-.,]+$', '', text)
    
    # Common manufacturer names we want to extract
    known_manufacturers = [
        "MARUTI", "TATA", "HYUNDAI", "MAHINDRA", "HONDA", "TOYOTA", "EICHER",
        "NISSAN", "VOLKSWAGEN", "MERCEDES", "SKODA", "FORD", "RENAULT", "KIA",
        "CHEVROLET", "FIAT", "JEEP", "AUDI", "BMW", "DATSUN", "PORSCHE", "VOLVO",
        "BAJAJ", "HERO", "TVS", "YAMAHA", "SUZUKI", "ROYAL ENFIELD", "JAWA",
        "ASHOK LEYLAND", "FORCE", "ISUZU", "LEXUS", "MG", "MINI", "JAGUAR",
        "LAND ROVER", "MITSUBISHI", "ROLLS ROYCE", "LAMBORGHINI", "FERRARI",
        "BENTLEY", "DAEWOO", "OPEL", "SSANGYONG", "ESCORTS", "SWARAJ"
    ]
    
    # Model names that need special handling
    model_to_manufacturer = {
        "ACTIVA": "HONDA",
        "CRETA": "HYUNDAI",
        "SWIFT": "MARUTI",
        "ALTO": "MARUTI",
        "BALENO": "MARUTI",
        "DZIRE": "MARUTI",
        "WAGON": "MARUTI",
        "ERTIGA": "MARUTI",
        "WAGONR": "MARUTI",
        "BREZZA": "MARUTI",
        "VITARA": "MARUTI",
        "BREEZA": "MARUTI",
        "CIAZ": "MARUTI",
        "XUV": "MAHINDRA",
        "SCORPIO": "MAHINDRA",
        "BOLERO": "MAHINDRA",
        "THAR": "MAHINDRA",
        "EECO": "MARUTI",
        "IGNIS": "MARUTI",
        "POLO": "VOLKSWAGEN",
        "I20": "HYUNDAI",
        "I10": "HYUNDAI",
        "VERNA": "HYUNDAI",
        "VENUE": "HYUNDAI",
        "NEXON": "TATA",
        "HARRIER": "TATA",
        "ALTROZ": "TATA",
        "TIAGO": "TATA",
        "TIGOR": "TATA",
        "SAFARI": "TATA",
        "ZEST": "TATA",
        "DOST": "ASHOK LEYLAND",
        "INNOVA": "TOYOTA",
        "FORTUNER": "TOYOTA",
        "GLANZA": "TOYOTA",
        "ETIOS": "TOYOTA",
        "KWID": "RENAULT",
        "DUSTER": "RENAULT",
        "TRIBER": "RENAULT",
        "MAGNITE": "NISSAN",
        "SELTOS": "KIA",
        "SONET": "KIA",
        "CARNIVAL": "KIA",
        "AMAZE": "HONDA"
    }
    
    # Standardize common manufacturer variations
    manufacturer_variations = {
        # Mahindra variations
        "MAHINDRA & MAHINDRA": "MAHINDRA",
        "MAHINDRA&MAHINDRA": "MAHINDRA",
        "MAHINDRA MAHINDRA": "MAHINDRA",
        "MAHINDRA TRUCKS": "MAHINDRA",
        "MAHINDRA LAST MILE MOBILITY": "MAHINDRA",
        "MAHINDRA TRACTORS": "MAHINDRA",
        "MAHINDRA TRUCKS&BUSES": "MAHINDRA",
        "MAHINDRA TRUCKS&AMP;BUSES": "MAHINDRA",
        "MAH & MAH": "MAHINDRA",
        
        # Tata variations
        "TATA MOTORS": "TATA",
        "TATA MOTORS LIM": "TATA",
        "TATA MOTERS": "TATA",
        "TATA ENGINEERING": "TATA",
        "TATA PASSENGER": "TATA",
        "TATA COMMERCIAL": "TATA",
        "TELCO": "TATA",  # Tata Engineering and Locomotive Company
        
        # Maruti variations
        "MARUTI SUZUKI": "MARUTI",
        "MARUTI UDYOG": "MARUTI",
        "MARUTIUDYOG": "MARUTI",
        "MARUITI": "MARUTI",
        
        # Honda variations
        "HONDA SIEL": "HONDA",
        "HONDA CARS": "HONDA",
        "HONDA MOTORCYCLE": "HONDA",
        "HONDA MOTORCYCLE AND SCOOTER": "HONDA",
        "KINETIC HONDA": "HONDA",
        
        # Volkswagen variations
        "VOLKSWAGON": "VOLKSWAGEN",
        "VOLKSWAGE 38436 WOLFBUR": "VOLKSWAGEN",
        "VOLKSWAGE 38436WOLFBURG": "VOLKSWAGEN",
        "VOLKS WAGON": "VOLKSWAGEN",
        "VW": "VOLKSWAGEN",
        "VOLKSWAGEN GROUP": "VOLKSWAGEN",
        
        # Other common variations
        "HYUNDAI MOTOR": "HYUNDAI",
        "ASHOK LEYLAND": "ASHOK LEYLAND",
        "TOYOTA KIRLOSKAR": "TOYOTA",
        "MERCEDES BENZ": "MERCEDES",
        "MERCEDES-BENZ": "MERCEDES",
        "HERO HONDA": "HERO",
        "HERO MOTOCORP": "HERO",
        "SWARAJ MAZDA": "SWARAJ",
        "ROYAL ENFIELD": "ROYAL ENFIELD",
        "ROYAL-ENFIELD": "ROYAL ENFIELD",
        "ROYAL-ENFIELD (UNIT OF EICHER)": "ROYAL ENFIELD",
        "RENAULT NISSAN": "RENAULT-NISSAN",
        "RENAULT-NISSAN AUTOMOTIVE": "RENAULT-NISSAN",
        "HINDUSTAN MOTORS": "HINDUSTAN",
        "HINDUSTAN FINANCE": "HINDUSTAN",
        "INDIA YAMAHA": "YAMAHA",
        "SKODAAUTO": "SKODA",
        "GENERAL MOTORS": "GENERAL MOTORS",
        "GENERAL MOTOR": "GENERAL MOTORS",
        "INTERNATIONAL TRACTORS": "INTERNATIONAL",
        "INTERNATIONAL &": "INTERNATIONAL",
        "INDIA KAWASAKI": "KAWASAKI",
        "DASMESH MECHANICAL": "DASMESH",
        "DASMESH AGRICULTURE": "DASMESH",
        "DASMESH AGRI": "DASMESH",
        "DASMESHRICULTURAL": "DASMESH"
    }
    
    # First try direct mapping
    if text in manufacturer_variations:
        return manufacturer_variations[text]
    
    # Check for Volkswagen variations using regex
    if re.search(r'^VOLKSWAGE(?:N|)\s*\d*', text):
        return "VOLKSWAGEN"
        
    # Then try to extract known manufacturer from the beginning of the string
    for manufacturer in known_manufacturers:
        pattern = f"^{manufacturer}\\b"
        if re.search(pattern, text):
            return manufacturer
    
    # Check for models we know
    for model, manufacturer in model_to_manufacturer.items():
        pattern = f"\\b{model}\\b"
        if re.search(pattern, text):
            return manufacturer
    
    # Handle special cases from the examples provided
    if "EICHER PRO" in text:
        return "EICHER"
    elif text.startswith("VW "):
        return "VOLKSWAGEN"
    elif "MARUTI-VITARA" in text:
        return "MARUTI"
    elif "MAHINDRA" in text:
        return "MAHINDRA"
    elif "JCB" in text:
        return "JCB"
    elif "BENZ" in text:
        return "MERCEDES"
    elif "ASHOK" in text and "LEYLAND" in text:
        return "ASHOK LEYLAND"
    
    # Clean up common suffixes and standardize manufacturer names
    common_suffixes = [
        " LTD", " LIMITED", " PVT LTD", " PVT", " INDIA PVT LTD", " INDIA LIMITED",
        " & MAHINDRA", " INDIA", " CO.", " MOTORS", " MOTOR", " COMPANY", ".,", ".",
        " PRIVATE LIMITED", " PRIVATE", " P LTD", " (P) LTD", " (P LTD", " (I) LTD",
        " (INDIA) PVT LTD", " (INDIA) LIMITED", " (UNIT OF EICHER LTD)", " AG",
        " CORPORATION", " CORP", " (P)", " LTD.,", " AUTOMOBILE", " AUTOMOBILES",
        " AUTOMOTIVE", " VEHICLES", " VEHICLE", " AUTO", " CORP.", " INDUSTRIES",
        " INDUSTRY", " WORKS", " MANUFACTURING", " MFG", " TECH", " TECHNOLOGY",
        " LAST MILE MOBILITY", " COMMERCIAL", " PASSENGER", " FARM EQUIPMENT",
        " TRUCKS", " BUSES", " CARS", " MOTORCYCLES", " TWO WHEELER", " TRACTORS"
    ]
    
    for suffix in common_suffixes:
        text = text.replace(suffix, "")
    
    # We've tried our best, return the first word as fallback
    first_word = text.split()[0] if text.split() else text
    
    # If first_word is in our known manufacturers, return it
    if first_word in known_manufacturers:
        return first_word
    
    # Clean up any remaining multiple spaces
    text = re.sub(r'\s+', ' ', text).strip()
    
    # If the result contains technical indicators, just return the first word
    if re.search(r'\b(BS[0-9IV]+|[0-9]+CC|[0-9]+PS|AT|MT|XMA|XE|QJET|CDI|CRDI|SX|CAB)\b', text):
        return first_word
    
    # Handle "OTHERS" case
    if text in ["OTHERS", "OTHER", "NIL", "LOCAL", "UNKNOWN"]:
        return "OTHERS"
    
    return text

# Load the unique makers JSON file
try:
    with open('unique_makers.json', 'r') as f:
        makers_data = json.load(f)
except Exception as e:
    print(f"Error loading unique_makers.json: {e}")
    exit(1)

print(f"Loaded {len(makers_data)} manufacturer names")

# Clean the manufacturer names
clean_makers = []
unique_clean_makers = set()

start_time = time.time()
for maker in makers_data:
    clean_maker = enhanced_clean_manufacturer(maker)
    clean_makers.append(clean_maker)
    unique_clean_makers.add(clean_maker)

# Create a mapping dictionary
mapping = {makers_data[i]: clean_makers[i] for i in range(len(makers_data))}

# Count occurrences of each manufacturer
maker_counts = {}
for maker in clean_makers:
    maker_counts[maker] = maker_counts.get(maker, 0) + 1

# Sort manufacturers by frequency
sorted_makers = sorted(maker_counts.items(), key=lambda x: x[1], reverse=True)

# Print top 100 manufacturers
print("\nTop 100 most common manufacturer names:")
for i, (maker, count) in enumerate(sorted_makers[:100]):
    print(f"{i+1}. {maker}: {count} occurrences")

# Save the cleaned data to new JSON files
try:
    # Save the clean makers list (same order as original)
    with open('enhanced_clean_makers.json', 'w') as f:
        json.dump(clean_makers, f, indent=2)
    
    # Save the unique clean makers (sorted)
    with open('enhanced_unique_makers.json', 'w') as f:
        json.dump(sorted(list(unique_clean_makers)), f, indent=2)
    
    # Save the mapping of original to clean
    with open('enhanced_maker_mapping.json', 'w') as f:
        json.dump(mapping, f, indent=2)
    
    # Save manufacturer frequency data
    frequency_data = [{"manufacturer": maker, "count": count} for maker, count in sorted_makers]
    with open('manufacturer_frequency.json', 'w') as f:
        json.dump(frequency_data, f, indent=2)
except Exception as e:
    print(f"Error saving files: {e}")
    exit(1)

end_time = time.time()
print(f"\nCleaning completed in {end_time - start_time:.2f} seconds")
print(f"Original number of makers: {len(makers_data)}")
print(f"Number of unique clean makers: {len(unique_clean_makers)}")
print(f"Reduced by: {len(makers_data) - len(unique_clean_makers)} ({(1 - len(unique_clean_makers)/len(makers_data))*100:.1f}%)")
print(f"\nResults saved to:")
print("- enhanced_clean_makers.json (cleaned list in original order)")
print("- enhanced_unique_makers.json (sorted unique cleaned names)")
print("- enhanced_maker_mapping.json (mapping from original to clean names)")
print("- manufacturer_frequency.json (frequency data for each manufacturer)")
