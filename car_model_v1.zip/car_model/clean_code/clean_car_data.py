import pandas as pd
import re

def clean_manufacturer(maker):
    """
    Clean the car manufacturer names by removing common suffixes and standardizing names
    """
    # Convert to uppercase for consistency
    maker = maker.upper() if isinstance(maker, str) else "UNKNOWN"
    
    # Remove common suffixes and standardize manufacturer names
    common_suffixes = [
        " LTD", " LIMITED", " PVT LTD", " PVT", " INDIA PVT LTD", " INDIA LIMITED",
        " & MAHINDRA", " INDIA", " CO.", " MOTORS", " MOTOR", " COMPANY", ".,", "."
    ]
    
    for suffix in common_suffixes:
        maker = maker.replace(suffix, "")
    
    # Handle specific cases
    maker_mapping = {
        "MARUTI SUZUKI": "MARUTI",
        "MERCEDES-BENZ": "MERCEDES",
        "M BENZ": "MERCEDES",
        "MERCEDES BENZ": "MERCEDES",
        "BAJAJ TEMPO": "BAJAJ",
        "TATA MOTORS": "TATA",
        "ASHOK LEYLAND": "LEYLAND",
        "MAHINDRA & MAHINDRA": "MAHINDRA",
        "MAHINDRA": "MAHINDRA"
    }
    
    for original, replacement in maker_mapping.items():
        if original in maker:
            return replacement
    
    # Handle "OTHERS" case
    if maker == "OTHERS":
        return "OTHERS"
    
    return maker.strip()

def clean_model(model):
    """
    Clean the car model names by standardizing format and removing unnecessary information
    """
    if not isinstance(model, str):
        return "UNKNOWN"
    
    # Convert to title case for better readability
    model = model.title()
    
    # Remove specific prefixes that repeat the manufacturer
    prefixes_to_remove = ["Maruti ", "Mahindra ", "Tata ", "M Benz "]
    for prefix in prefixes_to_remove:
        if model.startswith(prefix):
            model = model[len(prefix):]
    
    # Remove unnecessary detail patterns
    # For example: "2WD", "BSVI-PH2", etc.
    detail_patterns = [
        r'\d+\.\d+L',  # engine size like 1.5L
        r'\d+MT',      # transmission type
        r'BSVI-PH\d+', # emission standards
        r'\d+WD',      # wheel drive type
        r'\(\w+\)',    # anything in parentheses
    ]
    
    for pattern in detail_patterns:
        model = re.sub(pattern, '', model)
    
    # Remove multiple spaces and trim
    model = re.sub(r'\s+', ' ', model).strip()
    
    return model

def main():
    # Read the Excel file
    try:
        df = pd.read_excel('UniqueMakeModels.xlsx')
        print(f"Successfully read file. Found {len(df)} records.")
    except Exception as e:
        print(f"Error reading file: {e}")
        return
    
    # Check column names and use the ones from the example
    if 'rc_maker_desc' in df.columns and 'rc_maker_model' in df.columns:
        # Make a copy of original columns
        df['original_maker'] = df['rc_maker_desc']
        df['original_model'] = df['rc_maker_model']
        
        # Apply cleaning functions
        df['clean_maker'] = df['rc_maker_desc'].apply(clean_manufacturer)
        df['clean_model'] = df['rc_maker_model'].apply(clean_model)
    else:
        print(f"Expected columns not found. Available columns: {df.columns.tolist()}")
        return
    
    # Save the cleaned data
    output_file = 'CleanedCarData.xlsx'
    df.to_excel(output_file, index=False)
    print(f"Cleaned data saved to {output_file}")
    
    # Display some examples
    print("\nCleaning Examples:")
    sample = df.head(10)
    for _, row in sample.iterrows():
        print(f"Original: {row['original_maker']} | {row['original_model']}")
        print(f"Cleaned : {row['clean_maker']} | {row['clean_model']}")
        print("---")

if __name__ == "__main__":
    main()
