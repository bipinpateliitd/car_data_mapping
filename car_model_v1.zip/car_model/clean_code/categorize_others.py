import json
import re

def categorize_others():
    """
    Loads 'others_list.json' and categorizes entries into three groups:
    1. Entries containing numbers.
    2. Entries not containing numbers but containing 'LTD'.
    3. Entries not containing numbers and not containing 'LTD'.
    Saves these lists to separate JSON and TXT files.
    """
    input_filename = 'others_list.json'
    output_with_numbers_json = 'others_with_numbers.json'
    output_with_numbers_txt = 'others_with_numbers.txt'
    output_with_ltd_json = 'others_with_ltd_no_numbers.json'
    output_with_ltd_txt = 'others_with_ltd_no_numbers.txt'
    output_neither_json = 'others_neither_number_nor_ltd.json'
    output_neither_txt = 'others_neither_number_nor_ltd.txt'

    try:
        with open(input_filename, 'r') as f:
            others_list = json.load(f)
        print(f"Loaded {len(others_list)} entries from '{input_filename}'.")

        with_numbers = []
        with_ltd_no_numbers = []
        neither_number_nor_ltd = []

        for item in others_list:
            item_str = str(item) # Ensure item is a string
            # Check for numbers
            if re.search(r'\d', item_str):
                with_numbers.append(item_str)
            # Else, check for 'LTD' (case-insensitive for robustness, though data is uppercase)
            elif 'LTD' in item_str.upper():
                with_ltd_no_numbers.append(item_str)
            # Else, it's neither a number nor contains 'LTD'
            else:
                neither_number_nor_ltd.append(item_str)

        # Sort the lists for consistent output
        with_numbers.sort()
        with_ltd_no_numbers.sort()
        neither_number_nor_ltd.sort()

        print(f"Found {len(with_numbers)} entries containing numbers.")
        print(f"Found {len(with_ltd_no_numbers)} entries containing 'LTD' (and no numbers).")
        print(f"Found {len(neither_number_nor_ltd)} entries with neither numbers nor 'LTD'.")

        # Save 'with_numbers' lists
        with open(output_with_numbers_json, 'w') as f:
            json.dump(with_numbers, f, indent=2)
        with open(output_with_numbers_txt, 'w') as f:
            for entry in with_numbers:
                f.write(f"{entry}\n")
        print(f"Saved number-containing entries to '{output_with_numbers_json}' and '{output_with_numbers_txt}'.")

        # Save 'with_ltd_no_numbers' lists
        with open(output_with_ltd_json, 'w') as f:
            json.dump(with_ltd_no_numbers, f, indent=2)
        with open(output_with_ltd_txt, 'w') as f:
            for entry in with_ltd_no_numbers:
                f.write(f"{entry}\n")
        print(f"Saved 'LTD'-containing (no numbers) entries to '{output_with_ltd_json}' and '{output_with_ltd_txt}'.")

        # Save 'neither_number_nor_ltd' lists
        with open(output_neither_json, 'w') as f:
            json.dump(neither_number_nor_ltd, f, indent=2)
        with open(output_neither_txt, 'w') as f:
            for entry in neither_number_nor_ltd:
                f.write(f"{entry}\n")
        print(f"Saved entries with neither numbers nor 'LTD' to '{output_neither_json}' and '{output_neither_txt}'.")

    except FileNotFoundError:
        print(f"Error: '{input_filename}' not found. Please ensure the file exists.")
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    categorize_others()
