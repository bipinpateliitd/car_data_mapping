import json

def extract_others():
    """
    Extract all entries from the batch_llm_maker_mapping.json file that were mapped to "OTHERS"
    """
    try:
        # Load the mapping file
        with open('batch_llm_maker_mapping.json', 'r') as f:
            mapping = json.load(f)
        
        # Find all entries mapped to "OTHERS"
        others_list = [original for original, cleaned in mapping.items() if cleaned == "OTHERS"]
        
        # Sort the list for better readability
        others_list.sort()
        
        # Print the count and list
        print(f"Found {len(others_list)} entries categorized as 'OTHERS'")
        for i, item in enumerate(others_list):
            print(f"{i+1}. {item}")
        
        # Save to a JSON file
        with open('others_list.json', 'w') as f:
            json.dump(others_list, f, indent=2)
        
        # Save to a text file for easier viewing
        with open('others_list.txt', 'w') as f:
            for item in others_list:
                f.write(f"{item}\n")
        
        print(f"\nResults saved to:")
        print("- others_list.json")
        print("- others_list.txt")
    
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    extract_others()
