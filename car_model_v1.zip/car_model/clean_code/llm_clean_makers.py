import json
import os
import time
import openai
import dotenv
from concurrent.futures import ThreadPoolExecutor
from tqdm import tqdm

# Load environment variables from .env file if it exists
dotenv.load_dotenv()

# Get API key from environment variables
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
if not OPENAI_API_KEY:
    print("Error: OPENAI_API_KEY not found in environment variables.")
    print("Please create a .env file with your API key or set it in your environment.")
    print("Example .env file content: OPENAI_API_KEY=your_api_key_here")
    exit(1)

# Set up OpenAI client
openai.api_key = OPENAI_API_KEY

def clean_manufacturer_with_llm(maker, model="gpt-4o-mini"):
    """
    Use LLM to standardize manufacturer name
    """
    if not isinstance(maker, str) or maker.strip() == "":
        return "UNKNOWN"
    
    try:
        response = openai.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": """You are a specialized automotive data cleaning assistant. 
Your task is to identify and return ONLY the standardized automobile manufacturer name from the text provided.
- If the input contains a car manufacturer and model, return ONLY the standardized manufacturer name.
- If the input is a car model without a manufacturer mentioned, identify and return the manufacturer of that model.
- If the input contains technical specs like engine sizes, BS4/BS6, etc., ignore these and focus on the manufacturer.
- If the manufacturer name has variations (like M/S MAHINDRA, MAHINDRA & MAHINDRA, etc.), standardize to the simplest form (e.g., "MAHINDRA").
- Return ONLY the manufacturer name in uppercase, nothing else - no explanations or additional text.
- If you cannot confidently identify a manufacturer, return "OTHERS".

Examples of standardized manufacturer names:
MARUTI (for Maruti Suzuki or similar)
TATA
HYUNDAI
MAHINDRA
HONDA
TOYOTA
MERCEDES
VOLKSWAGEN
FORD
"""},
                {"role": "user", "content": f"Identify and standardize the manufacturer name from: {maker}"}
            ],
            temperature=0.0,  # Use deterministic output
            max_tokens=10     # We just need the name, so limit tokens
        )
        
        # Extract the response
        result = response.choices[0].message.content.strip()
        return result
    except Exception as e:
        print(f"Error processing '{maker}': {e}")
        return maker  # Return original if there's an error

def process_batch(batch):
    """Process a batch of manufacturer names"""
    results = []
    for maker in batch:
        clean_maker = clean_manufacturer_with_llm(maker)
        results.append(clean_maker)
    return results

# Load the unique makers JSON file
try:
    with open('unique_makers.json', 'r') as f:
        makers_data = json.load(f)
except Exception as e:
    print(f"Error loading unique_makers.json: {e}")
    exit(1)

print(f"Loaded {len(makers_data)} manufacturer names")

# Ask for confirmation due to potential API costs
unique_set = set(makers_data)
print(f"This will make {len(unique_set)} API calls to OpenAI.")
print(f"Using gpt-3.5-turbo, this may cost approximately ${len(unique_set) * 0.0015:.2f}")
confirmation = input("Do you want to proceed? (yes/no): ")

if confirmation.lower() not in ["yes", "y"]:
    print("Operation cancelled.")
    exit(0)

# Process only unique values to save API calls
start_time = time.time()
print(f"Processing {len(unique_set)} unique manufacturer names...")

# Create a mapping of original to deduped indices to rebuild the full list later
unique_list = list(unique_set)
deduped_mapping = {}
for i, maker in enumerate(makers_data):
    if maker in unique_set:
        deduped_mapping[maker] = unique_list.index(maker)

# Use ThreadPoolExecutor for parallel processing
# Split into batches of 20 for progress display
batch_size = 20
batches = [unique_list[i:i+batch_size] for i in range(0, len(unique_list), batch_size)]
clean_unique_makers = []

with ThreadPoolExecutor(max_workers=5) as executor:
    for result_batch in tqdm(executor.map(process_batch, batches), total=len(batches)):
        clean_unique_makers.extend(result_batch)

# Rebuild the full list using the mapping
clean_makers = []
for maker in makers_data:
    idx = deduped_mapping[maker]
    clean_makers.append(clean_unique_makers[idx])

# Count unique values after cleaning
final_unique_makers = set(clean_makers)

# Count occurrences of each manufacturer
maker_counts = {}
for maker in clean_makers:
    maker_counts[maker] = maker_counts.get(maker, 0) + 1

# Sort manufacturers by frequency
sorted_makers = sorted(maker_counts.items(), key=lambda x: x[1], reverse=True)

# Print top 50 manufacturers
print("\nTop 50 most common manufacturer names after LLM cleaning:")
for i, (maker, count) in enumerate(sorted_makers[:50]):
    print(f"{i+1}. {maker}: {count} occurrences")

# Save the cleaned data to new JSON files
try:
    # Save the clean makers list (same order as original)
    with open('llm_clean_makers.json', 'w') as f:
        json.dump(clean_makers, f, indent=2)
    
    # Save the unique clean makers (sorted)
    with open('llm_unique_makers.json', 'w') as f:
        json.dump(sorted(list(final_unique_makers)), f, indent=2)
    
    # Save the mapping of original to clean
    mapping = {makers_data[i]: clean_makers[i] for i in range(len(makers_data))}
    with open('llm_maker_mapping.json', 'w') as f:
        json.dump(mapping, f, indent=2)
    
    # Save manufacturer frequency data
    frequency_data = [{"manufacturer": maker, "count": count} for maker, count in sorted_makers]
    with open('llm_manufacturer_frequency.json', 'w') as f:
        json.dump(frequency_data, f, indent=2)
except Exception as e:
    print(f"Error saving files: {e}")
    exit(1)

end_time = time.time()
print(f"\nCleaning completed in {end_time - start_time:.2f} seconds")
print(f"Original number of makers: {len(makers_data)}")
print(f"Number of unique clean makers before LLM: {len(unique_set)}")
print(f"Number of unique clean makers after LLM: {len(final_unique_makers)}")
print(f"Reduced by: {len(makers_data) - len(final_unique_makers)} ({(1 - len(final_unique_makers)/len(makers_data))*100:.1f}%)")
print(f"\nResults saved to:")
print("- llm_clean_makers.json (cleaned list in original order)")
print("- llm_unique_makers.json (sorted unique cleaned names)")
print("- llm_maker_mapping.json (mapping from original to clean names)")
print("- llm_manufacturer_frequency.json (frequency data for each manufacturer)")
