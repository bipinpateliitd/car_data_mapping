import json
import re
import time

def extract_manufacturer(text):
    """
    Extract just the manufacturer name from a string that might contain model details
    """
    if not isinstance(text, str):
        return "UNKNOWN"
    
    text = text.upper().strip()
    
    # Common manufacturer names we want to extract
    known_manufacturers = [
        "MARUTI", "TATA", "HYUNDAI", "MAHINDRA", "HONDA", "TOYOTA", "EICHER",
        "NISSAN", "VOLKSWAGEN", "MERCEDES", "SKODA", "FORD", "RENAULT", "KIA",
        "CHEVROLET", "FIAT", "JEEP", "AUDI", "BMW", "DATSUN", "PORSCHE", "VOLVO",
        "BAJAJ", "HERO", "TVS", "YAMAHA", "SUZUKI", "ROYAL ENFIELD", "JAWA",
        "ASHOK LEYLAND", "FORCE", "ISUZU", "LEXUS", "MG", "MINI", "JAGUAR",
        "LAND ROVER", "MITSUBISHI", "ROLLS ROYCE", "LAMBORGHINI", "FERRARI",
        "BENTLEY", "DAEWOO", "OPEL", "SSANGYONG", "ESCORTS", "SWARAJ"
    ]
    
    # Model names that need special handling
    model_to_manufacturer = {
        "ACTIVA": "HONDA",
        "CRETA": "HYUNDAI",
        "SWIFT": "MARUTI",
        "ALTO": "MARUTI",
        "BALENO": "MARUTI",
        "DZIRE": "MARUTI",
        "WAGON": "MARUTI",
        "ERTIGA": "MARUTI",
        "WAGONR": "MARUTI",
        "BREZZA": "MARUTI",
        "VITARA": "MARUTI",
        "BREEZA": "MARUTI",
        "CIAZ": "MARUTI",
        "XUV": "MAHINDRA",
        "SCORPIO": "MAHINDRA",
        "BOLERO": "MAHINDRA",
        "THAR": "MAHINDRA",
        "EECO": "MARUTI",
        "IGNIS": "MARUTI",
        "POLO": "VOLKSWAGEN",
        "I20": "HYUNDAI",
        "I10": "HYUNDAI",
        "VERNA": "HYUNDAI",
        "VENUE": "HYUNDAI",
        "NEXON": "TATA",
        "HARRIER": "TATA",
        "ALTROZ": "TATA",
        "TIAGO": "TATA",
        "TIGOR": "TATA",
        "SAFARI": "TATA",
        "ZEST": "TATA",
        "DOST": "ASHOK LEYLAND",
        "INNOVA": "TOYOTA",
        "FORTUNER": "TOYOTA",
        "GLANZA": "TOYOTA",
        "ETIOS": "TOYOTA",
        "KWID": "RENAULT",
        "DUSTER": "RENAULT",
        "TRIBER": "RENAULT",
        "MAGNITE": "NISSAN",
        "SELTOS": "KIA",
        "SONET": "KIA",
        "CARNIVAL": "KIA"
    }
    
    # First try to extract known manufacturer from the beginning of the string
    for manufacturer in known_manufacturers:
        pattern = f"^{manufacturer}\\b"
        if re.search(pattern, text):
            return manufacturer
    
    # If that fails, check for models we know
    for model, manufacturer in model_to_manufacturer.items():
        pattern = f"\\b{model}\\b"
        if re.search(pattern, text):
            return manufacturer
    
    # Handle special cases from the examples provided
    if "EICHER PRO" in text:
        return "EICHER"
    elif "VW " in text:
        return "VOLKSWAGEN"
    elif "MARUTI-VITARA" in text:
        return "MARUTI"
    
    # We've tried our best, return the first word as fallback
    first_word = text.split()[0] if text.split() else text
    
    # If first_word is in our known manufacturers, return it
    if first_word in known_manufacturers:
        return first_word
    
    # For anything else, apply basic cleaning to the input
    # Remove common suffixes
    common_suffixes = [
        " LTD", " LIMITED", " PVT LTD", " PVT", " INDIA PVT LTD", " INDIA LIMITED",
        " & MAHINDRA", " INDIA", " CO.", " MOTORS", " MOTOR", " COMPANY", ".,", "."
    ]
    
    result = text
    for suffix in common_suffixes:
        result = result.replace(suffix, "")
    
    # If the result contains BS4/BS6/BSIV/BSVI indicators or common model descriptors,
    # just return the first word as manufacturer
    if re.search(r'\b(BS[0-9IV]+|[0-9]+CC|[0-9]+PS|AT|MT|XMA|XE|QJET|CDI|CRDI|SX|CAB)\b', result):
        return first_word
    
    return result.strip()

start_time = time.time()

# Load the unique makers JSON file
try:
    with open('unique_makers.json', 'r') as f:
        makers_data = json.load(f)
except Exception as e:
    print(f"Error loading unique_makers.json: {e}")
    exit(1)

print(f"Loaded {len(makers_data)} manufacturer names")

# Clean the manufacturer names
clean_makers = []
unique_clean_makers = set()

for maker in makers_data:
    clean_maker = extract_manufacturer(maker)
    clean_makers.append(clean_maker)
    unique_clean_makers.add(clean_maker)

# Create a mapping dictionary
mapping = {makers_data[i]: clean_makers[i] for i in range(len(makers_data))}

# Save the cleaned data to a new JSON file
try:
    # Save the clean makers list (same order as original)
    with open('improved_clean_makers.json', 'w') as f:
        json.dump(clean_makers, f, indent=2)
    
    # Save the unique clean makers (sorted)
    with open('improved_unique_makers.json', 'w') as f:
        json.dump(sorted(list(unique_clean_makers)), f, indent=2)
    
    # Save the mapping of original to clean
    with open('improved_maker_mapping.json', 'w') as f:
        json.dump(mapping, f, indent=2)
except Exception as e:
    print(f"Error saving files: {e}")
    exit(1)

end_time = time.time()
print(f"Cleaning completed in {end_time - start_time:.2f} seconds")
print(f"Original number of makers: {len(makers_data)}")
print(f"Number of unique clean makers: {len(unique_clean_makers)}")
print(f"Reduced by: {len(makers_data) - len(unique_clean_makers)} ({(1 - len(unique_clean_makers)/len(makers_data))*100:.1f}%)")

# Display sample of original vs cleaned for the examples mentioned by user
examples = [
    "TATA NEXON XMA 15 RTQ BS6 BSVI",
    "ACTIVA125 W EAUTO S & K S &DRUM CBSWALOYWL BSIV",
    "TATA ZEST XE QJET 75PS BSIV",
    "CRETA 15 CRDI AT SX(O) BSVI",
    "EICHER PRO 1110XP H CAB & HSD BSIV",
    "NISSAN MAGNITE MT XV BSVI"
]

print("\nSample of how problematic entries are now cleaned:")
for example in examples:
    if example in makers_data:
        idx = makers_data.index(example)
        print(f"Original: {example}")
        print(f"Cleaned : {clean_makers[idx]}")
        print("---")
    else:
        print(f"Example '{example}' not found in the data, but would clean to: {extract_manufacturer(example)}")
        print("---")
