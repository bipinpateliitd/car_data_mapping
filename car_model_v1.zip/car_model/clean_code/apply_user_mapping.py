import json
import os

def apply_mapping():
    base_path = "/home/bipin/Documents/kotak/car_model/"
    others_file_path = os.path.join(base_path, "others_with_numbers.json")
    mapping_file_path = os.path.join(base_path, "user_provided_mapping.json")
    output_file_path = os.path.join(base_path, "final_mapped_numbered_others.json")

    try:
        with open(others_file_path, 'r', encoding='utf-8') as f:
            others_list = json.load(f)
    except FileNotFoundError:
        print(f"Error: File not found - {others_file_path}")
        return
    except json.JSONDecodeError:
        print(f"Error: Could not decode JSON from {others_file_path}")
        return

    try:
        with open(mapping_file_path, 'r', encoding='utf-8') as f:
            user_mapping = json.load(f)
    except FileNotFoundError:
        print(f"Error: File not found - {mapping_file_path}. Please run create_user_mapping_json.py first.")
        return
    except json.JSONDecodeError:
        print(f"Error: Could not decode JSON from {mapping_file_path}")
        return

    final_mapping = {}
    not_found_count = 0

    if not isinstance(others_list, list):
        print(f"Error: Expected a list in {others_file_path}, but got {type(others_list)}")
        return

    if not isinstance(user_mapping, dict):
        print(f"Error: Expected a dictionary in {mapping_file_path}, but got {type(user_mapping)}")
        return

    for entry in others_list:
        if isinstance(entry, str):
            if entry in user_mapping:
                final_mapping[entry] = user_mapping[entry]
            else:
                final_mapping[entry] = "others"
                not_found_count += 1
        else:
            print(f"Warning: Skipping non-string entry in {others_file_path}: {entry}")

    try:
        with open(output_file_path, 'w', encoding='utf-8') as f:
            json.dump(final_mapping, f, indent=2, ensure_ascii=False)
        print(f"Successfully created mapping file: {output_file_path}")
        print(f"Total entries processed: {len(others_list)}")
        print(f"Entries mapped from user_provided_mapping.json: {len(others_list) - not_found_count}")
        print(f"Entries mapped to 'others': {not_found_count}")

    except IOError as e:
        print(f"Error writing to file {output_file_path}: {e}")

if __name__ == "__main__":
    apply_mapping()
