import json

# The string provided by the user
user_data_string = """{
  "0": "Unknown",
  "10.90 RHD F CAB DSD BS3": "Eicher Trucks (VE Commercial Vehicles Ltd.)",
  "10.90 RHD H CAB HSD BS3": "Eicher Trucks (VE Commercial Vehicles Ltd.)",
  "11.10 HD RHD G CAB & HSD BSII": "Eicher Trucks (VE Commercial Vehicles Ltd.)",
  "11.10 HD RHD H CAB & HSD BS II": "Eicher Trucks (VE Commercial Vehicles Ltd.)",
  "11.10 HD RHD H CAB & HSD BS III": "Eicher Trucks (VE Commercial Vehicles Ltd.)",
  "11.10 HD RHD H CAB & HSD BSII": "Eicher Trucks (VE Commercial Vehicles Ltd.)",
  "1616 IL/1 BSIII": "Eicher Trucks (Pro Series)",
  "2516 XL  TUSKER SUPER 6X2 BSIII": "Eicher Trucks (Pro Series)",
  "2518C/4 RMC DAYCAB(10.00-20;16PR) BSIV": "Eicher Trucks (Pro Series)",
  "3718COWL(L10450 BSIV": "Eicher Trucks (Pro Series)",
  "3718COWL(L10450) BSIV": "Eicher Trucks (Pro Series)",
  "3718IL TYRE 10.00 R 20: 16 PR BSIII": "Eicher Trucks (Pro Series)",
  "3DX  2WD BACKHOE LOADER BSIII": "Ashok Leyland",
  "3EV INDUSTRIES PVT LTD": "3EV Industries Pvt Ltd",
  "3GB TECHNOLOGY PVT LTD": "3GB Technology Pvt Ltd",
  "3S INDUSTRIES PRIVATE LIMITED": "3S Industries Private Limited",
  "5TONS 2WH TRAILER WATER TANKER IRON BODY": "Self-manufacturer",
  "A1 HEAVY EQUIPMENTS DEVELOPER": "A1 Heavy Equipments Developer",
  "A3T INCORPORTED": "A3T Incorporated",
  "ACTIVA 5GWEAS&KS&DCBS(CBS)WSEHEETWHEEL BSIV": "Honda Motorcycle & Scooter India (HMSI)",
  "ACTIVA125 W EAUTO S & K S &DRUM CBSWALOYWL BSIV": "Honda Motorcycle & Scooter India (HMSI)",
  "ALPSV 4/185 10X20-16 BSIII": "Ashok Leyland (ALPSV)",
  "ALPSV 4/88 VIKING BSII": "Ashok Leyland (ALPSV)",
  "AVENGER 220-CRUISE BSIV": "Bajaj Auto",
  "BADA DOST I2TNDD-FSD-NON AC-215/75-R15-LT BSVI-PH2": "Force Motors",
  "BADA DOST I4TNDD NON-AC -LB BSVI": "Force Motors",
  "BHARATBENZ 1617R 5100 HSD (5985X2365X2000) BSIV": "BharatBenz",
  "BHARATBENZ 2528C 6X4-6 BSIV": "BharatBenz",
  "BHARATBENZ 2826C 6X4 N3G-4 BSVI-PH2": "BharatBenz",
  "BOLERO ZLX MH 2WD 7S BSIV AC PS": "Mahindra & Mahindra",
  "CA1215/39 H CC BSVI-PH2": "Tata Motors (ACE CA12)",
  "CA1415/32 T TIP 7CU M BSVI-PH2": "Tata Motors (ACE CA14)",
  "CA1415/39 H FBL/17FTFSD BSVI": "Tata Motors (ACE CA14)",
  "CLASSIC 500 BSIII": "Royal Enfield",
  "DASMESH-912(4X4)TRPCHARVESTERWJOHND5075ETR BSIII": "Dasmesh Group",
  "DEMAG DEMAG HC 340": "Terex (Demag)",
  "DOST + RLS - FSD - 195 R15 LT BSVI-PH2": "Force Motors",
  "DOST RLE-CC-MS-185R14LT8PR BSVI": "Force Motors",
  "DOST RLS FSD-PS-185R14C;8PR BSVI": "Force Motors",
  "DOST RLS HSD-PS-185R14LT;8PR BSVI": "Force Motors",
  "DOST RLS-FSD-PS -185R14C;8PR BSVI": "Force Motors",
  "DOST RLS-FSD-PS-185R14LT8PR BSVI": "Force Motors",
  "DOST+RLS-FSD-PS-195R15C-8PR BSVI": "Force Motors",
  "DOST+RLS-FSD-PS-195R15LT BSVI": "Force Motors",
  "EA 1920/66 H 33 FT LS COWL 295/90 R 20 BSVI": "Eicher Trucks",
  "ECOMET 1212 E4/4 BSIV": "ECOMET",
  "EXECUTIVE LXAC BUS 22STR RSDWWINDOW FRAME BSIV": "Tata Motors (Starbus)",
  "F15 WITH OUTRIGGER & CO-DRIVER BSIII": "Eicher Trucks",
  "FORTUNER SIGMA 4 AT BSIV": "Toyota Kirloskar Motor",
  "FV 2523 BSIII": "Ashok Leyland",
  "FV 4923 BSIII": "Ashok Leyland",
  "GP4825/66 H COWL LA 30LS NRS-295/90R20 BSVI": "Eicher Trucks",
  "GURU 1111 E4 CAB.CH(3800 WB(8.25-20;16PR) BSIV": "Eicher Trucks",
  "HECTORPLUS6 SHARPPRO-1325DBM BSVI": "MG Motor (Hector)",
  "INNOVA HYCROSS HYBRID ZX(7S) BSVI-PH2": "Toyota Kirloskar Motor",
  "INTRA  V30 PICKUP VX CLB LOW DECK BSVI-PH2": "Tata Motors (Intra)",
  "ISHER 568": "ISHER",
  "JEEP COMPASS LIMITED PLUS 1.4 MAIR DDCT BSIV": "Jeep India (Stellantis)",
  "JUPITER 125 FAW DISC & REAR AW DBM BSVI": "TVS Motor (Jupiter)",
  "KIASONET SMARTSTREAM G1.2 5MT HTK PLUS BSVI": "Kia Motors",
  "LPK 2518 TC 6X4 BSIII HT NS CAB CEMENT MIXER": "Ashok Leyland",
  "LPT 1212 DCR42CBC TRUCK CHASSIS WITH CAB BSVI": "Tata Motors (LPT)",
  "LPT 3118 TC BSIII(8X2)COWL WB5205": "Tata Motors (LPT)",
  "LPT 4825 10X2 TRK CHASS COWL WTH WINSHIELD BSVI": "Tata Motors (LPT)",
  "LPT4825 10X2TRK CHASS COWL WINSHILD 6780WB BSVI": "Tata Motors (LPT)",
  "M/S VOLKSWAGE AG 38436 WOLFBUR": "Volkswagen AG",
  "MAHA MOHAN 5246": "Maha Mohan",
  "N0VA AUTOMOTIVE TECHNOLOGIES PVT. LTD": "Nova Automotive Technologies Pvt Ltd",
  "NIC TEST ACCOUNT-1": "Test Account",
  "PLANET 7 INTERNATIONAL": "Planet 7 International",
  "PRESTIGE TC III WT50TCIII LWB BUS SEMIDELUXE": "Tata Motors (Starbus)",
  "R  KWID RXT CLIMBER OP PETROL EASY-R1.0SCE BSVI": "Renault (Kwid)",
  "R3 ENTERPRISES": "R3 Enterprises",
  "RAPID AMBITION 77KW MPI BSIV": "Mahindra & Mahindra (e-Verito Rapid)",
  "S-CAB- 2WD CBC HR BSVI": "Eicher Trucks",
  "S-CAB- 2WD HR BSVI": "Eicher Trucks",
  "S7 3335 SCHOOL BUS BSIV": "Tata Motors (Starbus)",
  "SAMRAT BH53 4240 SCHOOL BUS 43 STR BSVI": "Tata Motors (Starbus)",
  "SAMRAT WITH CARGO BOX  ELWB 4760 BSIV": "Tata Motors (Starbus)",
  "SARTAJ 5252 XM WITH SHD CARGO BOX BSIV": "Tata Motors (Starbus)",
  "SARTAJ 5252 XM WITH SMHD CARGO BOX BSIII": "Tata Motors (Starbus)",
  "SCHWING STETTER F-17 TAMILNADU": "Schwing Stetter",
  "SCORPIO-N D AT 2WD Z8L 6S NE BSVI": "Mahindra & Mahindra",
  "SCORPIO-N D AT 2WD Z8L 7S BSVI-PH2": "Mahindra & Mahindra",
  "SCORPIO-N D MT 2WD Z8L 7S BSVI": "Mahindra & Mahindra",
  "SCORPIO-N G AT 2WD Z8 7S BSVI-PH2": "Mahindra & Mahindra",
  "SIGNA 2825.K HDFBTIP NSPCAB BOG S&14CBTBB1 BSVI": "Ashok Leyland",
  "SIGNA4825.TK 10X2 FBTT SPCAB STDS 29C TBB1 BSVI": "Ashok Leyland",
  "SS1009.4D4RB 41 SEATS BSIV": "Tata Motors (Starbus)",
  "SUPREME 4760 ZT54E DELWB SCHOOL BUS 40 BSVI": "Tata Motors (Starbus)",
  "SUPREME ZT54E D ELWB DRIVE AWAY CHASSIS BSIV": "Tata Motors (Starbus)",
  "SUPREME ZT54E D LWB DRIVE AWAY CHASSIS BSIV": "Tata Motors (Starbus)",
  "SWARAJMAZDASPRMZT54ETCIIIDELWB BUS STBSIII": "Swaraj Mazda",
  "Test Maker 06": "Test Account",
  "UE2820/39R -NRS-7CUM-RMC-295/95D20 BSVI": "Eicher Trucks",
  "UJ3520/52 T TIP-BOGIE-22CUM BB--295/90R20 BSVI": "Eicher Trucks",
  "ULTRA T.11 DCR49HSD 125B6M5 FFCTCWC HDLB BSVI": "Tata Motors (Ultra)",
  "ULTRA1918.T 5L TRUCK CHASS WTH SLP TILTCAB BSVI": "Tata Motors (Ultra)",
  "UM4220/66 H 30FT SL.CABCH-375L BSVI": "Tata Motors (Ultra)",
  "VERITO D4 BSIV": "Tata Motors (Verito)",
  "VERNA-1.6 VTVT AUTO SX(O) BSIV": "Hyundai Motor India",
  "XUV700 AX5 DSL MT 7 SEATER BSVI": "Mahindra & Mahindra",
  "ZS ASTOR MT  MT STYLE EX 2123GFJ BSVI": "MG Motor (ZS Astor)"
}"""

def main():
    output_filename = "user_provided_mapping.json"

    try:
        # Parse the string into a Python dictionary
        data_dict = json.loads(user_data_string)
    except json.JSONDecodeError as e:
        print(f"Error decoding JSON string: {e}")
        return

    try:
        # Write the dictionary to a JSON file
        with open(output_filename, 'w', encoding='utf-8') as f:
            json.dump(data_dict, f, indent=2, ensure_ascii=False)
        print(f"Successfully created JSON file: {output_filename}")
    except IOError as e:
        print(f"Error writing to file {output_filename}: {e}")

if __name__ == "__main__":
    main()
