import json
import re
import time

def clean_manufacturer(maker):
    """
    Clean the car manufacturer names by removing common suffixes and standardizing names
    """
    # Handle non-string values
    if not isinstance(maker, str):
        return "UNKNOWN"
    
    # Convert to uppercase for consistency
    maker = maker.upper()
    
    # Remove non-alphanumeric characters at the beginning and end
    maker = re.sub(r'^[^a-zA-Z0-9]+|[^a-zA-Z0-9]+$', '', maker)
    
    # Remove common suffixes and standardize manufacturer names
    common_suffixes = [
        " LTD", " LIMITED", " PVT LTD", " PVT", " INDIA PVT LTD", " INDIA LIMITED",
        " & MAHINDRA", " INDIA", " CO.", " MOTORS", " MOTOR", " COMPANY", ".,", ".",
        " PRIVATE LIMITED", " PRIVATE", " P LTD", " (P) LTD", " (P LTD", " (I) LTD",
        " (INDIA) PVT LTD", " (INDIA) LIMITED", " (UNIT OF EICHER LTD)", " AG",
        " CORPORATION", " CORP", " (P)", " LTD.,", " AUTOMOBILE", " AUTOMOBILES",
        " AUTOMOTIVE", " VEHICLES", " VEHICLE", " AUTO", " CORP.", " INDUSTRIES",
        " INDUSTRY", " WORKS", " CORP.", " (I)", " (INDIA)", "\u00a0\u00a0\u00a0\u00a0",
        " \u00a0"
    ]
    
    for suffix in common_suffixes:
        maker = maker.replace(suffix, "")
    
    # Handle specific cases - mapping similar manufacturers to a standard name
    maker_mapping = {
        "MARUTI SUZUKI": "MARUTI",
        "MARUTI UDYOG": "MARUTI",
        "MARUTIUDYG": "MARUTI",
        "MARUTISWIFT": "MARUTI",
        "MERCEDES-BENZ": "MERCEDES",
        "MERCEDES BENZ": "MERCEDES",
        "M BENZ": "MERCEDES",
        "MERC BENZ": "MERCEDES",
        "MERCEDEZ BENZ": "MERCEDES",
        "BAJAJ TEMPO": "BAJAJ",
        "BAJAJTEMPO": "BAJAJ",
        "TATA MOTORS": "TATA",
        "TATA ENGG": "TATA",
        "TATA ENGG AND LOCO": "TATA",
        "TATA ENGG & LOCO": "TATA",
        "TATA PASSENGER ELECTRIC MOBILITY": "TATA",
        "ASHOK LEYLAND": "LEYLAND",
        "ASHOK LELYAND": "LEYLAND",
        "MAHINDRA & MAHINDRA": "MAHINDRA",
        "MAHINDRA MAHINDRA": "MAHINDRA",
        "MAHINDRA  MAHINDRA": "MAHINDRA",
        "MAHINDR & MAHINDRA": "MAHINDRA",
        "MAHINDR  MAHINDRA": "MAHINDRA",
        "MAH & MAH": "MAHINDRA",
        "MAHINDRA AND MAHINDRA": "MAHINDRA",
        "HYUNDAI MOTOR": "HYUNDAI",
        "HYUNDAIMOT": "HYUNDAI",
        "FORCE MOTORS": "FORCE",
        "HERO HONDA": "HERO",
        "HERO MOTO CORP": "HERO",
        "HERO MOTOCORP": "HERO",
        "HERO ELECTRIC": "HERO ELECTRIC",
        "HONDA MOTORCYCLE": "HONDA",
        "HONDA CARS": "HONDA",
        "HONDA SIEL CARS": "HONDA",
        "HONDA MCY": "HONDA",
        "HONDA MOTORCYCLE&SCOOTER": "HONDA",
        "HONDAMCYSC": "HONDA",
        "VOLKSWAGEN": "VOLKSWAGEN",
        "VOLKS WAGON": "VOLKSWAGEN",
        "VOLKSWAGON": "VOLKSWAGEN",
        "VOLKSWAGON AG": "VOLKSWAGEN",
        "TVS SUZUKI": "TVS",
        "TVS MOTOR": "TVS",
        "TVSMOTORCO": "TVS",
        "ROYAL-ENFIELD": "ROYAL ENFIELD",
        "ROYAL ENF": "ROYAL ENFIELD",
        "ENFIELDIND": "ROYAL ENFIELD",
        "ENFIELD": "ROYAL ENFIELD",
        "EICHER POLARIS": "EICHER",
        "EICHER MOT": "EICHER",
        "EICH TRA L": "EICHER",
        "SWARAJ MAZDA": "SWARAJ",
        "SWARAJMZD": "SWARAJ",
        "SWARAJMAZDASPRMZT": "SWARAJ",
        "TOYOTA KIRLOSKAR": "TOYOTA",
        "TOYOTAKIRL": "TOYOTA",
        "TOYOTA MATERIAL HANDLING": "TOYOTA",
        "NEW HOLLAND": "NEW HOLLAND",
        "KINETIC HONDA": "KINETIC",
        "KIN HONDA": "KINETIC",
        "KINETIC ENGINEERING": "KINETIC",
        "KINETIC MOTOR": "KINETIC",
        "PREET AGRO": "PREET",
        "PREET TRACTORS": "PREET",
        "JCB": "JCB",
        "JCBINDIA": "JCB",
        "ESCORTS KUBOTA": "ESCORTS",
        "ESCORTS JCB": "ESCORTS",
        "ESCORTS R&D": "ESCORTS",
        "ESCORTSLTD": "ESCORTS",
        "ESCORTS CONST": "ESCORTS",
        "YAMAHA MOTOR": "YAMAHA",
        "YAMAHAM": "YAMAHA",
        "INDIA YAMAHA": "YAMAHA",
        "DASMESH MECHANICAL": "DASMESH",
        "DASMESH AGRICULTURE": "DASMESH",
        "DASMESH AGRI": "DASMESH",
        "SKODA AUTO": "SKODA",
        "SKODAAUTO": "SKODA",
        "GENERAL MOTOR": "GENERAL MOTORS",
        "GENERAL MOTORS INDIA": "GENERAL MOTORS",
        "GEN MOTORS": "GENERAL MOTORS",
        "GM INDIA": "GENERAL MOTORS",
        "GM DAEWOO": "GENERAL MOTORS",
        "DAEWOO MOTORS": "DAEWOO",
        "DAEWOOMOT": "DAEWOO",
        "RENAULT NISSAN": "RENAULT-NISSAN",
        "RENAULTNISSAN": "RENAULT-NISSAN"
    }
    
    # First try direct mapping
    if maker in maker_mapping:
        return maker_mapping[maker]
    
    # Then try partial matching
    for original, replacement in maker_mapping.items():
        if original in maker:
            return replacement
    
    # Handle "OTHERS" case
    if maker in ["OTHERS", "OTHER", "NIL", "LOCAL", "UNKNOWN"]:
        return "OTHERS"
    
    # Clean up any remaining multiple spaces
    maker = re.sub(r'\s+', ' ', maker).strip()
    
    return maker

start_time = time.time()

# Load the unique makers JSON file
try:
    with open('unique_makers.json', 'r') as f:
        makers_data = json.load(f)
except Exception as e:
    print(f"Error loading unique_makers.json: {e}")
    exit(1)

print(f"Loaded {len(makers_data)} manufacturer names")

# Clean the manufacturer names
clean_makers = []
unique_clean_makers = set()

for maker in makers_data:
    clean_maker = clean_manufacturer(maker)
    clean_makers.append(clean_maker)
    unique_clean_makers.add(clean_maker)

# Create a mapping dictionary
mapping = {makers_data[i]: clean_makers[i] for i in range(len(makers_data))}

# Save the cleaned data to a new JSON file
try:
    # Save the clean makers list (same order as original)
    with open('clean_makers.json', 'w') as f:
        json.dump(clean_makers, f, indent=2)
    
    # Save the unique clean makers (sorted)
    with open('unique_clean_makers.json', 'w') as f:
        json.dump(sorted(list(unique_clean_makers)), f, indent=2)
    
    # Save the mapping of original to clean
    with open('maker_mapping.json', 'w') as f:
        json.dump(mapping, f, indent=2)
except Exception as e:
    print(f"Error saving clean_makers.json: {e}")
    exit(1)

end_time = time.time()
print(f"Cleaning completed in {end_time - start_time:.2f} seconds")
print(f"Original number of makers: {len(makers_data)}")
print(f"Number of unique clean makers: {len(unique_clean_makers)}")
print(f"Reduced by: {len(makers_data) - len(unique_clean_makers)} ({(1 - len(unique_clean_makers)/len(makers_data))*100:.1f}%)")
print(f"\nResults saved to:")
print("- clean_makers.json (cleaned list in original order)")
print("- unique_clean_makers.json (sorted unique cleaned names)")
print("- maker_mapping.json (mapping from original to clean names)")

# Display sample of original vs cleaned
print("\nSample of original vs. cleaned manufacturer names:")
for i in range(min(10, len(makers_data))):
    print(f"Original: {makers_data[i]}")
    print(f"Cleaned : {clean_makers[i]}")
    print("---")
