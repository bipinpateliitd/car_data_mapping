import json
import os
import time
import openai
import dotenv

# Load environment variables from .env file if it exists
dotenv.load_dotenv()

# Get API key from environment variables
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
if not OPENAI_API_KEY:
    print("Error: OPENAI_API_KEY not found in environment variables.")
    print("Please create a .env file with your API key or set it in your environment.")
    print("Example .env file content: OPENAI_API_KEY=your_api_key_here")
    exit(1)

# Set up OpenAI client
openai.api_key = OPENAI_API_KEY

def clean_manufacturers_in_batch(makers_list, model="gpt-4o-mini"):
    """
    Use LLM to standardize all manufacturer names in one API call
    """
    # Convert the list to a numbered list for the LLM to process
    numbered_list = "\n".join([f"{i+1}. {maker}" for i, maker in enumerate(makers_list)])
    
    try:
        print(f"Sending batch of {len(makers_list)} items to OpenAI API...")
        
        response = openai.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": """You are a specialized automotive data cleaning assistant. 
Your task is to standardize automobile manufacturer names from the given list.

For each entry in the numbered list I will provide:
1. Identify the car manufacturer
2. Return the standardized manufacturer name in uppercase
3. Ignore model details, technical specs, dealer info, etc.
4. Standardize variations (M/S MAHINDRA, MAHINDRA & MAHINDRA, etc.) to their simplest form (e.g., "MAHINDRA")
5. If you cannot identify a manufacturer, use "OTHERS"

IMPORTANT: Return your response in a valid JSON format with this structure:
{
  "1": "STANDARDIZED_NAME_1",
  "2": "STANDARDIZED_NAME_2",
  ...and so on for each item
}

Common standardized names reference:
- MARUTI (not Maruti Suzuki)
- TATA
- HYUNDAI
- MAHINDRA
- HONDA
- TOYOTA
- MERCEDES
- VOLKSWAGEN
- FORD
- ASHOK LEYLAND
- HERO
- BAJAJ
- ROYAL ENFIELD

Only output the JSON. No explanations or additional text."""},
                {"role": "user", "content": f"Please standardize these car manufacturer names:\n{numbered_list}"}
            ],
            temperature=0.0,  # Use deterministic output
            max_tokens=4000   # Increase for larger batches
        )
        
        # Extract the response
        result_text = response.choices[0].message.content.strip()
        
        # Extract just the JSON portion if there's any extra text
        json_start = result_text.find('{')
        json_end = result_text.rfind('}') + 1
        if json_start >= 0 and json_end > json_start:
            result_text = result_text[json_start:json_end]
        
        # Parse the JSON
        try:
            cleaned_dict = json.loads(result_text)
            # Convert from {"1": "MAKER", "2": "MAKER"} format to list with original order
            return [cleaned_dict.get(str(i+1), item) for i, item in enumerate(makers_list)]
        except json.JSONDecodeError as e:
            print(f"Error parsing JSON response: {e}")
            print(f"Response was: {result_text}")
            return makers_list
    except Exception as e:
        print(f"Error processing batch: {e}")
        return makers_list

# Load the unique makers JSON file
try:
    with open('unique_makers.json', 'r') as f:
        makers_data = json.load(f)
except Exception as e:
    print(f"Error loading unique_makers.json: {e}")
    exit(1)

print(f"Loaded {len(makers_data)} manufacturer names")

# Process in chunks to avoid token limits
# Adjust chunk size based on your model's token limit
start_time = time.time()

# Create unique set for processing to avoid duplicates
unique_makers = list(set(makers_data))
print(f"Found {len(unique_makers)} unique manufacturer names")

# Ask for confirmation due to potential API costs
print(f"This approach uses batch processing and will make fewer API calls.")
print(f"Using gpt-3.5-turbo, this may cost approximately $0.05-0.10 instead of $2.86")
confirmation = input("Do you want to proceed? (yes/no): ")

if confirmation.lower() not in ["yes", "y"]:
    print("Operation cancelled.")
    exit(0)

# Maximum items per batch - adjust based on token limits
max_items_per_batch = 300
total_batches = (len(unique_makers) + max_items_per_batch - 1) // max_items_per_batch

# Process in batches
clean_unique_dict = {}
for batch_num in range(total_batches):
    start_idx = batch_num * max_items_per_batch
    end_idx = min((batch_num + 1) * max_items_per_batch, len(unique_makers))
    
    print(f"Processing batch {batch_num + 1}/{total_batches} ({start_idx} to {end_idx})")
    batch = unique_makers[start_idx:end_idx]
    
    clean_batch = clean_manufacturers_in_batch(batch)
    
    # Map original to cleaned for this batch
    for i, original in enumerate(batch):
        clean_unique_dict[original] = clean_batch[i]
    
    # Wait a bit between batches to avoid rate limits
    if batch_num < total_batches - 1:
        print("Waiting 2 seconds before next batch...")
        time.sleep(2)

# Map all original names using the dictionary
clean_makers = [clean_unique_dict.get(maker, maker) for maker in makers_data]

# Count unique values after cleaning
final_unique_makers = set(clean_makers)

# Count occurrences of each manufacturer
maker_counts = {}
for maker in clean_makers:
    maker_counts[maker] = maker_counts.get(maker, 0) + 1

# Sort manufacturers by frequency
sorted_makers = sorted(maker_counts.items(), key=lambda x: x[1], reverse=True)

# Print top 50 manufacturers
print("\nTop 50 most common manufacturer names after LLM cleaning:")
for i, (maker, count) in enumerate(sorted_makers[:50]):
    print(f"{i+1}. {maker}: {count} occurrences")

# Save the cleaned data to new JSON files
try:
    # Save the clean makers list (same order as original)
    with open('batch_llm_clean_makers.json', 'w') as f:
        json.dump(clean_makers, f, indent=2)
    
    # Save the unique clean makers (sorted)
    with open('batch_llm_unique_makers.json', 'w') as f:
        json.dump(sorted(list(final_unique_makers)), f, indent=2)
    
    # Save the mapping of original to clean
    mapping = {makers_data[i]: clean_makers[i] for i in range(len(makers_data))}
    with open('batch_llm_maker_mapping.json', 'w') as f:
        json.dump(mapping, f, indent=2)
    
    # Save manufacturer frequency data
    frequency_data = [{"manufacturer": maker, "count": count} for maker, count in sorted_makers]
    with open('batch_llm_manufacturer_frequency.json', 'w') as f:
        json.dump(frequency_data, f, indent=2)
except Exception as e:
    print(f"Error saving files: {e}")
    exit(1)

end_time = time.time()
print(f"\nCleaning completed in {end_time - start_time:.2f} seconds")
print(f"Original number of makers: {len(makers_data)}")
print(f"Number of unique clean makers after LLM: {len(final_unique_makers)}")
print(f"Reduced by: {len(makers_data) - len(final_unique_makers)} ({(1 - len(final_unique_makers)/len(makers_data))*100:.1f}%)")
print(f"\nResults saved to:")
print("- batch_llm_clean_makers.json (cleaned list in original order)")
print("- batch_llm_unique_makers.json (sorted unique cleaned names)")
print("- batch_llm_maker_mapping.json (mapping from original to clean names)")
print("- batch_llm_manufacturer_frequency.json (frequency data for each manufacturer)")
