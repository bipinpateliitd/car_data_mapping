import json
import re

# The text provided by the user
csv_data = """Original,Manufacturer
0,Others
10.90 RHD F CAB DSD BS3,Eicher Trucks & Buses :contentReference[oaicite:0]{index=0}
10.90 RHD H CAB HSD BS3,Eicher Trucks & Buses :contentReference[oaicite:1]{index=1}
11.10 HD RHD G CAB & HSD BSII,Eicher Trucks & Buses :contentReference[oaicite:2]{index=2}
11.10 HD RHD H CAB & HSD BS II,Eicher Trucks & Buses :contentReference[oaicite:3]{index=3}
11.10 HD RHD H CAB & HSD BS III,Eicher Trucks & Buses :contentReference[oaicite:4]{index=4}
11.10 HD RHD H CAB & HSD BSII,Eicher Trucks & Buses :contentReference[oaicite:5]{index=5}
1616 IL/1 BSIII,Ashok Leyland :contentReference[oaicite:6]{index=6}
2516 XL  TUSKER SUPER 6X2 BSIII,Ashok Leyland :contentReference[oaicite:7]{index=7}
2518C/4 RMC DAYCAB(10.00-20;16PR) BSIV,Ashok Leyland :contentReference[oaicite:8]{index=8}
3718COWL(L10450 BSIV,Ashok Leyland :contentReference[oaicite:9]{index=9}
3718COWL(L10450) BSIV,Ashok Leyland :contentReference[oaicite:10]{index=10}
3718IL TYRE 10.00 R 20: 16 PR BSIII,Ashok Leyland :contentReference[oaicite:11]{index=11}
3DX  2WD BACKHOE LOADER BSIII,JCB :contentReference[oaicite:12]{index=12}
3EV INDUSTRIES PVT LTD,3EV Industries Pvt Ltd :contentReference[oaicite:13]{index=13}
3GB TECHNOLOGY PVT LTD,3GB Technology Pvt Ltd :contentReference[oaicite:14]{index=14}
3S INDUSTRIES PRIVATE LIMITED,3S Industries Pvt Ltd :contentReference[oaicite:15]{index=15}
5TONS 2WH TRAILER WATER TANKER IRON BODY,Others
A AND Z MOTOR CO P LTD,A & Z Motor Co. Pvt Ltd :contentReference[oaicite:16]{index=16}
A D AGRO WORKS,A D Agro Works Ltd. :contentReference[oaicite:17]{index=17}
A J S,A J S Engineering Ltd. :contentReference[oaicite:18]{index=18}"""

def convert_text_to_json(data):
    """
    Converts the provided CSV-like text with citations into a JSON object.
    """
    lines = data.strip().split('\n')
    
    # Skip header
    data_lines = lines[1:]
    
    result_dict = {}
    # Regex to find and remove the citation part
    citation_pattern = re.compile(r'\s*:contentReference\[.*?\]\{.*?\}')
    
    for line in data_lines:
        # Remove the citation part from the line
        cleaned_line = citation_pattern.sub('', line)
        
        # Split by the last comma to safely separate the original name from the manufacturer
        parts = cleaned_line.rsplit(',', 1)
        if len(parts) == 2:
            original, manufacturer = parts
            result_dict[original.strip()] = manufacturer.strip()
            
    return result_dict

# --- Main execution ---
if __name__ == "__main__":
    # Convert the data using the function
    manufacturer_mapping = convert_text_to_json(csv_data)

    # Define the output filename
    output_filename = 'manufacturer_mapping_from_text.json'
    
    # Save the resulting dictionary to a JSON file
    try:
        with open(output_filename, 'w') as f:
            json.dump(manufacturer_mapping, f, indent=2)
        print(f"Successfully created '{output_filename}' with {len(manufacturer_mapping)} entries.")
    except Exception as e:
        print(f"An error occurred while saving the file: {e}")
