import json

def create_unique_others_list():
    """
    Loads 'others_list.json', cleans up entries (e.g., stripping whitespace),
    finds the unique values, and saves them to a new file.
    """
    try:
        # Load the others_list.json file
        with open('others_list.json', 'r') as f:
            others_list = json.load(f)
        
        print(f"Loaded {len(others_list)} entries from others_list.json")

        # Clean and find unique values
        unique_others = set()
        for item in others_list:
            # Apply basic cleaning like stripping whitespace from both ends
            cleaned_item = item.strip()
            if cleaned_item: # Avoid adding empty strings
                unique_others.add(cleaned_item)

        # Convert set to a sorted list
        sorted_unique_others = sorted(list(unique_others))

        # Print the count and the list
        print(f"Found {len(sorted_unique_others)} unique entries after cleaning.")
        for i, item in enumerate(sorted_unique_others):
            print(f"{i+1}. {item}")

        # Save the unique list to new files
        with open('unique_others_list.json', 'w') as f:
            json.dump(sorted_unique_others, f, indent=2)
            
        with open('unique_others_list.txt', 'w') as f:
            for item in sorted_unique_others:
                f.write(f"{item}\n")

        print("\nResults saved to:")
        print("- unique_others_list.json")
        print("- unique_others_list.txt")

    except FileNotFoundError:
        print("Error: 'others_list.json' not found. Please run 'extract_others_list.py' first.")
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    create_unique_others_list()
