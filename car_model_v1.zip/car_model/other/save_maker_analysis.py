import json

# Load the improved clean makers file
try:
    with open('improved_clean_makers.json', 'r') as f:
        clean_makers = json.load(f)
except Exception as e:
    print(f"Error loading improved_clean_makers.json: {e}")
    exit(1)

# Count unique values
unique_makers = sorted(set(clean_makers))
maker_counts = {}
for maker in clean_makers:
    maker_counts[maker] = maker_counts.get(maker, 0) + 1

# Sort by frequency (most common first)
sorted_makers = sorted(maker_counts.items(), key=lambda x: x[1], reverse=True)

# Create analysis data dictionary
analysis_data = {
    "total_entries": len(clean_makers),
    "unique_manufacturers": len(unique_makers),
    "reduction_percentage": round((1 - len(unique_makers)/len(clean_makers))*100, 2),
    "manufacturer_counts": maker_counts,
    "top_manufacturers": [{"name": maker, "count": count} for maker, count in sorted_makers[:50]],
    "all_unique_manufacturers": unique_makers
}

# Save analysis to new JSON file
with open('manufacturer_analysis.json', 'w') as f:
    json.dump(analysis_data, f, indent=2)

# Also separately save the alphabetically sorted unique manufacturers
with open('sorted_unique_manufacturers.json', 'w') as f:
    json.dump(unique_makers, f, indent=2)

print(f"Analysis saved to manufacturer_analysis.json")
print(f"Sorted unique manufacturers saved to sorted_unique_manufacturers.json")
print(f"Total manufacturers: {len(clean_makers)}")
print(f"Unique manufacturers: {len(unique_makers)}")
print(f"Reduction: {round((1 - len(unique_makers)/len(clean_makers))*100, 2)}%")
