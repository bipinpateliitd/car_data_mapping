#!/usr/bin/env python
# FCA Vehicle Model Processing Script

import pandas as pd
import numpy as np
import re
from collections import Counter
from rapidfuzz import fuzz, process
import os

# Load the FCA dataset
fca_data = pd.read_csv('/home/bipin/Documents/kotak/car_model/manufacturer_data/FCA.csv')
print(f"Loaded {len(fca_data)} records from FCA.csv")

# Function to clean model names
def clean_model(text):
    if pd.isna(text) or text is None:
        return ""
        
    text = str(text).upper()
    
    # Remove manufacturer prefixes
    text = re.sub(r'FCA\s+INDIA\s+AUTOMOBILES\s+PRIVATE\s+LIMITED,?\s*', '', text)
    text = re.sub(r'FCA\s+INDIA\s+AUTO.?,?\s*', '', text)
    text = re.sub(r'FCA\s+INDIA.?,?\s*', '', text)
    
    # Remove FIAT prefix (but preserve it in the middle of a string)
    text = re.sub(r'^FIAT\s+', '', text)
    text = re.sub(r'FAIT', 'FIAT', text)
    
    # Fix common misspellings
    text = re.sub(r'FICA', 'FIAT', text)
    text = re.sub(r'FIAAT', 'FIAT', text)
    text = re.sub(r'AVVENT U\.', 'AVVENTURA', text)
    text = re.sub(r'AWENT U\.', 'AVVENTURA', text)
    text = re.sub(r'ADVENTURA', 'AVVENTURA', text)
    text = re.sub(r'PUNOT', 'PUNTO', text)
    text = re.sub(r'LENIA', 'LINEA', text)
    text = re.sub(r'LEINA', 'LINEA', text)
    
    # Standardize model variants
    text = re.sub(r'G\.PUNTO', 'GRANDE PUNTO', text)
    text = re.sub(r'G PUNTO', 'GRANDE PUNTO', text)
    text = re.sub(r'GRANDEPUNTO', 'GRANDE PUNTO', text)
    
    # Remove BSIII/BS III/BSIV notations (will be handled separately)
    text = re.sub(r'\bBS[-\s]*(III|IV|VI|3|4|6)\b', '', text)
    text = re.sub(r'\bBS(III|IV|VI|3|4|6)\b', '', text)
    
    # Remove special characters except for certain punctuation
    text = re.sub(r'[^\w\s\./\-]', ' ', text)
    
    # Remove extra spaces
    text = re.sub(r'\s+', ' ', text).strip()
    
    return text

# Apply cleaning to create clean_model column
fca_data['clean_model'] = fca_data['rc_maker_model'].apply(clean_model)

# Define primary FCA model keywords
fca_model_keywords = [
    # Fiat Punto models and variants
    "PUNTO", "GRANDE PUNTO", "PUNTO EVO", "PUNTO ACTIVE", "PUNTO DYNAMIC", "PUNTO EMOTION",
    
    # Fiat Linea models and variants
    "LINEA", "LINEA ACTIVE", "LINEA DYNAMIC", "LINEA EMOTION",
    
    # Fiat Avventura models
    "AVVENTURA", "AVVENTURA CROSS", "AVVENTURA EMOTION", "AVVENTURA DYNAMIC",
    
    # Fiat Palio models
    "PALIO", "PALIO STILE", "PALIO ELX",
    
    # Fiat Uno models
    "UNO", "UNO ELX", "UNO DX",
    
    # Jeep models
    "JEEP", "COMPASS", "COMPASS SPORT", "COMPASS LONGITUDE", "COMPASS LIMITED", "COMPASS LIMITED PLUS",
    
    # Abarth models
    "ABARTH", "ABARTH PUNTO", "ABARTH 595",
    
    # Engine types
    "MULTIJET", "TJCT", "TJET", "MJET", "FIRE", "EMOTION", "DYNAMIC", "ACTIVE", "SPORT",
    
    # Engine sizes
    "1.2", "1.3", "1.4", "1.6", "1.7", "1.9", "2.0",
    
    # Transmission types
    "AT", "MT", "AUTO", "MANUAL",
    
    # Trims
    "ELX", "DX", "AC", "PS", "PK", "EMO", "DI", "BSIV", "PACK"
]

# Create alias map for common abbreviations and variations
fca_alias_map = {
    # Punto variants
    "GRANDE PUNTO": "PUNTO GRANDE",
    "G PUNTO": "PUNTO GRANDE",
    "G.PUNTO": "PUNTO GRANDE",
    "PUNTO EVO": "PUNTO EVO",
    "PUNTO 1.2": "PUNTO 1.2",
    "PUNTO 1.3": "PUNTO 1.3",
    "PUNTO 1.4": "PUNTO 1.4",
    "PUNTO EMOTION": "PUNTO EMOTION",
    "PUNTO DYNAMIC": "PUNTO DYNAMIC",
    "PUNTO ACTIVE": "PUNTO ACTIVE",
    "PUNTO SPORT": "PUNTO SPORT",
    
    # Linea variants
    "LINEA 1370": "LINEA 1.4",
    "LINEA 1368": "LINEA 1.4",
    "LINEA 1.4": "LINEA 1.4",
    "LINEA EMOTION": "LINEA EMOTION",
    "LINEA DYNAMIC": "LINEA DYNAMIC",
    "LINEA ACTIVE": "LINEA ACTIVE",
    "LINEA MULTIJET": "LINEA DIESEL",
    
    # Avventura variants
    "AVVENTURA 1.3": "AVVENTURA DIESEL",
    "AVVENTURA EMOTION": "AVVENTURA EMOTION",
    "AVVENTURA DYNAMIC": "AVVENTURA DYNAMIC",
    "AVVENTURA ACTIVE": "AVVENTURA ACTIVE",
    "AVVENTURA CROSS": "AVVENTURA CROSS",
    "AVVENTURA FIRE": "AVVENTURA PETROL",
    "AVVENTURA MJET": "AVVENTURA DIESEL",
    "AVVENTURA MULTIJET": "AVVENTURA DIESEL",
    
    # Palio variants
    "PALIO STILE": "PALIO STILE",
    "PALIO ELX": "PALIO ELX",
    "PALIO 1.2": "PALIO 1.2",
    "PALIO 1.6": "PALIO 1.6",
    "PALIO 1.9 D": "PALIO DIESEL",
    
    # Uno variants
    "UNO ELX": "UNO ELX",
    "UNO DX": "UNO DX",
    
    # Jeep variants
    "JEEP COMPASS": "COMPASS",
    "COMPASS SPORT": "COMPASS SPORT",
    "COMPASS LONGITUDE": "COMPASS LONGITUDE", 
    "COMPASS LIMITED": "COMPASS LIMITED",
    "COMPASS LIMITED PLUS": "COMPASS LIMITED PLUS",
    "COMPASS MAIR": "COMPASS PETROL",
    "COMPASS 2.0 D": "COMPASS DIESEL",
    "COMPASS 2.0": "COMPASS DIESEL",
    "COMPASS 1.4": "COMPASS PETROL",
    "COMPASS AT": "COMPASS AUTO",
    "COMPASS 4X4": "COMPASS 4X4",
    
    # Abarth variants
    "ABARTH PUNTO": "ABARTH PUNTO",
    "ABARTH 595": "ABARTH 595",
    "PUNTO T JET": "ABARTH PUNTO",
    "595 T JET": "ABARTH 595",
    
    # Engine types
    "MULTIJET": "DIESEL",
    "MJET": "DIESEL",
    "MJCT": "DIESEL",
    "FIRE": "PETROL",
    "TJET": "TURBO PETROL",
    "T JET": "TURBO PETROL",
    
    # Trim levels
    "EMOTION PK": "EMOTION PACK",
    "EMOTION PACK": "EMOTION PACK",
    "DI EM PK": "DIESEL EMOTION PACK",
    "DI EMOTION": "DIESEL EMOTION",
    
    # Emission Standards
    "BS-III": "BS3",
    "BS-IV": "BS4",
    "BS-VI": "BS6",
    "BSIII": "BS3",
    "BSIV": "BS4",
    "BSVI": "BS6"
}

# Function to normalize model names using the alias map
def normalize(text, alias_map):
    """Normalize model names using an alias map"""
    words = text.split()
    normalized_words = []
    
    i = 0
    while i < len(words):
        # Try to match multi-word phrases (up to 3 words)
        matched = False
        for n_words in [3, 2, 1]:
            if i + n_words <= len(words):
                phrase = " ".join(words[i:i+n_words])
                if phrase in alias_map:
                    normalized_words.extend(alias_map[phrase].split())
                    i += n_words
                    matched = True
                    break
        
        if not matched:
            normalized_words.append(words[i])
            i += 1
    
    return " ".join(normalized_words)

# Function to extract standardized FCA model name from cleaned text
def extract_fca_model(text):
    """Extract standardized FCA model name from cleaned text"""
    if pd.isna(text) or not text:
        return "FCA OTHER"
    
    # Normalize the text using the alias map
    normalized = normalize(text, fca_alias_map)
    
    # Check for Abarth models first (distinct performance sub-brand)
    if "ABARTH" in normalized:
        if "595" in normalized:
            return "ABARTH 595"
        elif "PUNTO" in normalized:
            return "ABARTH PUNTO"
        else:
            return "ABARTH OTHER"
    
    # Check for Jeep Compass variants
    if "COMPASS" in normalized:
        if "SPORT" in normalized:
            return "JEEP COMPASS SPORT"
        elif "LONGITUDE" in normalized:
            return "JEEP COMPASS LONGITUDE"
        elif "LIMITED PLUS" in normalized:
            return "JEEP COMPASS LIMITED PLUS"
        elif "LIMITED" in normalized:
            return "JEEP COMPASS LIMITED"
        else:
            return "JEEP COMPASS"
    
    # Check for Fiat Punto variants
    if "PUNTO" in normalized:
        if "EVO" in normalized:
            return "FIAT PUNTO EVO"
        elif "GRANDE" in normalized:
            return "FIAT GRANDE PUNTO"
        else:
            return "FIAT PUNTO"
    
    # Check for Fiat Linea
    if "LINEA" in normalized:
        return "FIAT LINEA"
    
    # Check for Fiat Avventura
    if "AVVENTURA" in normalized:
        return "FIAT AVVENTURA"
    
    # Check for Fiat Palio
    if "PALIO" in normalized:
        if "STILE" in normalized:
            return "FIAT PALIO STILE"
        else:
            return "FIAT PALIO"
    
    # Check for Fiat Uno
    if "UNO" in normalized:
        return "FIAT UNO"
    
    # If no direct match, try fuzzy matching
    best_match = None
    best_score = 0
    
    for keyword in fca_model_keywords:
        if len(keyword) > 3:  # Skip short keywords
            score = fuzz.partial_ratio(keyword, normalized)
            if score > best_score and score >= 85:  # 85% match threshold
                best_score = score
                
                # Special handling for major model groups
                if keyword in ["PUNTO", "GRANDE PUNTO", "PUNTO EVO"]:
                    if "EVO" in keyword:
                        best_match = "FIAT PUNTO EVO"
                    elif "GRANDE" in keyword:
                        best_match = "FIAT GRANDE PUNTO"
                    else:
                        best_match = "FIAT PUNTO"
                elif keyword == "LINEA":
                    best_match = "FIAT LINEA"
                elif keyword == "AVVENTURA":
                    best_match = "FIAT AVVENTURA"
                elif keyword == "PALIO":
                    best_match = "FIAT PALIO"
                elif keyword == "UNO":
                    best_match = "FIAT UNO"
                elif keyword in ["COMPASS", "JEEP"]:
                    best_match = "JEEP COMPASS"
                elif keyword in ["ABARTH"]:
                    best_match = "ABARTH OTHER"
                else:
                    best_match = f"FCA {keyword}"
    
    return best_match if best_match else "FCA OTHER"

# Apply normalization to get normalized_model column
fca_data['normalized_model'] = fca_data['clean_model'].apply(lambda x: normalize(x, fca_alias_map))

# Apply model extraction to get fca_model column
fca_data['fca_model'] = fca_data['normalized_model'].apply(extract_fca_model)

# Set final model (same as fca_model in this case)
fca_data['final_model'] = fca_data['fca_model']

# Create a mapping dataframe for analysis
mapping_df = fca_data.groupby(['clean_model', 'final_model']).size().reset_index().rename(columns={0: 'count'})
mapping_df = mapping_df.sort_values(['final_model', 'count'], ascending=[True, False])

# Save the processed data and mapping
os.makedirs('/home/bipin/Documents/kotak/car_model/clean_model/', exist_ok=True)

# Save processed data
output_file = '/home/bipin/Documents/kotak/car_model/clean_model/fca_processed.csv'
fca_data.to_csv(output_file, index=False)
print(f"\nProcessed data saved to {output_file}")

# Save mapping file
mapping_file = '/home/bipin/Documents/kotak/car_model/clean_model/fca_model_mapping.csv'
mapping_df.to_csv(mapping_file, index=False)
print(f"Model mapping saved to {mapping_file}")

# Print summary statistics
total_models = len(fca_data)
mapped_models = fca_data[fca_data['final_model'] != 'FCA OTHER'].shape[0]
mapping_rate = (mapped_models / total_models) * 100

print("\nSummary Statistics:")
print(f"Total models: {total_models}")
print(f"Successfully mapped models: {mapped_models}")
print(f"Mapping rate: {mapping_rate:.2f}%")

# Count models by category
model_counts = fca_data['final_model'].value_counts()
print("\nModel distribution:")
for model, count in model_counts.items():
    percentage = (count / total_models) * 100
    print(f"{model}: {count} ({percentage:.2f}%)")
