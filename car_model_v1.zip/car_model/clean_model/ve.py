import pandas as pd
import re
import numpy as np
from collections import Counter
from rapidfuzz import fuzz, process

# Load the VE CSV file
ve_data = pd.read_csv('/home/bipin/Documents/kotak/car_model/manufacturer_data/VE.csv')
print(f"Loaded {len(ve_data)} records from VE.csv")
ve_data.head()

# Function to clean and normalize model names
def clean_model(text):
    if pd.isna(text) or text is None:
        return ""
    # Convert to string
    text = str(text).upper()
    # Remove common prefixes and company names
    text = re.sub(r'VE\s+COMMERCIAL\s+VEHICLES\s+LTD\.?,?\s*', '', text)
    text = re.sub(r'VE\s+COMMERCIAL\s+VEHICLES\s+LIMITED,?\s*', '', text)
    text = re.sub(r'V\s*E\s+COMMERCIAL\s+VEHICLE\s+LTD\.?,?\s*', '', text)
    text = re.sub(r'\"', '', text)
    text = re.sub(r'"VE\s+COMMERCIAL\s+VEHICLES\s+LTD,?\s*', '', text)
    text = re.sub(r'VE\s+COMMERCIAL\s+VEHI,?\s*', '', text)
    text = re.sub(r',', '', text)
    
    # Remove special characters and extra spaces
    text = re.sub(r'[^\w\s\./\-]', ' ', text)  # Keep ., /, and -
    text = re.sub(r'\s+', ' ', text).strip()
    return text

# Create a list of cleaned model names
ve_data['clean_model'] = ve_data['rc_maker_model'].apply(clean_model)

# Filter out too generic or empty model names
generic_terms = ['LIMITED', 'LTD', 'NOT AVAILABLE', 'OTHER', 'Not Available', 'HGV', 'TIPPER']
filtered_models = ve_data['clean_model'].apply(
    lambda x: x if x and all(term not in x.split() for term in generic_terms) else np.nan
)

# Count model name frequencies
model_counts = Counter([m for models in filtered_models.dropna() for m in models.split()])
model_counts = {k: v for k, v in model_counts.items() if v >= 3}  # Keep only somewhat frequent terms

# Print top model keywords by frequency
print("\nTop model keywords by frequency:")
sorted_counts = sorted(model_counts.items(), key=lambda x: x[1], reverse=True)
for model, count in sorted_counts[:30]:
    print(f"{model}: {count}")

# Define primary VE model keywords
ve_model_keywords = [
    # PRO Series
    "PRO 1049", "PRO 1055", "PRO 1059", "PRO 1075", "PRO 1080", "PRO 1090",
    "PRO 1095", "PRO 1110", "PRO 1114", "PRO 2049", "PRO 2055", "PRO 2059", 
    "PRO 2075", "PRO 2080", "PRO 2095", "PRO 2110", "PRO 2114", "PRO 2118", "PRO 2119",
    "PRO 3008", "PRO 3009", "PRO 3010", "PRO 3012", "PRO 3014", "PRO 3015", "PRO 3016", 
    "PRO 3018", "PRO 3019", "PRO 5016", "PRO 5025", "PRO 5031", "PRO 5035",
    "PRO 6025", "PRO 6028", "PRO 6031", "PRO 6035", "PRO 6037", "PRO 6040", 
    "PRO 6042", "PRO 6048", "PRO 6055", "PRO 8025",
    
    # Number Series Models
    "10.49", "10.50", "10.59", "10.75", "10.80", "10.90", "10.95", 
    "11.10", "11.12", "11.14", "20.15", "20.16", "30.25", "35.31",
    
    # Numeric Models
    "1049", "1050", "1055", "1059", "1075", "1080", "1090", "1095", 
    "1110", "1114", "2049", "2050", "2055", "2059", "2065", "2075", 
    "2080", "2090", "2095", "2110", "2114", "2118", "2119",
    "3008", "3009", "3010", "3012", "3014", "3015", "3016", "3018", "3019",
    "4035", "4040", "5016", "5025", "5031", "5035",
    "6025", "6028", "6031", "6035", "6037", "6040", "6042", "6048", "6055", 
    
    # Series Names
    "EICHER", "SKYLINE", "GALAXY", "HERCULES", "TERRA",
    
    # Type Identifiers
    "XP", "FE", 
    
    # Vehicle Types
    "BUS", "TRUCK", "TIPPER",
    
    # Body Types
    "CAB", "CBC", "CHASSIS", "CWC", "HSD", "FSD", "DSD", "COWL",
    
    # Configurations
    "CNG", "BSIII", "BSIV", "BSVI", "BS3", "BS4", "BS6", "RHD", "PS", 
    
    # Features
    "SLEEPER", "STARLINE", "SELF", "SLP"
]

# Create alias map for common abbreviations and variations
ve_alias_map = {
    # Model Aliases
    "PRO1049": "PRO 1049",
    "PRO1055": "PRO 1055",
    "PRO1059": "PRO 1059", 
    "PRO1075": "PRO 1075",
    "PRO1080": "PRO 1080",
    "PRO1090": "PRO 1090",
    "PRO1095": "PRO 1095", 
    "PRO1110": "PRO 1110",
    "PRO1114": "PRO 1114",
    "PRO2049": "PRO 2049",
    "PRO2055": "PRO 2055",
    "PRO2059": "PRO 2059", 
    "PRO2075": "PRO 2075",
    "PRO2080": "PRO 2080",
    "PRO2095": "PRO 2095",
    "PRO2110": "PRO 2110",
    "PRO2114": "PRO 2114",
    "PRO2118": "PRO 2118", 
    "PRO2119": "PRO 2119",
    "PRO3008": "PRO 3008",
    "PRO3009": "PRO 3009",
    "PRO3010": "PRO 3010",
    "PRO3012": "PRO 3012",
    "PRO3014": "PRO 3014",
    "PRO3015": "PRO 3015",
    "PRO3016": "PRO 3016",
    "PRO3018": "PRO 3018", 
    "PRO3019": "PRO 3019",
    "PRO5016": "PRO 5016",
    "PRO5025": "PRO 5025",
    "PRO5031": "PRO 5031",
    "PRO5035": "PRO 5035",
    "PRO6025": "PRO 6025",
    "PRO6028": "PRO 6028",
    "PRO6031": "PRO 6031",
    "PRO6035": "PRO 6035",
    "PRO6037": "PRO 6037",
    "PRO6040": "PRO 6040",
    "PRO6042": "PRO 6042",
    "PRO6048": "PRO 6048",
    "PRO6055": "PRO 6055",
    "PRO8025": "PRO 8025",
    
    # Series Aliases
    "POR": "PRO",
    "ECHR": "EICHER",
    "EISH": "EICHER",
    "EICH": "EICHER",
    "ECHER": "EICHER",
    
    # Body Type Aliases
    "CAB&HSD": "CAB HSD",
    "CAB & HSD": "CAB HSD",
    "CAB&CHASSIS": "CAB CHASSIS",
    "CAB & CHASSIS": "CAB CHASSIS",
    "CABCHASS": "CAB CHASSIS",
    "CABCHS": "CAB CHASSIS",
    "CABIN": "CAB",
    "CABCHASS": "CAB CHASSIS",
    "CABCHS": "CAB CHASSIS",
    "CABHSD": "CAB HSD",
    "CAP": "CAB",
    
    # Feature Aliases
    "SLPCAB": "SLEEPER CAB",
    "SLPCABHSD": "SLEEPER CAB HSD",
    "SLPCABCHS": "SLEEPER CAB CHASSIS",
    "SLF": "SELF",
    
    # Configuration Aliases
    "BSIII": "BS3",
    "BSIV": "BS4",
    "BSVI": "BS6",
    "BS-III": "BS3",
    "BS-IV": "BS4",
    "BS-VI": "BS6"
}

# Function to normalize text
def normalize(text):
    # Handle NaN/None values or any non-string types
    if pd.isna(text) or text is None:
        return ""
    # Convert to string if it's not already a string
    if not isinstance(text, str):
        text = str(text)
    # Then proceed with normalization
    return re.sub(r'[^A-Z0-9 \.]', '', text.upper())

# Function to extract VE model
def extract_ve_model(text):
    txt = normalize(text)
    
    # Skip entries that clearly aren't VE commercial vehicles
    if pd.isna(text) or text is None or text == "":
        return "NOT FOUND"
    
    # Fix aliases (correct misspellings and abbreviations)
    for bad, good in ve_alias_map.items():
        if bad in txt:
            txt = txt.replace(bad, good)
    
    # First check for models with PRO prefix
    pro_pattern = r'PRO\s+(\d{4})([A-Z]*)'
    pro_match = re.search(pro_pattern, txt)
    if pro_match:
        base_model = f"PRO {pro_match.group(1)}"
        suffix = pro_match.group(2)
        
        # Check if it's an XP variant
        if "XP" in txt:
            base_model = f"{base_model}XP"
        
        # Check for model variations by suffix
        if suffix:
            return f"{base_model} {suffix}"
        else:
            return base_model
    
    # Check for numeric models (10.xx, 11.xx, etc.)
    num_pattern = r'(\d{1,2}\.\d{2})([A-Z]*)'
    num_match = re.search(num_pattern, txt)
    if num_match:
        base_model = num_match.group(1)
        suffix = num_match.group(2)
        
        # Check if it's an XP variant
        if "XP" in txt:
            base_model = f"{base_model}XP"
        
        # Check for model variations by suffix
        if suffix:
            return f"{base_model} {suffix}"
        else:
            return base_model
    
    # Check for pure numeric models without decimal
    pure_num_pattern = r'(\d{4})([A-Z]*)'
    pure_num_match = re.search(pure_num_pattern, txt)
    if pure_num_match:
        base_model = pure_num_match.group(1)
        suffix = pure_num_match.group(2)
        
        # Special case for 30.25, 35.31, etc.
        if base_model.startswith("30"):
            return f"30.25{' '+suffix if suffix else ''}"
        if base_model.startswith("35"):
            return f"35.31{' '+suffix if suffix else ''}"
            
        # Check for other specific model types
        if "XP" in txt:
            base_model = f"{base_model}XP"
        
        # Check for model variations by suffix
        if suffix:
            return f"{base_model} {suffix}"
        else:
            return base_model
    
    # Look for specific named models
    if "SKYLINE" in txt:
        return "SKYLINE"
    
    if "GALAXY" in txt:
        return "GALAXY"
        
    if "TERRA" in txt:
        return "TERRA"
    
    # Check for any keywords from our list
    for keyword in sorted(ve_model_keywords, key=len, reverse=True):
        if keyword in txt:
            return keyword
    
    # If nothing matches, use fuzzy matching as fallback
    try:
        # Use rapidfuzz for fuzzy matching
        result = process.extractOne(txt, ve_model_keywords, scorer=fuzz.token_set_ratio)
        if result and result[1] >= 80:  # if similarity score is at least 80%
            return result[0]
    except Exception:
        # If rapidfuzz isn't available or fails, we'll just continue
        pass
    
    return "NOT FOUND"

# Apply the extraction to the dataset
ve_data['ve_model'] = ve_data['rc_maker_model'].apply(extract_ve_model)

# Count the frequency of each extracted model
model_distribution = ve_data['ve_model'].value_counts()
print("\nExtracted model distribution:")
print(model_distribution.head(20))

# Create final model column with fallback logic
ve_data['final_model'] = ve_data['ve_model']
ve_data.loc[ve_data['final_model'] == "NOT FOUND", 'final_model'] = "VE OTHER"

# Save the processed data
ve_data.to_csv('/home/bipin/Documents/kotak/car_model/clean_model/ve_processed.csv', index=False)

# Save the model mapping for verification and record
model_mapping = pd.DataFrame({
    'original_model': ve_data['rc_maker_model'].unique()
})
model_mapping['cleaned_model'] = model_mapping['original_model'].apply(clean_model)
model_mapping['extracted_model'] = model_mapping['original_model'].apply(extract_ve_model)
model_mapping['final_model'] = model_mapping['extracted_model']
model_mapping.loc[model_mapping['final_model'] == "NOT FOUND", 'final_model'] = "VE OTHER"

model_mapping.to_csv('/home/bipin/Documents/kotak/car_model/clean_model/ve_model_mapping.csv', index=False)

print("\nProcessing complete. Files saved:")
print("1. Processed data: ve_processed.csv")
print("2. Model mapping: ve_model_mapping.csv")

# Print some statistics
print(f"\nTotal records: {len(ve_data)}")
print(f"Unique original models: {len(ve_data['rc_maker_model'].unique())}")
print(f"Unique extracted models: {len(ve_data['ve_model'].unique())}")
print(f"Records mapped to known models: {(ve_data['ve_model'] != 'NOT FOUND').sum()}")
print(f"Records not mapped (VE OTHER): {(ve_data['ve_model'] == 'NOT FOUND').sum()}")
print(f"Mapping success rate: {(ve_data['ve_model'] != 'NOT FOUND').sum() / len(ve_data) * 100:.2f}%")
