import pandas as pd
import re
import numpy as np
from collections import Counter
from rapidfuzz import fuzz, process

# Load the VOLKSWAGEN CSV file
vw_data = pd.read_csv('/home/bipin/Documents/kotak/car_model/manufacturer_data/VOLKSWAGEN.csv')
print(f"Loaded {len(vw_data)} records from VOLKSWAGEN.csv")
vw_data.head()

# Function to clean and normalize model names
def clean_model(text):
    if pd.isna(text) or text is None:
        return ""
    # Convert to string
    text = str(text).upper()
    # Remove common prefixes and company names
    text = re.sub(r'VOLKSWAGEN\s+INDIA\s+PVT\s+LTD\.?,?\s*', '', text)
    text = re.sub(r'VOLKSWAGEN\s+INDIA\s+PRIVATE\s+LIMITED,?\s*', '', text)
    text = re.sub(r'VOLKSWAGEN\s+AG\s*', '', text)
    text = re.sub(r'VOLKSWAGON\s+AG\s*', '', text)  # Common misspelling
    text = re.sub(r'VOLKSWAGON\s*', '', text)  # Common misspelling
    text = re.sub(r'\"', '', text)
    text = re.sub(r'"VOLKSWAGEN\s+INDIA\s+PVT\s+LTD,?\s*', '', text)
    text = re.sub(r',', '', text)
    text = re.sub(r'M/S\.SKODA\s+AUTO\s+VOLKSWAGEN\s+INDIA\s+PRIVATE\s+LIMITED\s*', '', text)
    
    # Remove special characters and extra spaces
    text = re.sub(r'[^\w\s\./\-]', ' ', text)  # Keep ., /, and -
    text = re.sub(r'\s+', ' ', text).strip()
    return text


# Create a list of cleaned model names
vw_data['clean_model'] = vw_data['rc_maker_model'].apply(clean_model)

# Filter out too generic or empty model names
generic_terms = ['LIMITED', 'LTD', 'NOT AVAILABLE', 'OTHER', 'Not Available', 'PASSENGER CAR']
filtered_models = vw_data['clean_model'].apply(
    lambda x: x if x and all(term not in x.split() for term in generic_terms) else np.nan
)

# Count model name frequencies
model_counts = Counter([m for models in filtered_models.dropna() for m in models.split()])
model_counts = {k: v for k, v in model_counts.items() if v >= 3}  # Keep only somewhat frequent terms

# Print top model keywords by frequency
print("\nTop model keywords by frequency:")
sorted_counts = sorted(model_counts.items(), key=lambda x: x[1], reverse=True)
for model, count in sorted_counts[:30]:
    print(f"{model}: {count}")

# Define primary VW model keywords
vw_model_keywords = [
    # Main Models
    "POLO", "VENTO", "AMEO", "JETTA", "PASSAT", "TIGUAN", "BEETLE", "TOUAREG", "TAIGUN",
    
    # Polo Variants
    "POLO GT", "POLO GTI", "CROSS POLO",
    
    # Engine Types
    "MPI", "TDI", "TSI", "CRTDI", "ITSI",
    
    # Engine Sizes
    "1.0", "1.0L", "1.2", "1.2L", "1.4", "1.4L", "1.5", "1.5L", "1.6", "1.6L", "1.8", "1.8L", "2.0", "2.0L", "3.0", "3.0L",
    
    # Trims
    "TRENDLINE", "COMFORTLINE", "HIGHLINE", "HIGHLINE PLUS", "COMFL", "HIGHLINE+", "HL", "CL", "TL", "TDI",
    
    # Transmission
    "MT", "AT", "DSG", "TIPTRONIC",
    
    # Emission Standards
    "BS3", "BS4", "BS6", "BSIII", "BSIV", "BSVI", "BS-III", "BS-IV", "BS-VI",
    
    # Features/Packages
    "ALL STAR", "PLUS", "GP", "L4390"
]

# Create alias map for common abbreviations and variations
vw_alias_map = {
    # Model Name Normalization
    "V W": "VW",
    "V.W.": "VW",
    "V-W": "VW",
    "VOL.": "VOLKSWAGEN",
    "VOLKSWAGON": "VOLKSWAGEN",
    "VW-": "VW ",
    "VW.": "VW",
    "VWPOLO": "VW POLO",
    "VWVENTO": "VW VENTO",
    "VWAMEO": "VW AMEO",
    "VWJETTA": "VW JETTA",
    "VWPASSAT": "VW PASSAT",
    "VWTIGUAN": "VW TIGUAN",
    "VWBEETLE": "VW BEETLE",
    "VWTOUAREG": "VW TOUAREG",
    "VWTAIGUN": "VW TAIGUN",
    "VVENTO": "VENTO",
    
    # Model Variants
    "POLO1.0": "POLO 1.0",
    "POLO1.2": "POLO 1.2",
    "POLO1.5": "POLO 1.5",
    "POLO1.6": "POLO 1.6",
    "VENTO1.2": "VENTO 1.2",
    "VENTO1.5": "VENTO 1.5",
    "VENTO1.6": "VENTO 1.6",
    "AMEO1.2": "AMEO 1.2",
    "AMEO1.5": "AMEO 1.5",
    "JETTA1.4": "JETTA 1.4",
    "JETTA1.9": "JETTA 1.9",
    "JETTA2.0": "JETTA 2.0",
    
    # Trim Levels
    "COMFERTLINE": "COMFORTLINE",
    "COMFIRT": "COMFORT",
    "COMF": "COMFORTLINE",
    "COMFL": "COMFORTLINE",
    "COMFOR": "COMFORT",
    "COMFORLINEM1": "COMFORTLINE",
    "COMFORT LINE": "COMFORTLINE",
    "CMFRTLI N": "COMFORTLINE",
    "CMFTLIN": "COMFORTLINE",
    "HIGHLI": "HIGHLINE",
    "HIGHL": "HIGHLINE",
    "HIGHLIN": "HIGHLINE",
    "HIGHLINE+": "HIGHLINE PLUS",
    "HIGHLINEPLUS": "HIGHLINE PLUS",
    "TRADELINE": "TRENDLINE",
    "TREDLINE": "TRENDLINE",
    "TRENDLI N": "TRENDLINE",
    "H LINE": "HIGHLINE",
    "H/LINE": "HIGHLINE",
    "H/L": "HIGHLINE",
    "H L": "HIGHLINE",
    "C LINE": "COMFORTLINE",
    "C/LINE": "COMFORTLINE",
    "C/L": "COMFORTLINE",
    "C L": "COMFORTLINE",
    "T LINE": "TRENDLINE",
    "T/LINE": "TRENDLINE",
    "T/L": "TRENDLINE",
    "T L": "TRENDLINE",
    
    # Transmission Types
    "M/T": "MT",
    "A/T": "AT",
    "M.T": "MT",
    "A.T": "AT",
    "(MT)": "MT",
    "(AT)": "AT",
    "MT-": "MT ",
    "AT-": "AT ",
    
    # Engine Types
    "DISEL": "DIESEL",
    "DIESEL": "TDI",
    "PETROL": "MPI",
    "PETRO": "MPI",
    
    # Emission Standards
    "BS-III": "BS3",
    "BS-IV": "BS4",
    "BS-VI": "BS6",
    "BSIII": "BS3",
    "BSIV": "BS4",
    "BSVI": "BS6"
}


def normalize(text):
    if pd.isna(text) or text == "":
        return ""
    
    # Apply alias replacements
    result = text
    for alias, replacement in vw_alias_map.items():
        result = re.sub(r'\b' + re.escape(alias) + r'\b', replacement, result)
    
    return result

# Function to extract VW model
def extract_vw_model(text):
    if pd.isna(text) or text is None:
        return "NOT FOUND"
        
    # Clean and normalize the text
    txt = clean_model(text)
    txt = normalize(txt)
    
    # Check for anomalous entries
    if len(txt) <= 1 or txt.isdigit():
        return "NOT FOUND"
    
    # Handle special case - Audi models that appear in VW data
    if "AUDI" in txt:
        match = re.search(r'AUDI\s+([A-Z0-9]+)', txt)
        if match:
            return f"AUDI {match.group(1)}"
        else:
            return "AUDI"
    
    # Extract main model first (Polo, Vento, Ameo, Jetta, etc.)
    main_models = ["POLO", "VENTO", "AMEO", "JETTA", "PASSAT", "TIGUAN", "BEETLE", "TOUAREG", "TAIGUN"]
    
    model_base = None
    for model in main_models:
        if model in txt:
            model_base = model
            break
    
    if model_base is None:
        # No main model found - try fuzzy matching
        try:
            result = process.extractOne(txt, main_models, scorer=fuzz.token_set_ratio)
            if result and result[1] >= 80:  # if similarity score is at least 80%
                model_base = result[0]
            else:
                return "NOT FOUND"
        except Exception:
            return "NOT FOUND"
    
    # Now extract model details based on the base model
    if model_base == "POLO":
        # Handle special Polo variants
        if "GTI" in txt:
            return "POLO GTI"
        elif "GT TSI" in txt:
            return "POLO GT TSI"
        elif "CROSS POLO" in txt or "CROSSPOLO" in txt:
            return "CROSS POLO"
        
        # Extract engine type for Polo
        engine_type = None
        for eng in ["TDI", "MPI", "TSI"]:
            if eng in txt:
                engine_type = eng
                break
        
        # Extract engine size for Polo
        engine_size = None
        size_pattern = r'(1\.0L?|1\.2L?|1\.5L?|1\.6L?)'
        size_match = re.search(size_pattern, txt)
        if size_match:
            engine_size = size_match.group(1)
        
        # Extract trim level for Polo
        trim = None
        for t in ["TRENDLINE", "COMFORTLINE", "HIGHLINE", "HIGHLINE PLUS"]:
            if t in txt:
                trim = t
                break
        
        # Construct model identifier
        if engine_size and engine_type:
            if trim:
                return f"POLO {engine_size} {engine_type} {trim}"
            else:
                return f"POLO {engine_size} {engine_type}"
        elif engine_size:
            if trim:
                return f"POLO {engine_size} {trim}"
            else:
                return f"POLO {engine_size}"
        else:
            return "POLO"
            
    elif model_base == "VENTO":
        # Extract engine type for Vento
        engine_type = None
        for eng in ["TDI", "MPI", "TSI", "CR"]:
            if eng in txt:
                engine_type = eng
                break
        
        # Extract engine size for Vento
        engine_size = None
        size_pattern = r'(1\.2L?|1\.5L?|1\.6L?)'
        size_match = re.search(size_pattern, txt)
        if size_match:
            engine_size = size_match.group(1)
        
        # Extract transmission type
        transmission = None
        if "AT" in txt.split() or "DSG" in txt:
            transmission = "AT"
        elif "MT" in txt.split():
            transmission = "MT"
        
        # Extract trim level for Vento
        trim = None
        for t in ["TRENDLINE", "COMFORTLINE", "HIGHLINE", "HIGHLINE PLUS"]:
            if t in txt:
                trim = t
                break
        
        # Construct model identifier
        if engine_size and engine_type:
            if transmission and trim:
                return f"VENTO {engine_size} {engine_type} {transmission} {trim}"
            elif transmission:
                return f"VENTO {engine_size} {engine_type} {transmission}"
            elif trim:
                return f"VENTO {engine_size} {engine_type} {trim}"
            else:
                return f"VENTO {engine_size} {engine_type}"
        elif engine_size:
            if trim:
                return f"VENTO {engine_size} {trim}"
            else:
                return f"VENTO {engine_size}"
        else:
            return "VENTO"
    
    elif model_base == "AMEO":
        # Extract engine type for Ameo
        engine_type = None
        for eng in ["TDI", "MPI"]:
            if eng in txt:
                engine_type = eng
                break
        
        # Extract engine size for Ameo
        engine_size = None
        size_pattern = r'(1\.0L?|1\.2L?|1\.5L?)'
        size_match = re.search(size_pattern, txt)
        if size_match:
            engine_size = size_match.group(1)
        
        # Extract transmission type
        transmission = None
        if "AT" in txt.split() or "DSG" in txt:
            transmission = "AT"
        elif "MT" in txt.split():
            transmission = "MT"
        
        # Extract trim level for Ameo
        trim = None
        for t in ["TRENDLINE", "COMFORTLINE", "HIGHLINE"]:
            if t in txt:
                trim = t
                break
        
        # Construct model identifier
        if engine_size:
            if engine_type and trim and transmission:
                return f"AMEO {engine_size} {engine_type} {transmission} {trim}"
            elif engine_type and trim:
                return f"AMEO {engine_size} {engine_type} {trim}"
            elif engine_type:
                return f"AMEO {engine_size} {engine_type}"
            else:
                return f"AMEO {engine_size}"
        else:
            return "AMEO"
            
    elif model_base == "JETTA":
        # Extract engine size for Jetta
        engine_size = None
        size_pattern = r'(1\.4L?|1\.9L?|2\.0L?)'
        size_match = re.search(size_pattern, txt)
        if size_match:
            engine_size = size_match.group(1)
        
        # Extract engine type
        engine_type = None
        for eng in ["TDI", "TSI", "CRTDI"]:
            if eng in txt:
                engine_type = eng
                break
        
        # Extract transmission type
        transmission = None
        if "AT" in txt.split() or "DSG" in txt:
            transmission = "AT"
        elif "MT" in txt.split():
            transmission = "MT"
            
        # Extract trim level
        trim = None
        for t in ["TRENDLINE", "COMFORTLINE", "HIGHLINE"]:
            if t in txt:
                trim = t
                break
                
        # Construct model identifier
        if engine_size:
            if engine_type and trim and transmission:
                return f"JETTA {engine_size} {engine_type} {transmission} {trim}"
            elif engine_type and transmission:
                return f"JETTA {engine_size} {engine_type} {transmission}"
            elif engine_type:
                return f"JETTA {engine_size} {engine_type}"
            else:
                return f"JETTA {engine_size}"
        else:
            return "JETTA"
    
    # For other models, just return the base model name since they are less frequent
    return model_base

    # Apply the extraction to the dataset
vw_data['vw_model'] = vw_data['rc_maker_model'].apply(extract_vw_model)

# Count the frequency of each extracted model
model_distribution = vw_data['vw_model'].value_counts()
print("\nExtracted model distribution:")
print(model_distribution.head(20))

# Create final model column with fallback logic
vw_data['final_model'] = vw_data['vw_model']
vw_data.loc[vw_data['final_model'] == "NOT FOUND", 'final_model'] = "VW OTHER"

# Save the processed data
vw_data.to_csv('/home/bipin/Documents/kotak/car_model/clean_model/vw_processed.csv', index=False)

# Save the model mapping for verification and record
model_mapping = pd.DataFrame({
    'original_model': vw_data['rc_maker_model'].unique()
})
model_mapping['cleaned_model'] = model_mapping['original_model'].apply(clean_model)
model_mapping['extracted_model'] = model_mapping['original_model'].apply(extract_vw_model)
model_mapping['final_model'] = model_mapping['extracted_model']
model_mapping.loc[model_mapping['final_model'] == "NOT FOUND", 'final_model'] = "VW OTHER"

model_mapping.to_csv('/home/bipin/Documents/kotak/car_model/clean_model/vw_model_mapping.csv', index=False)

print("\nProcessing complete. Files saved:")
print("1. Processed data: vw_processed.csv")
print("2. Model mapping: vw_model_mapping.csv")

# Print some statistics
print(f"\nTotal records: {len(vw_data)}")
print(f"Unique original models: {len(vw_data['rc_maker_model'].unique())}")
print(f"Unique extracted models: {len(vw_data['vw_model'].unique())}")
print(f"Records mapped to known models: {(vw_data['vw_model'] != 'NOT FOUND').sum()}")
print(f"Records not mapped (VW OTHER): {(vw_data['vw_model'] == 'NOT FOUND').sum()}")
print(f"Mapping success rate: {(vw_data['vw_model'] != 'NOT FOUND').sum() / len(vw_data) * 100:.2f}%")