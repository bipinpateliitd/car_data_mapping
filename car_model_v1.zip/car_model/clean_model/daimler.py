#!/usr/bin/env python
# Daimler Vehicle Model Processing Script

import pandas as pd
import numpy as np
import re
from collections import Counter
from rapidfuzz import fuzz, process
import os

# Load the Daimler dataset
daimler_data = pd.read_csv('/home/bipin/Documents/kotak/car_model/manufacturer_data/DAIMLER.csv')
print(f"Loaded {len(daimler_data)} records from DAIMLER.csv")

# Function to clean model names
def clean_model(text):
    if pd.isna(text) or text is None:
        return ""
        
    text = str(text).upper()
    
    # Remove manufacturer prefixes/suffixes
    text = re.sub(r'DAIMLER(?:\s+(?:INDIA|AG))?(?:\s+COMMERCIAL\s+VEHICLES)?(?:\s+(?:PVT|PRIVATE)\.?\s*(?:LTD|LIMITED))?,?\s*', '', text)
    text = re.sub(r'DAIMLER\s*\(I\)\s*COMMERCIAL\s+VEH\s+P\s+LTD,?\s*', '', text)
    
    # Fix BharatBenz name variations
    text = re.sub(r'BHARAT(?:\s*)BENZ', 'BHARATBENZ', text)
    
    # Standardize Mercedes-Benz mentions
    text = re.sub(r'MERCEDES(?:\s*)BENZ', 'MERCEDES-BENZ', text)
    
    # Clean up common format issues
    text = re.sub(r'\s+-\s+\d+$', '', text)  # Remove trailing "- XX" suffixes
    
    # Standardize emission standards
    text = re.sub(r'\bBS(?:[-\s]*(?:III|IV|VI?))\b', '', text)
    
    # Clean up axle configurations
    text = re.sub(r'(\d+)[Xx](\d+)', r'\1X\2', text)  # Standardize 4x2 to 4X2 format
    
    # Remove trailing spaces and commas
    text = text.strip().rstrip(',')
    
    # Remove any multiple spaces
    text = re.sub(r'\s+', ' ', text).strip()
    
    return text

# Create a clean_model column with normalized data
daimler_data['clean_model'] = daimler_data['rc_maker_model'].apply(clean_model)

# Define known Daimler model keywords to search for
model_keywords = [
    # BharatBenz trucks - Light/Medium Duty
    'BHARATBENZ 914', 'BHARATBENZ 1214', 'BHARATBENZ 1215', 'BHARATBENZ 1217',
    'BHARATBENZ 1417', 'BHARATBENZ 1617',
    # BharatBenz trucks - Heavy Duty
    'BHARATBENZ 2523', 'BHARATBENZ 2528', 'BHARATBENZ 2826', 'BHARATBENZ 3123',
    'BHARATBENZ 3128', 'BHARATBENZ 4023',
    # Mercedes-Benz passenger vehicles
    'MERCEDES-BENZ ML',
    # Config types
    'R', 'C', 'T', 'CM'
]

# Define an alias map for common misspellings or alternative notations
alias_map = {
    'BHARATBENZ': ['BHARAT BENZ', 'BHRATBENZ'],
    'MERCEDES-BENZ': ['MERCEDES BENZ'],
}

# Function to normalize model variants by replacing with preferred terminology
def normalize(text):
    for key, aliases in alias_map.items():
        for alias in aliases:
            text = re.sub(r'\b' + re.escape(alias) + r'\b', key, text)
    return text

# Function to extract BharatBenz model series number from a string
def extract_model_number(text):
    # Look for patterns like 1214, 3128, etc.
    match = re.search(r'BHARATBENZ\s+(\d{4})', text)
    if match:
        return match.group(1)
    
    # For models without BharatBenz prefix
    match = re.search(r'\b(\d{4})[RC]', text)
    if match:
        return match.group(1)
        
    match = re.search(r'\b(\d{4})\b', text)
    if match:
        return match.group(1)
        
    return None

# Function to extract Daimler model from the clean text
def extract_daimler_model(text):
    if pd.isna(text) or not text:
        return "DAIMLER OTHER"
    
    text = normalize(text)
    
    # Handle Mercedes-Benz passenger vehicles
    if 'MERCEDES-BENZ ML' in text or 'ML350' in text:
        return "MERCEDES-BENZ ML350"
    
    # For BharatBenz vehicles, extract the model series and type
    if 'BHARATBENZ' in text or re.search(r'\b\d{4}[RCT]', text):
        model_number = extract_model_number(text)
        if not model_number:
            return "BHARATBENZ OTHER"
        
        # Determine truck type (R = Rigid, C = Construction/Tipper, T = Tractor)
        if 'R' in text:
            truck_type = 'R'  # Rigid truck
        elif 'C' in text:
            truck_type = 'C'  # Construction/Tipper
        elif 'T' in text:
            truck_type = 'T'  # Tractor
        elif 'CM' in text:
            truck_type = 'CM' # Concrete mixer
        else:
            truck_type = ''
            
        # Determine axle configuration
        axle_match = re.search(r'(\d+X\d+)', text)
        axle_config = axle_match.group(1) if axle_match else ''
        
        # Build the standardized model name
        if truck_type and axle_config:
            return f"BHARATBENZ {model_number}{truck_type} {axle_config}"
        elif truck_type:
            return f"BHARATBENZ {model_number}{truck_type}"
        elif axle_config:
            return f"BHARATBENZ {model_number} {axle_config}"
        else:
            return f"BHARATBENZ {model_number}"
    
    # Special case for OF bus series
    if 'OF 914' in text or 'OF914' in text:
        return "BHARATBENZ OF 914 BUS"
    
    # Default fallback
    return "DAIMLER OTHER"

# Extract the model from the clean text
daimler_data['daimler_model'] = daimler_data['clean_model'].apply(extract_daimler_model)

# Create a final_model column with fallback to "DAIMLER OTHER" if needed
daimler_data['final_model'] = daimler_data['daimler_model'].apply(
    lambda x: x if x != "DAIMLER OTHER" else "DAIMLER OTHER"
)

# Save the processed data
output_dir = '/home/bipin/Documents/kotak/car_model/clean_model'
os.makedirs(output_dir, exist_ok=True)
daimler_data.to_csv(f'{output_dir}/daimler_processed.csv', index=False)

# Generate model mapping data
mapping_df = pd.DataFrame({
    'clean_model': daimler_data['clean_model'].tolist(),
    'extracted_model': daimler_data['final_model'].tolist()
})
mapping_df.to_csv(f'{output_dir}/daimler_model_mapping.csv', index=False)

# Print summary statistics
total_models = len(daimler_data)
mapped_models = len(daimler_data[daimler_data['final_model'] != "DAIMLER OTHER"])
mapping_rate = (mapped_models / total_models) * 100

print(f"\nProcessed data saved to {output_dir}/daimler_processed.csv")
print(f"Model mapping saved to {output_dir}/daimler_model_mapping.csv")

print(f"\nSummary Statistics:")
print(f"Total models: {total_models}")
print(f"Successfully mapped models: {mapped_models}")
print(f"Mapping rate: {mapping_rate:.2f}%")

# Print model distribution
model_counts = Counter(daimler_data['final_model'])
print("\nModel distribution:")
for model, count in model_counts.most_common():
    percentage = (count / total_models) * 100
    print(f"{model}: {count} ({percentage:.2f}%)")
