#!/usr/bin/env python
# Audi Vehicle Model Processing Script

import pandas as pd
import numpy as np
import re
from collections import Counter
from rapidfuzz import fuzz, process
import os

# Load the Audi dataset
audi_data = pd.read_csv('/home/bipin/Documents/kotak/car_model/manufacturer_data/AUDI.csv')
print(f"Loaded {len(audi_data)} records from AUDI.csv")

# Function to clean model names
def clean_model(text):
    if pd.isna(text) or text is None:
        return ""
        
    text = str(text).upper()
    
    # Remove manufacturer prefixes
    text = re.sub(r'AUDI\s+AG\s+D-85045\s+INGOLSTADT,?\s*', '', text)
    text = re.sub(r'AUDI\s+AG,?\s*', '', text)
    
    # Remove "AUDI" prefix when at start of string (but preserve when part of model designations)
    text = re.sub(r'^"?AUDI\s+AG,\s+', '', text)
    text = re.sub(r'^NEW\s+AUDI\s+', 'AUDI ', text)
    
    # Fix spacing in model designations
    text = re.sub(r'AUDI\s+([AQ])(\d)', r'AUDI \1\2', text)  # Fix "AUDI A 4" -> "AUDI A4"
    text = re.sub(r'([AQ])\s+(\d)', r'\1\2', text)  # Fix "A 4" -> "A4" or "Q 3" -> "Q3"
    text = re.sub(r'(\d)\.(\d)', r'\1.\2', text)  # Fix engine displacement spacing
    text = re.sub(r'(\d)\s+TDI', r'\1 TDI', text)  # Fix "30TDI" -> "30 TDI"
    
    # Remove quotes and standardize engine/trim designations
    text = text.replace('"', '')
    text = re.sub(r'(\d+)(TDI|TFSI)', r'\1 \2', text)  # Add space between number and engine type
    
    return text.strip()

# Create a clean_model column with normalized data
audi_data['clean_model'] = audi_data['rc_maker_model'].apply(clean_model)

# Define known Audi model keywords to search for
model_keywords = [
    # A-series (sedans)
    'A3', 'A4', 'A6', 'A8', 'A8L',
    # Q-series (SUVs)
    'Q3', 'Q5', 'Q7',
    # Sports cars
    'TT', 'R8',
    # S-series (performance models)
    'S5',
    # Engine/drivetrain designations
    'TDI', 'TFSI', 'QUATTRO',
    # Body styles
    'CABRIOLET', 'LIMOUSINE', 'COUPE'
]

# Define an alias map for common misspellings or alternative notations
alias_map = {
    'A8L': ['A8 L', 'A8 LWB'],
    'QUATTRO': ['QUAT', 'Q MULTITRONIC', 'MULTITRONIC'],
    'CABRIOLET': ['CABRIO'],
    'LIMOUSINE': ['LIMO'],
}

# Function to normalize model variants by replacing with preferred terminology
def normalize(text):
    for key, aliases in alias_map.items():
        for alias in aliases:
            text = re.sub(r'\b' + re.escape(alias) + r'\b', key, text)
    return text

# Function to extract Audi model from the clean text
def extract_audi_model(text):
    if pd.isna(text) or not text or len(text) < 2:
        return "AUDI OTHER"
        
    text = normalize(text)
    
    # Handle A-series models
    if 'A3' in text:
        if 'CABRIOLET' in text:
            return "AUDI A3 CABRIOLET"
        if 'LIMOUSINE' in text:
            return "AUDI A3 LIMOUSINE"
        if 'TFSI' in text:
            return "AUDI A3 TFSI"
        if 'TDI' in text:
            return "AUDI A3 TDI"
        return "AUDI A3"
    
    if 'A4' in text:
        if '2.0' in text and 'TDI' in text:
            return "AUDI A4 2.0 TDI"
        if '1.8' in text:
            return "AUDI A4 1.8"
        if 'TFSI' in text:
            return "AUDI A4 TFSI"
        if 'TDI' in text:
            return "AUDI A4 TDI"
        return "AUDI A4"
    
    if 'A6' in text:
        if '2.0' in text and 'TDI' in text:
            return "AUDI A6 2.0 TDI"
        if '3.0' in text and 'TDI' in text:
            return "AUDI A6 3.0 TDI"
        if '2.8' in text and 'FSI' in text:
            return "AUDI A6 2.8 FSI"
        if 'TDI' in text:
            return "AUDI A6 TDI"
        return "AUDI A6"
    
    if 'A8' in text or 'A8L' in text:
        if 'TDI' in text:
            if '3.0' in text:
                return "AUDI A8L 3.0 TDI"
            return "AUDI A8L TDI"
        return "AUDI A8L"
    
    # Handle Q-series models
    if 'Q3' in text:
        if 'QUATTRO' in text:
            return "AUDI Q3 QUATTRO"
        if '2.0' in text and 'TDI' in text:
            return "AUDI Q3 2.0 TDI"
        if 'TDI' in text:
            return "AUDI Q3 TDI"
        return "AUDI Q3"
    
    if 'Q5' in text:
        if 'QUATTRO' in text:
            if '2.0' in text:
                return "AUDI Q5 2.0 TDI QUATTRO"
            return "AUDI Q5 QUATTRO"
        if '2.0' in text and 'TDI' in text:
            return "AUDI Q5 2.0 TDI"
        if '3.0' in text:
            return "AUDI Q5 3.0"
        if 'TDI' in text:
            return "AUDI Q5 TDI"
        if 'TFSI' in text:
            return "AUDI Q5 TFSI"
        return "AUDI Q5"
    
    if 'Q7' in text:
        if '3.0' in text or '30' in text or '35' in text or '45' in text:
            return "AUDI Q7 TDI"
        if 'TDI' in text:
            return "AUDI Q7 TDI"
        return "AUDI Q7"
    
    # Handle sports car models
    if 'TT' in text:
        if 'COUPE' in text:
            if 'QUATTRO' in text:
                return "AUDI TT COUPE QUATTRO"
            return "AUDI TT COUPE"
        return "AUDI TT"
    
    if 'R8' in text:
        if 'QUATTRO' in text:
            return "AUDI R8 QUATTRO"
        return "AUDI R8"
    
    # Handle S models
    if 'S5' in text:
        return "AUDI S5"
    
    # Try to extract model series if specific model extraction failed
    for model in ['A3', 'A4', 'A6', 'A8', 'Q3', 'Q5', 'Q7', 'TT', 'R8', 'S5']:
        if model in text:
            return f"AUDI {model}"
    
    # Default fallback
    return "AUDI OTHER"

# Extract the model from the clean text
audi_data['audi_model'] = audi_data['clean_model'].apply(extract_audi_model)

# Create a final_model column with fallback to "AUDI OTHER" if needed
audi_data['final_model'] = audi_data['audi_model'].apply(
    lambda x: x if x != "AUDI OTHER" else "AUDI OTHER"
)

# Save the processed data
output_dir = '/home/bipin/Documents/kotak/car_model/clean_model'
os.makedirs(output_dir, exist_ok=True)
audi_data.to_csv(f'{output_dir}/audi_processed.csv', index=False)

# Generate model mapping data
mapping_df = pd.DataFrame({
    'clean_model': audi_data['clean_model'].tolist(),
    'extracted_model': audi_data['final_model'].tolist()
})
mapping_df.to_csv(f'{output_dir}/audi_model_mapping.csv', index=False)

# Print summary statistics
total_models = len(audi_data)
mapped_models = len(audi_data[audi_data['final_model'] != "AUDI OTHER"])
mapping_rate = (mapped_models / total_models) * 100

print(f"\nProcessed data saved to {output_dir}/audi_processed.csv")
print(f"Model mapping saved to {output_dir}/audi_model_mapping.csv")

print(f"\nSummary Statistics:")
print(f"Total models: {total_models}")
print(f"Successfully mapped models: {mapped_models}")
print(f"Mapping rate: {mapping_rate:.2f}%")

# Print model distribution
model_counts = Counter(audi_data['final_model'])
print("\nModel distribution:")
for model, count in model_counts.most_common():
    percentage = (count / total_models) * 100
    print(f"{model}: {count} ({percentage:.2f}%)")
