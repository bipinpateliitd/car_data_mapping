#!/usr/bin/env python
# Chevrolet Vehicle Model Processing Script

import pandas as pd
import numpy as np
import re
from collections import Counter
from rapidfuzz import fuzz, process
import os

# Load the Chevrolet dataset
chevrolet_data = pd.read_csv('/home/bipin/Documents/kotak/car_model/manufacturer_data/CHEVROLET.csv')
print(f"Loaded {len(chevrolet_data)} records from CHEVROLET.csv")

# Function to clean model names
def clean_model(text):
    if pd.isna(text) or text is None:
        return ""
        
    text = str(text).upper()
    
    # Remove manufacturer prefixes/suffixes
    text = re.sub(r'CHEVROLET\s+SALES\s+INDIA\s+(?:PVT\.?\s*LTD\.?)?', '', text)
    text = re.sub(r'CHEVROLET\s+', '', text)  # Remove CHEVROLET prefix from model names
    text = re.sub(r'CHEV(?:E)?RLET', '', text)  # Catch misspellings
    text = re.sub(r'^[\s,]*', '', text)  # Remove leading spaces and commas
    
    # Fix model name variations
    text = re.sub(r'SAIL\s+U\s+VA', 'SAIL UVA', text)  # Standardize SAIL U-VA
    text = re.sub(r'SAIL\s+SEDAN', 'SAIL', text)  # Standardize SAIL SEDAN to SAIL
    text = re.sub(r'CAPTIV(?:A)?', 'CAPTIVA', text)  # Fix CAPTIV to CAPTIVA
    text = re.sub(r'TAVERA\s+NEO\s*3?', 'TAVERA', text)  # Standardize TAVERA NEO3 to TAVERA
    
    # Clean specifications
    text = re.sub(r'(?:BS|BSIV?|BSVI?)\s*(?:III|IV|VI?)?', '', text)  # Remove emission standards
    text = re.sub(r'(?:\d+)?\s*(?:STR|SEATER)', '', text)  # Remove seating capacity
    text = re.sub(r'\b(?:L|LS|LT|LTZ|PS|TCDI|DIESEL|BASE|ABS)\b', '', text)  # Remove trim levels and engine types
    
    # Remove commas, periods, and other punctuation
    text = re.sub(r'[,.\"]', ' ', text)
    text = re.sub(r'\s+', ' ', text).strip()
    
    return text

# Create a clean_model column with normalized data
chevrolet_data['clean_model'] = chevrolet_data['rc_maker_model'].apply(clean_model)

# Define known Chevrolet model keywords to search for
model_keywords = [
    'BEAT', 'CRUZE', 'TAVERA', 'ENJOY', 'SPARK', 'SAIL', 'CAPTIVA', 'OPTRA', 
    'AVEO', 'TRAILBLAZER', 'EXTREME', 'XTREME'
]

# Define an alias map for common misspellings or alternative notations
alias_map = {
    'BEAT': ['BEAT'],
    'CRUZE': ['CRUZE'],
    'TAVERA': ['TAVERA'],
    'ENJOY': ['ENJOY'],
    'SPARK': ['SPARK'],
    'SAIL': ['SAIL', 'SAIL UVA'],
    'SAIL UVA': ['SAIL UVA', 'SAIL U VA'],
    'CAPTIVA': ['CAPTIVA', 'CAPTIV'],
    'OPTRA': ['OPTRA'],
    'AVEO': ['AVEO'],
    'TRAILBLAZER': ['TRAILBLAZER'],
    'EXTREME': ['EXTREME', 'XTREME']
}

# Function to normalize model variants by replacing with preferred terminology
def normalize(text):
    for key, aliases in alias_map.items():
        for alias in aliases:
            text = re.sub(r'\b' + re.escape(alias) + r'\b', key, text)
    return text

# Function to extract Chevrolet model from the clean text
def extract_chevrolet_model(text):
    if pd.isna(text) or not text:
        return "CHEVROLET OTHER"
    
    text = normalize(text)
    
    # Check for specific models
    if 'BEAT' in text:
        if 'DIESEL' in text:
            return "CHEVROLET BEAT DIESEL"
        if 'LPG' in text:
            return "CHEVROLET BEAT LPG"
        return "CHEVROLET BEAT"
    
    if 'CRUZE' in text:
        return "CHEVROLET CRUZE"
    
    if 'TAVERA' in text:
        return "CHEVROLET TAVERA"
    
    if 'ENJOY' in text:
        return "CHEVROLET ENJOY"
    
    if 'SPARK' in text:
        if 'LPG' in text:
            return "CHEVROLET SPARK LPG"
        return "CHEVROLET SPARK"
    
    if 'SAIL UVA' in text:
        return "CHEVROLET SAIL UVA"
    
    if 'SAIL' in text:
        return "CHEVROLET SAIL"
    
    if 'CAPTIVA' in text:
        return "CHEVROLET CAPTIVA"
    
    if 'OPTRA' in text:
        return "CHEVROLET OPTRA"
    
    if 'AVEO' in text:
        return "CHEVROLET AVEO"
    
    if 'TRAILBLAZER' in text:
        return "CHEVROLET TRAILBLAZER"
    
    if 'EXTREME' in text or 'XTREME' in text:
        return "CHEVROLET EXTREME"
    
    # Try fuzzy matching if direct keyword matching fails
    best_match = None
    best_score = 0
    for keyword in model_keywords:
        score = fuzz.partial_ratio(text, keyword)
        if score > best_score and score > 80:  # Only accept matches with high confidence
            best_score = score
            best_match = keyword
    
    if best_match:
        return f"CHEVROLET {best_match}"
    
    # Default fallback
    return "CHEVROLET OTHER"

# Extract the model from the clean text
chevrolet_data['chevrolet_model'] = chevrolet_data['clean_model'].apply(extract_chevrolet_model)

# Create a final_model column with fallback to "CHEVROLET OTHER" if needed
chevrolet_data['final_model'] = chevrolet_data['chevrolet_model'].apply(
    lambda x: x if x != "CHEVROLET OTHER" else "CHEVROLET OTHER"
)

# Save the processed data
output_dir = '/home/bipin/Documents/kotak/car_model/clean_model'
os.makedirs(output_dir, exist_ok=True)
chevrolet_data.to_csv(f'{output_dir}/chevrolet_processed.csv', index=False)

# Generate model mapping data
mapping_df = pd.DataFrame({
    'clean_model': chevrolet_data['clean_model'].tolist(),
    'extracted_model': chevrolet_data['final_model'].tolist()
})
mapping_df.to_csv(f'{output_dir}/chevrolet_model_mapping.csv', index=False)

# Print summary statistics
total_models = len(chevrolet_data)
mapped_models = len(chevrolet_data[chevrolet_data['final_model'] != "CHEVROLET OTHER"])
mapping_rate = (mapped_models / total_models) * 100

print(f"\nProcessed data saved to {output_dir}/chevrolet_processed.csv")
print(f"Model mapping saved to {output_dir}/chevrolet_model_mapping.csv")

print(f"\nSummary Statistics:")
print(f"Total models: {total_models}")
print(f"Successfully mapped models: {mapped_models}")
print(f"Mapping rate: {mapping_rate:.2f}%")

# Print model distribution
model_counts = Counter(chevrolet_data['final_model'])
print("\nModel distribution:")
for model, count in model_counts.most_common():
    percentage = (count / total_models) * 100
    print(f"{model}: {count} ({percentage:.2f}%)")
