#!/usr/bin/env python
# Eicher Vehicle Model Processing Script

import pandas as pd
import numpy as np
import re
from collections import Counter
from rapidfuzz import fuzz, process
import os

# Load the Eicher dataset
eicher_data = pd.read_csv('/home/bipin/Documents/kotak/car_model/manufacturer_data/EICHER.csv')
print(f"Loaded {len(eicher_data)} records from EICHER.csv")

# Function to clean model names
def clean_model(text):
    if pd.isna(text) or text is None:
        return ""
        
    text = str(text).upper()
    
    # Remove manufacturer prefixes
    text = re.sub(r'EICHER\s+MOTORS\s+LTD\.?,?\s*', '', text)
    text = re.sub(r'EICHER\s+MOTORS?.?,?\s*', '', text)
    text = re.sub(r'EICHER\s+MOT?.?,?\s*', '', text)
    text = re.sub(r'EICHER\s+TRACTORS\s+LTD\.?,?\s*', '', text)
    text = re.sub(r'EICHER\s+TRACTORS?.?,?\s*', '', text)
    
    # Remove any ", EICHER" variants
    text = re.sub(r',?\s*EICHER\b', '', text)
    
    # Fix common misspellings
    text = re.sub(r'IECHER', 'EICHER', text)
    text = re.sub(r'ECHER', 'EICHER', text)
    
    # Remove BSIII/BS III/BSIV notations (will be handled separately)
    text = re.sub(r'\bBS[-\s]*(III|IV|VI|3|4|6)\b', '', text)
    text = re.sub(r'\bBS(III|IV|VI|3|4|6)\b', '', text)
    
    # Remove special characters except for certain punctuation
    text = re.sub(r'[^\w\s\./\-]', ' ', text)
    
    # Remove extra spaces
    text = re.sub(r'\s+', ' ', text).strip()
    
    return text

# Apply cleaning to create clean_model column
eicher_data['clean_model'] = eicher_data['rc_maker_model'].apply(clean_model)

# Define primary Eicher model keywords
eicher_model_keywords = [
    # Numeric Models
    "10.50", "10.75", "10.80", "10.90", "10.95",
    "11.10", "11.12", "11.14",
    "20.16",
    
    # PRO series
    "PRO", "PRO 1080", "PRO 3015",
    
    # Tractor models
    "241", "380", "557",
    
    # Bullet motorcycles
    "BULLET", "BULLET CLASSIC", "BULLET STANDARD", "CLASSIC 350", "STANDARD 350",
    
    # Hercules model
    "HERCULES", "HERCULES 35.31",
    
    # Common variants
    "XP", "XP 1110",
    "HF", "HF/L",
    "RHD", "LRD",
    "F CAB", "G CAB", "C CAB",
    "FIXED SIDE", "FSD",
    "HSD", "CHASS",
    "AB", "AB PS",
    "CWC", "MGV", "SLP"
]

# Create alias map for common abbreviations and variations
eicher_alias_map = {
    # Model Name Normalization
    "EICHER10": "EICHER 10",
    "EICHER11": "EICHER 11",
    "EICHER20": "EICHER 20",
    
    # PRO series
    "PRO1080": "PRO 1080",
    "PRO3015": "PRO 3015",
    
    # Common variations
    "10 50": "10.50",
    "10 75": "10.75",
    "10 80": "10.80",
    "10 90": "10.90",
    "10 95": "10.95",
    "11 10": "11.10",
    "11 12": "11.12",
    "11 14": "11.14",
    "20 16": "20.16",
    
    # Cab types
    "FIXED SIDE DECK": "FSD",
    "FIXED SIDE": "FSD",
    "CAB CHASSIS": "CHASS",
    "CAB AND CHASSIS": "CHASS",
    "CAB & CHASSIS": "CHASS",
    "CAB AND FIXED SIDE DECK": "CAB FSD",
    "CAB & FIXED SIDE DECK": "CAB FSD",
    
    # Transmission/Drive types
    "RIGHT HAND DRIVE": "RHD",
    "LEFT HAND DRIVE": "LHD",
    
    # Bullet motorcycle variants
    "BULLET CLASSIC 350 UCE": "BULLET CLASSIC 350",
    "BULLET STD 350": "BULLET STANDARD 350",
    "BULLET STD": "BULLET STANDARD",
    
    # Emission Standards
    "BS-III": "BS3",
    "BS-IV": "BS4",
    "BS-VI": "BS6",
    "BSIII": "BS3",
    "BSIV": "BS4",
    "BSVI": "BS6"
}

# Function to normalize model names using the alias map
def normalize(text, alias_map):
    """Normalize model names using an alias map"""
    words = text.split()
    normalized_words = []
    
    i = 0
    while i < len(words):
        # Try to match multi-word phrases (up to 3 words)
        matched = False
        for n_words in [3, 2, 1]:
            if i + n_words <= len(words):
                phrase = " ".join(words[i:i+n_words])
                if phrase in alias_map:
                    normalized_words.extend(alias_map[phrase].split())
                    i += n_words
                    matched = True
                    break
        
        if not matched:
            normalized_words.append(words[i])
            i += 1
    
    return " ".join(normalized_words)

# Function to extract standardized Eicher model name from cleaned text
def extract_eicher_model(text):
    """Extract standardized Eicher model name from cleaned text"""
    if pd.isna(text) or not text:
        return "EICHER OTHER"
    
    # Normalize the text using the alias map
    normalized = normalize(text, eicher_alias_map)
    
    # Check for Bullet motorcycles first (distinct product line)
    if "BULLET" in normalized or "CLASSIC 350" in normalized or "STANDARD 350" in normalized:
        if "CLASSIC" in normalized:
            return "EICHER BULLET CLASSIC"
        elif "STANDARD" in normalized:
            return "EICHER BULLET STANDARD"
        else:
            return "EICHER BULLET"
    
    # Check for PRO series
    if "PRO" in normalized:
        if "1080" in normalized:
            return "EICHER PRO 1080"
        elif "3015" in normalized:
            return "EICHER PRO 3015"
        else:
            return "EICHER PRO SERIES"
    
    # Check for Hercules models
    if "HERCULES" in normalized:
        return "EICHER HERCULES"
    
    # Check for numeric models
    for model in ["10.50", "10.75", "10.80", "10.90", "10.95", "11.10", "11.12", "11.14", "20.16"]:
        if model in normalized:
            return f"EICHER {model}"
    
    # Check for tractor models
    for tractor in ["241", "380", "557"]:
        if tractor in normalized:
            return f"EICHER TRACTOR {tractor}"
    
    # If no direct match, try fuzzy matching
    best_match = None
    best_score = 0
    
    for keyword in eicher_model_keywords:
        if len(keyword) > 3:  # Skip short keywords
            score = fuzz.partial_ratio(keyword, normalized)
            if score > best_score and score >= 85:  # 85% match threshold
                best_score = score
                
                # Special handling for major model groups
                if keyword in ["10.50", "10.75", "10.80", "10.90", "10.95", "11.10", "11.12", "11.14", "20.16"]:
                    best_match = f"EICHER {keyword}"
                elif "BULLET" in keyword or "CLASSIC" in keyword or "STANDARD" in keyword:
                    best_match = "EICHER BULLET"
                elif "PRO" in keyword:
                    best_match = "EICHER PRO SERIES"
                elif keyword in ["241", "380", "557"]:
                    best_match = f"EICHER TRACTOR {keyword}"
                else:
                    best_match = f"EICHER {keyword}"
    
    return best_match if best_match else "EICHER OTHER"

# Apply normalization to get normalized_model column
eicher_data['normalized_model'] = eicher_data['clean_model'].apply(lambda x: normalize(x, eicher_alias_map))

# Apply model extraction to get eicher_model column
eicher_data['eicher_model'] = eicher_data['normalized_model'].apply(extract_eicher_model)

# Set final model (same as eicher_model in this case)
eicher_data['final_model'] = eicher_data['eicher_model']

# Create a mapping dataframe for analysis
mapping_df = eicher_data.groupby(['clean_model', 'final_model']).size().reset_index().rename(columns={0: 'count'})
mapping_df = mapping_df.sort_values(['final_model', 'count'], ascending=[True, False])

# Save the processed data and mapping
os.makedirs('/home/bipin/Documents/kotak/car_model/clean_model/', exist_ok=True)

# Save processed data
output_file = '/home/bipin/Documents/kotak/car_model/clean_model/eicher_processed.csv'
eicher_data.to_csv(output_file, index=False)
print(f"\nProcessed data saved to {output_file}")

# Save mapping file
mapping_file = '/home/bipin/Documents/kotak/car_model/clean_model/eicher_model_mapping.csv'
mapping_df.to_csv(mapping_file, index=False)
print(f"Model mapping saved to {mapping_file}")

# Print summary statistics
total_models = len(eicher_data)
mapped_models = eicher_data[eicher_data['final_model'] != 'EICHER OTHER'].shape[0]
mapping_rate = (mapped_models / total_models) * 100

print("\nSummary Statistics:")
print(f"Total models: {total_models}")
print(f"Successfully mapped models: {mapped_models}")
print(f"Mapping rate: {mapping_rate:.2f}%")

# Count models by category
model_counts = eicher_data['final_model'].value_counts()
print("\nModel distribution:")
for model, count in model_counts.items():
    percentage = (count / total_models) * 100
    print(f"{model}: {count} ({percentage:.2f}%)")
