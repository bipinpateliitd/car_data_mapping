#!/usr/bin/env python
# Renault Vehicle Model Processing Script

import pandas as pd
import numpy as np
import re
from collections import Counter
from rapidfuzz import fuzz, process
import os

# Load the Renault dataset
renault_data = pd.read_csv('/home/bipin/Documents/kotak/car_model/manufacturer_data/RENAULT.csv')
print(f"Loaded {len(renault_data)} records from RENAULT.csv")

# Function to clean model names
def clean_model(text):
    if pd.isna(text) or text is None:
        return ""
        
    text = str(text).upper()
    
    # Remove manufacturer prefixes
    text = re.sub(r'RENAULT\s+INDIA\s+PVT\s+LTD\.?,?\s*', '', text)
    text = re.sub(r'RENAULT\s+INDIA\s+PRIVATE\s+LIMITED,?\s*', '', text)
    text = re.sub(r'M/S\s+RENAULT\s+INDIA\s+PRIVATE\s+LIMITED,?\s*', '', text)
    text = re.sub(r'RENAULTNISSAN\s+AUTOMOTIVE\s+I\s+P\s+L,?\s*', '', text)
    
    # Remove RENAULT prefix when at start of string (but preserve in model names like "RENAULT KWID")
    text = re.sub(r'^RENAULT\s+INDIA\s+PVT\s+LTD,\s+', '', text)
    text = re.sub(r'^"?RENAULT\s+INDIA\s+PVT\s+LTD,\s+', '', text)
    
    # Fix common misspellings
    text = re.sub(r'K\s+WID', 'KWID', text)  # Fix "K WID" -> "KWID"
    text = re.sub(r'DUSTETR', 'DUSTER', text)  # Fix "DUSTETR" typo
    
    # Standardize spacing for model designations
    text = re.sub(r'RX([LESZ])', r'RX\1', text)  # Ensure RXL, RXE, RXS, RXZ are properly spaced
    text = re.sub(r'(\d+)\s*PS', r'\1PS', text)  # Standardize PS designations
    
    # Remove quotes
    text = text.replace('"', '')
    
    return text.strip()

# Create a clean_model column with normalized data
renault_data['clean_model'] = renault_data['rc_maker_model'].apply(clean_model)

# Define known Renault model keywords to search for
model_keywords = [
    # Kwid models and trims
    'KWID', 'RXT', 'RXE', 'RXL', 'RXT', 'CLIMBER', 'EASY-R', 'EASY R', 'AMT',
    # Duster models and trims
    'DUSTER', 'RXE', 'RXL', 'RXZ', 'RXS', 'HP', '85PS', '110PS', '4X4',
    # Lodgy models and trims
    'LODGY', 'STEPWAY', 'DCI', '85 PS', '110PS',
    # Triber models
    'TRIBER',
    # Other Renault models
    'PULSE', 'SCALA', 'KOLEOS',
    # Nissan/Datsun models (Renault-Nissan alliance models that appear in the dataset)
    'TERRANO', 'MICRA', 'GO', 'REDI-GO', 'GO PLUS'
]

# Define an alias map for common misspellings or alternative notations
alias_map = {
    'KWID': ['K WID', 'K-WID'],
    'DUSTER': ['DUSTETR', 'DUSTR'],
    'REDI-GO': ['REDI GO', 'REDIGO'],
    'GO PLUS': ['GOPLUS', 'GO-PLUS'],
    'EASY-R': ['EASY R', 'EASYR'],
    'STEPWAY': ['STEP WAY', 'STEP-WAY']
}

# Function to normalize model variants by replacing with preferred terminology
def normalize(text):
    for key, aliases in alias_map.items():
        for alias in aliases:
            text = re.sub(r'\b' + re.escape(alias) + r'\b', key, text)
    return text

# Function to extract Renault model from the clean text
def extract_renault_model(text):
    if pd.isna(text) or not text:
        return "RENAULT OTHER"
        
    text = normalize(text)
    
    # Handle Kwid models
    if 'KWID' in text:
        if 'CLIMBER' in text:
            return "RENAULT KWID CLIMBER"
        
        # Handle engine/transmission variants
        if '1.0' in text or '1 0' in text:
            if 'AMT' in text or 'EASY-R' in text or 'EASY R' in text:
                return "RENAULT KWID 1.0 AMT"
            return "RENAULT KWID 1.0"
        
        # Handle trim levels
        if 'RXT' in text:
            return "RENAULT KWID RXT"
        if 'RXL' in text:
            return "RENAULT KWID RXL"
        if 'RXE' in text:
            return "RENAULT KWID RXE"
        
        return "RENAULT KWID"
    
    # Handle Duster models
    if 'DUSTER' in text:
        # Handle 4WD variant
        if '4X4' in text:
            return "RENAULT DUSTER 4X4"
        
        # Handle engine variants
        if '110' in text:
            return "RENAULT DUSTER 110PS"
        if '85' in text:
            return "RENAULT DUSTER 85PS"
        
        # Handle trim levels
        if 'RXZ' in text:
            return "RENAULT DUSTER RXZ"
        if 'RXL' in text:
            return "RENAULT DUSTER RXL"
        if 'RXS' in text:
            return "RENAULT DUSTER RXS"
        if 'RXE' in text:
            return "RENAULT DUSTER RXE"
        
        # Check fuel type if specified
        if 'PETROL' in text:
            return "RENAULT DUSTER PETROL"
        if 'DIESEL' in text:
            return "RENAULT DUSTER DIESEL"
        
        return "RENAULT DUSTER"
    
    # Handle Lodgy models
    if 'LODGY' in text:
        if 'STEPWAY' in text:
            return "RENAULT LODGY STEPWAY"
        
        # Handle trim levels
        if 'RXZ' in text:
            return "RENAULT LODGY RXZ"
        if 'RXL' in text:
            return "RENAULT LODGY RXL"
        if 'RXE' in text:
            return "RENAULT LODGY RXE"
        
        return "RENAULT LODGY"
    
    # Handle Triber models
    if 'TRIBER' in text:
        # Handle trim levels
        if 'RXT' in text:
            return "RENAULT TRIBER RXT"
        if 'RXL' in text:
            return "RENAULT TRIBER RXL"
        if 'RXZ' in text:
            return "RENAULT TRIBER RXZ"
        if 'RXE' in text:
            return "RENAULT TRIBER RXE"
        
        return "RENAULT TRIBER"
    
    # Handle other Renault models
    if 'PULSE' in text:
        return "RENAULT PULSE"
    
    if 'SCALA' in text:
        return "RENAULT SCALA"
    
    if 'KOLEOS' in text:
        return "RENAULT KOLEOS"
    
    # Handle Nissan models in the dataset (Renault-Nissan alliance)
    if 'TERRANO' in text:
        return "NISSAN TERRANO"
    
    if 'MICRA' in text:
        return "NISSAN MICRA"
    
    # Handle Datsun models in the dataset (Nissan's budget brand)
    if 'REDI-GO' in text or 'REDI GO' in text:
        return "DATSUN REDI-GO"
    
    if 'GO PLUS' in text:
        return "DATSUN GO PLUS"
    
    if 'GO' in text and 'PLUS' not in text:
        return "DATSUN GO"
    
    # Check for other keywords
    for keyword in model_keywords:
        if keyword in text:
            if keyword in ['RXE', 'RXL', 'RXS', 'RXZ', 'AMT', 'EASY-R', 'PS']:
                continue  # Skip trim levels and variant designations
            return f"RENAULT {keyword}"
    
    # Default fallback
    return "RENAULT OTHER"

# Extract the model from the clean text
renault_data['renault_model'] = renault_data['clean_model'].apply(extract_renault_model)

# Create a final_model column with fallback to "RENAULT OTHER" if needed
renault_data['final_model'] = renault_data['renault_model'].apply(
    lambda x: x if x != "RENAULT OTHER" else "RENAULT OTHER"
)

# Save the processed data
output_dir = '/home/bipin/Documents/kotak/car_model/clean_model'
os.makedirs(output_dir, exist_ok=True)
renault_data.to_csv(f'{output_dir}/renault_processed.csv', index=False)

# Generate model mapping data
mapping_df = pd.DataFrame({
    'clean_model': renault_data['clean_model'].tolist(),
    'extracted_model': renault_data['final_model'].tolist()
})
mapping_df.to_csv(f'{output_dir}/renault_model_mapping.csv', index=False)

# Print summary statistics
total_models = len(renault_data)
mapped_models = len(renault_data[renault_data['final_model'] != "RENAULT OTHER"])
mapping_rate = (mapped_models / total_models) * 100

print(f"\nProcessed data saved to {output_dir}/renault_processed.csv")
print(f"Model mapping saved to {output_dir}/renault_model_mapping.csv")

print(f"\nSummary Statistics:")
print(f"Total models: {total_models}")
print(f"Successfully mapped models: {mapped_models}")
print(f"Mapping rate: {mapping_rate:.2f}%")

# Print model distribution
model_counts = Counter(renault_data['final_model'])
print("\nModel distribution:")
for model, count in model_counts.most_common():
    percentage = (count / total_models) * 100
    print(f"{model}: {count} ({percentage:.2f}%)")
