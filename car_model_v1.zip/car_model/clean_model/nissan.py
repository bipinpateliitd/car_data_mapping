#!/usr/bin/env python
# Nissan Vehicle Model Processing Script

import pandas as pd
import numpy as np
import re
from collections import Counter
from rapidfuzz import fuzz, process
import os

# Load the Nissan dataset
nissan_data = pd.read_csv('/home/bipin/Documents/kotak/car_model/manufacturer_data/NISSAN.csv')
print(f"Loaded {len(nissan_data)} records from NISSAN.csv")

# Create clean_model column immediately after loading

# Function to clean model names
def clean_model(text):
    if pd.isna(text) or text is None:
        return ""
        
    text = str(text).upper()
    
    # Remove manufacturer prefixes
    text = re.sub(r'NISSAN\s+MOTOR\s+INDIA\s+PVT\s+LTD\.?,?\s*', '', text)
    text = re.sub(r'NISSAN\s+MOTORS?.?,?\s*', '', text)
    text = re.sub(r'NISSAN\s+MODEL\s*', '', text)
    text = re.sub(r'NISSAN\s+MOD\s*', '', text)
    
    # Remove any ", NISSAN" variants
    text = re.sub(r',?\s*NISSAN\b', '', text)
    
    # Fix common misspellings
    text = re.sub(r'NISSAM', 'NISSAN', text)
    text = re.sub(r'NISHAN', 'NISSAN', text)
    
    # Remove BSIV/BS IV/BSVI notations (will be handled separately)
    text = re.sub(r'\bBS[-\s]*(III|IV|VI|3|4|6)\b', '', text)
    text = re.sub(r'\bBS(III|IV|VI|3|4|6)\b', '', text)
    
    # Remove special characters except for certain punctuation
    text = re.sub(r'[^\w\s\./\-]', ' ', text)
    
    # Remove extra spaces
    text = re.sub(r'\s+', ' ', text).strip()
    
    return text
nissan_data['clean_model'] = nissan_data['rc_maker_model'].apply(clean_model)

# Define primary Nissan model keywords
nissan_model_keywords = [
    # Main Nissan Models
    "MICRA", "TERRANO", "SUNNY", "EVALIA", "KICKS", "MAGNITE", "X-TRAIL", "TEANA", "370Z",
    
    # Datsun sub-brand models
    "DATSUN", "GO", "GO PLUS", "REDI GO", "REDI-GO", "REDIGO",
    
    # Common Micra variants
    "MICRA ACTIVE", "MICRA PRIMO", "MICRA MC", "MICRA K13", "MICRA XL", "MICRA XV", 
    
    # Common Terrano variants
    "TERRANO XE", "TERRANO XL", "TERRANO XV", "TERRANO XVD", "TERRANO THP",
    "TERRANO PREMIUM", "TERRANO 110PS", "TERRANO 85PS",
    
    # Common Sunny variants
    "SUNNY XE", "SUNNY XL", "SUNNY XV", "SUNNY CVT",
    
    # Common Datsun Go variants
    "GO T", "GO T PLUS", "GO A", "GO A1", "GO SV", "GO TRUST",
    
    # Common Datsun Redi-Go variants
    "REDI GO T", "REDI GO S", "REDI GO A", "REDI-GO T", "REDI-GO S", "REDI-GO A",
    "REDI GO T(O)", "REDI GO S(O)", "REDI-GO T(O)", "REDI-GO S(O)",
    "REDI GO TO", "REDI GO T O", "REDI GO S(O)", "REDI-GO S(O)",
    
    # Common Evalia variants
    "EVALIA XV", "EVALIA XL", "NV200", "EVALIA DCI",
    
    # Engine types and sizes
    "DCI", "1.0", "1.0L", "1.2", "1.5", "1.6", "2.0", "DCL",
    
    # Transmission types
    "MT", "AT", "CVT", "XTRONIC",
    
    # Trims 
    "XL", "XV", "XE", "T", "S", "A", "(O)", "PLUS", "SPORT", "GOLD"
]

# Create alias map for common abbreviations and variations
nissan_alias_map = {
    # Model Name Normalization
    "DUTSUN": "DATSUN", 
    "DATSON": "DATSUN",
    "DUTSON": "DATSUN",
    "DESTUN": "DATSUN",
    "DASTUN": "DATSUN",
    "TERANO": "TERRANO",
    "TERRNO": "TERRANO",
    "TERRENO": "TERRANO",
    "TERRANCO": "TERRANO",
    "MICRAA": "MICRA",
    "SUNY": "SUNNY",
    "SUNNT": "SUNNY",
    "SUNNYXV": "SUNNY XV",
    "EVAIA": "EVALIA",
    
    # Datsun variants
    "GO PLUST": "GO PLUS",
    "GOPLUS": "GO PLUS",
    "GO+": "GO PLUS",
    "GO TRUST": "GO T",
    "GO T(O": "GO T (O)",
    "GO T PLUS": "GO PLUS T",
    "GO  PLUS": "GO PLUS",
    "GO  T": "GO T",
    "GO T BS4": "GO T",
    "GO T BS IV": "GO T",
    "GO T M1 BS4": "GO T",
    "GO PLUS T (O M1 BS4": "GO PLUS T (O)",
    "GO PLUS T (O BS4": "GO PLUS T (O)",
    "GO PLUS T M1 BS4": "GO PLUS T",
    
    # Redi Go variants
    "REDI GO": "REDIGO",
    "REDI-GO": "REDIGO",
    "REDI- GO": "REDIGO",
    "REDI GO T (O)": "REDIGO T (O)",
    "REDI-GO T (O)": "REDIGO T (O)",
    "REDI GO T(O)": "REDIGO T (O)",
    "REDI-GO T(O)": "REDIGO T (O)",
    "REDI GO TO": "REDIGO T (O)",
    "REDI GO T O": "REDIGO T (O)",
    "REDI GO S (O)": "REDIGO S (O)",
    "REDI-GO S (O)": "REDIGO S (O)",
    "REDI GO S(O)": "REDIGO S (O)",
    "REDI-GO S(O)": "REDIGO S (O)",
    "REDI GO SO": "REDIGO S (O)",
    
    # Micra variants
    "MICRA XL (O)": "MICRA XL (O)",
    "MICRA XV (D)": "MICRA XV DIESEL",
    "MICRA MC XVD": "MICRA XV DIESEL",
    "MICRA XL(O)": "MICRA XL (O)", 
    "MICRA ACTIVE XV SAFEPAC": "MICRA ACTIVE XV SAFETY PACK",
    "MICRA DL XV": "MICRA DIESEL XV",
    "MICRA DL XV PREM": "MICRA DIESEL XV PREMIUM",
    "MICRA DL XV PREMIUM": "MICRA DIESEL XV PREMIUM",
    "MICRA DL XV PREMIUM PRIMO": "MICRA DIESEL XV PREMIUM",
    "MICRA XE PLUS": "MICRA XE",
    "MICRA DOM": "MICRA",
    "MICRA DLXV": "MICRA DIESEL XV",
    "MICRA DCI": "MICRA DIESEL",
    "MICRA XL CVT BS IV": "MICRA XL CVT",
    "MICRA XV CVT SV": "MICRA XV CVT",
    "MICRA MC XV CVT SV": "MICRA XV CVT",
    "MICRA MC XV CVT PETROL": "MICRA XV CVT",
    "MICRA XTRONIC CVT": "MICRA XV CVT",

    # Terrano variants
    "TERRANO XV D PRM": "TERRANO XV PREMIUM",
    "TERRANO XV PRM DCI": "TERRANO XV PREMIUM",
    "TERRANO XV D PRM 110PS": "TERRANO XV PREMIUM 110PS",
    "TERRANO XVD THP": "TERRANO XV THP",
    "TERRANO XVD THD": "TERRANO XV THP",
    "TERRANO XVD (THP)": "TERRANO XV THP",
    "TERRANO THP XV": "TERRANO XV THP",
    "TERRANO XVD 0": "TERRANO XVD (O)",
    "TERRANO XVD O": "TERRANO XVD (O)",
    "TERRANO XLD 0": "TERRANO XLD (O)",
    "TERRANO XLD O": "TERRANO XLD (O)",
    "TERRANO XL (O": "TERRANO XL (O)",
    "TERRANO XV DCI (HSNA36)": "TERRANO XV",
    "TERRANO XE DCI - 85 PS": "TERRANO XE 85PS",
    "TERRANO XE DCI 85PS": "TERRANO XE 85PS",
    "TERRANO XL 85 PS D PLUS": "TERRANO XL PLUS 85PS",
    "TERRANO XL DIESEL PLUS 85PS": "TERRANO XL PLUS 85PS",
    "TERRANO XL PLUS DIESEL": "TERRANO XL PLUS",
    "TERRANO 110 PS": "TERRANO 110PS",
    "TERRANO 85 PS": "TERRANO 85PS",
    
    # Sunny variants
    "SUNNY DCI XV": "SUNNY XV DIESEL",
    "SUNNY DCI XL": "SUNNY XL DIESEL",
    "SUNNY XV DIESEL 1.5": "SUNNY XV DIESEL",
    "SUNNY XV 1.5 DIESEL": "SUNNY XV DIESEL",
    "SUNNY XV 1.5 PETROL": "SUNNY XV PETROL",
    "SUNNY XE (D)": "SUNNY XE DIESEL",
    "SUNNY XL (D)": "SUNNY XL DIESEL",
    "SUNNY XL CVT PETROL": "SUNNY XL CVT",
    "SUNNY XV CVT PETROL": "SUNNY XV CVT",
    "SUNNY MC XVD": "SUNNY XV DIESEL",
    "SUNNY MC XV CVT PETROL": "SUNNY XV CVT",
    "SUNNY XTONIC CVT": "SUNNY CVT",
    
    # Trim Level Variants
    "XL-D": "XL DIESEL",
    "XE-D": "XE DIESEL",
    "XV-D": "XV DIESEL",
    
    # Engine Types
    "DISEL": "DIESEL",
    "DIESAL": "DIESEL",
    "PETRO": "PETROL",
    
    # Emission Standards
    "BS-III": "BS3",
    "BS-IV": "BS4",
    "BS-VI": "BS6",
    "BSIII": "BS3",
    "BSIV": "BS4",
    "BSVI": "BS6"
}

# Function to normalize model names using the alias map
def normalize(text, alias_map):
    """Normalize model names using an alias map"""
    words = text.split()
    normalized_words = []
    
    i = 0
    while i < len(words):
        # Try to match multi-word phrases (up to 3 words)
        matched = False
        for n_words in [3, 2, 1]:
            if i + n_words <= len(words):
                phrase = " ".join(words[i:i+n_words])
                if phrase in alias_map:
                    normalized_words.extend(alias_map[phrase].split())
                    i += n_words
                    matched = True
                    break
        
        if not matched:
            normalized_words.append(words[i])
            i += 1
    
    return " ".join(normalized_words)

# Function to extract standardized Nissan model from cleaned text
def extract_nissan_model(text):
    """Extract standardized Nissan model name from cleaned text"""
    if pd.isna(text) or not text:
        return "NISSAN OTHER"
    
    # Normalize the text using the alias map
    normalized = normalize(text, nissan_alias_map)
    
    # Check for Datsun models first (sub-brand)
    if "DATSUN" in normalized or "GO" in normalized or "REDI" in normalized or "REDIGO" in normalized:
        # Datsun Go models
        if "GO" in normalized and "PLUS" in normalized:
            return "DATSUN GO PLUS"
        elif "GO" in normalized:
            return "DATSUN GO"
        # Datsun Redi-Go models
        elif any(term in normalized for term in ["REDIGO", "REDI GO", "REDI-GO"]):
            return "DATSUN REDIGO"
        else:
            return "DATSUN OTHER"
    
    # Check for main Nissan models
    for model in ["MICRA", "TERRANO", "SUNNY", "EVALIA", "KICKS", "MAGNITE", "X-TRAIL", "TEANA", "370Z"]:
        if model in normalized:
            # Special handling for model variants
            if model == "MICRA" and "ACTIVE" in normalized:
                return "NISSAN MICRA ACTIVE"
            elif model == "TERRANO":
                # Check for Terrano variants with PS specification
                if "110PS" in normalized or "110 PS" in normalized:
                    return "NISSAN TERRANO 110PS"
                elif "85PS" in normalized or "85 PS" in normalized:
                    return "NISSAN TERRANO 85PS"
                else:
                    return "NISSAN TERRANO"
            else:
                return f"NISSAN {model}"
    
    # If no direct match, try fuzzy matching
    best_match = None
    best_score = 0
    
    for keyword in nissan_model_keywords:
        if len(keyword) > 3:  # Skip short keywords like trim levels
            score = fuzz.partial_ratio(keyword, normalized)
            if score > best_score and score >= 85:  # 85% match threshold
                best_score = score
                
                # Special handling for major model groups
                if any(model in keyword for model in ["MICRA", "TERRANO", "SUNNY", "EVALIA", "DATSUN", "GO", "REDIGO", "REDI GO"]):
                    for model in ["MICRA", "TERRANO", "SUNNY", "EVALIA"]:
                        if model in keyword:
                            best_match = f"NISSAN {model}"
                            break
                    if "DATSUN" in keyword or "GO" in keyword:
                        if "PLUS" in keyword:
                            best_match = "DATSUN GO PLUS"
                        elif "REDI" in keyword or "REDIGO" in keyword:
                            best_match = "DATSUN REDIGO"
                        else:
                            best_match = "DATSUN GO"
                else:
                    best_match = f"NISSAN {keyword}"
    
    return best_match if best_match else "NISSAN OTHER"


nissan_data['normalized_model'] = nissan_data['clean_model'].apply(lambda x: normalize(x, nissan_alias_map))
nissan_data['nissan_model'] = nissan_data['normalized_model'].apply(extract_nissan_model)

# Set final model (same as nissan_model in this case)
nissan_data['final_model'] = nissan_data['nissan_model']

# Create a mapping dataframe for analysis
mapping_df = nissan_data.groupby(['clean_model', 'final_model']).size().reset_index().rename(columns={0: 'count'})
mapping_df = mapping_df.sort_values(['final_model', 'count'], ascending=[True, False])

# Save the processed data and mapping
os.makedirs('/home/bipin/Documents/kotak/car_model/clean_model/', exist_ok=True)

# Save processed data
output_file = '/home/bipin/Documents/kotak/car_model/clean_model/nissan_processed.csv'
nissan_data.to_csv(output_file, index=False)
print(f"\nProcessed data saved to {output_file}")

# Save mapping file
mapping_file = '/home/bipin/Documents/kotak/car_model/clean_model/nissan_model_mapping.csv'
mapping_df.to_csv(mapping_file, index=False)
print(f"Model mapping saved to {mapping_file}")

# Print summary statistics
total_models = len(nissan_data)
mapped_models = nissan_data[nissan_data['final_model'] != 'NISSAN OTHER'].shape[0]
mapping_rate = (mapped_models / total_models) * 100

print("\nSummary Statistics:")
print(f"Total models: {total_models}")
print(f"Successfully mapped models: {mapped_models}")
print(f"Mapping rate: {mapping_rate:.2f}%")

# Count models by category
model_counts = nissan_data['final_model'].value_counts()
print("\nModel distribution:")
for model, count in model_counts.items():
    percentage = (count / total_models) * 100
    print(f"{model}: {count} ({percentage:.2f}%)")
