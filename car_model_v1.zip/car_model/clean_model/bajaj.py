#!/usr/bin/env python
# Bajaj Vehicle Model Processing Script

import pandas as pd
import numpy as np
import re
from collections import Counter
from rapidfuzz import fuzz, process
import os

# Load the Bajaj dataset
bajaj_data = pd.read_csv('/home/bipin/Documents/kotak/car_model/manufacturer_data/BAJAJ.csv')
print(f"Loaded {len(bajaj_data)} records from BAJAJ.csv")

# Function to clean model names
def clean_model(text):
    if pd.isna(text) or text is None:
        return ""
        
    text = str(text).upper()
    
    # Remove manufacturer prefixes
    text = re.sub(r'BAJAJ\s+AUTO\s+LTD,?\s*', '', text)
    text = re.sub(r'BAJAJ\s+AUTO,?\s*', '', text)
    text = re.sub(r'BAJAJ\s+TEMPO\s+LTD,?\s*', '', text)
    text = re.sub(r'BAJAJ\s+TEMPO\s+LIMITED,?\s*', '', text)
    
    # Remove BAJAJ prefix when at start of string (but preserve when in middle)
    text = re.sub(r'^BAJAJ\s+', '', text)
    text = re.sub(r'^BAJAJ=', '', text)
    text = re.sub(r'^BAJAJ,', '', text)
    
    # Fix common misspellings
    text = re.sub(r'PULSER', 'PULSAR', text)
    text = re.sub(r'PLSAR', 'PULSAR', text)
    text = re.sub(r'PULZER', 'PULSAR', text)
    text = re.sub(r'PULSUR', 'PULSAR', text)
    
    text = re.sub(r'DESCVR', 'DISCOVER', text)
    text = re.sub(r'DISCVR', 'DISCOVER', text)
    text = re.sub(r'DISCO ', 'DISCOVER ', text)
    
    text = re.sub(r'AUTO\s+RIKSHAW', 'AUTORICKSHAW', text)
    text = re.sub(r'AUTO\s+RIKSHA', 'AUTORICKSHAW', text)
    text = re.sub(r'A/R', 'AUTORICKSHAW', text)
    text = re.sub(r'AR 4', 'AUTORICKSHAW 4', text)
    
    # Handle vehicle types
    text = re.sub(r'M/CYCLE', 'MOTORCYCLE', text)
    text = re.sub(r'M/C', 'MOTORCYCLE', text)
    text = re.sub(r'MOTOR\s+CYCLE', 'MOTORCYCLE', text)
    
    # Handle emission standards
    text = re.sub(r'BS[-\s]*(III|IV|VI|3|4|6)', '', text)
    text = re.sub(r'BS(III|IV|VI|3|4|6)', '', text)
    
    # Remove special characters except for certain punctuation
    text = re.sub(r'[^\w\s\./\-]', ' ', text)
    
    # Remove extra spaces
    text = re.sub(r'\s+', ' ', text).strip()
    
    return text

# Apply cleaning to create clean_model column
bajaj_data['clean_model'] = bajaj_data['rc_maker_model'].apply(clean_model)

# Define primary Bajaj model keywords
bajaj_model_keywords = [
    # Pulsar motorcycle models
    "PULSAR", "PULSAR 150", "PULSAR 180", "PULSAR 220", "PULSAR 200", 
    "PULSAR NS", "PULSAR RS", "PULSAR N160", "PULSAR 125", "PULSAR DTS I",
    
    # Discover motorcycle models
    "DISCOVER", "DISCOVER 100", "DISCOVER 110", "DISCOVER 125", "DISCOVER 135", 
    "DISCOVER 150", "DISCOVER DTS SI", "DISCOVER ES", 
    
    # CT motorcycle models
    "CT", "CT 100", "CT 110", "CT100", "CT110",
    
    # Other motorcycle models
    "XCD", "XCD 125", "WIND 125", "BOXER", 
    
    # Scooter models
    "CHETAK", "LEGEND", "SUNNY", "ASPIN",
    
    # Autorickshaw models
    "RE", "RE 2S", "RE 4S", "RE MAXIMA", "RE CNG", "AUTORICKSHAW",
    
    # Tempo/commercial vehicle models
    "TEMPO", "MINIDOR", "TRAVELLER", "TRAX", "KARGO", "TOFFAN", "JUDO", "GAMA",
    "TRAX GAMA", "TRAX JUDO", "KARGO KING", "307",
]

# Create alias map for common abbreviations and variations
bajaj_alias_map = {
    # Pulsar variants
    "PULSAR 150": "PULSAR 150",
    "PULSAR 150 DTS I": "PULSAR 150",
    "PULSAR 180": "PULSAR 180",
    "PULSAR 180 ES": "PULSAR 180",
    "PULSAR 200": "PULSAR 200",
    "PULSAR 220": "PULSAR 220",
    "PULSAR 125": "PULSAR 125",
    "PULSAR N 160": "PULSAR N160",
    "PULSAR N160": "PULSAR N160",
    "PULSAR NS": "PULSAR NS",
    "PULSAR RS": "PULSAR RS",
    "PULSAR ES": "PULSAR ES",
    "PULSAR DTS I": "PULSAR DTS-I",
    
    # Discover variants
    "DISCOVER 100": "DISCOVER 100",
    "DISCOVER 100 ES": "DISCOVER 100",
    "DISCOVER 110": "DISCOVER 110",
    "DISCOVER 110 CBS": "DISCOVER 110",
    "DISCOVER 125": "DISCOVER 125",
    "DISCOVER 125 DIBR ES": "DISCOVER 125",
    "DISCOVER 135": "DISCOVER 135",
    "DISCOVER 135 CC": "DISCOVER 135",
    "DISCOVER 150": "DISCOVER 150",
    "DISCOVER 150 F": "DISCOVER 150",
    "DISCOVER DTS SI": "DISCOVER DTS-SI",
    "DISCOVER DTS SI DRUM ES": "DISCOVER DTS-SI",
    
    # CT variants
    "CT 100": "CT100",
    "CT100": "CT100",
    "CT100 FAIRING": "CT100",
    "CT 100 WITH LG SG": "CT100",
    "CT 110": "CT110",
    "CT110": "CT110",
    "CT 110 L2": "CT110",
    
    # Other motorcycle variants
    "XCD 125": "XCD125",
    "XCD 125 DTS SI": "XCD125",
    "XCD125 DTS SI": "XCD125",
    "WIND 125": "WIND125",
    "WIND 125 DRUM": "WIND125",
    "BOXER 4S": "BOXER",
    "KB 100": "KB100",
    
    # Scooter variants
    "CHETAK": "CHETAK",
    "CHETAK 4 STROKE": "CHETAK 4S",
    "SUNNY": "SUNNY",
    "SUNNY SCOOTER": "SUNNY",
    "LEGEND": "LEGEND",
    "ASPIN": "ASPIN",
    
    # Autorickshaw variants
    "AUTORICKSHAW": "RE AUTORICKSHAW",
    "RE": "RE AUTORICKSHAW",
    "RE 2S": "RE 2S",
    "RE 4S": "RE 4S", 
    "RE 4 STROKE": "RE 4S",
    "RE 4 STROKE 205 LPG": "RE 4S LPG",
    "RE CNG 4S FI": "RE CNG",
    "RE MAXIMA": "RE MAXIMA",
    "PASSANGER AR": "RE AUTORICKSHAW",
    "AUTORICKSHAW RE": "RE AUTORICKSHAW",
    "AUTORICKSHAW RE 2S": "RE 2S",
    "OPERATION ON LPG 4S": "RE 4S LPG",
    "4 STROKE LPG": "RE 4S LPG",
    "MEGA BAJAJ": "RE MAXIMA",
    
    # Tempo/commercial variants
    "TEMPO": "TEMPO",
    "MINIDOR": "TEMPO MINIDOR",
    "MINIDOR PICK UP": "TEMPO MINIDOR PICKUP",
    "TEMPO TRAVELLER DELIVARY VAN": "TEMPO TRAVELLER",
    "TEMPO KARGO KING": "TEMPO KARGO KING",
    "TEMPO TOFFAN": "TEMPO TOFFAN",
    "TEMPO TRAX JUDO": "TEMPO TRAX JUDO",
    "TRAX JUDO": "TEMPO TRAX JUDO",
    "TRAX GAMA": "TEMPO TRAX GAMA",
    "TEMPO 307": "TEMPO 307",
}

# Function to normalize model names using the alias map
def normalize(text, alias_map):
    """Normalize model names using an alias map"""
    words = text.split()
    normalized_words = []
    
    i = 0
    while i < len(words):
        # Try to match multi-word phrases (up to 4 words)
        matched = False
        for n_words in [4, 3, 2, 1]:
            if i + n_words <= len(words):
                phrase = " ".join(words[i:i+n_words])
                if phrase in alias_map:
                    normalized_words.extend(alias_map[phrase].split())
                    i += n_words
                    matched = True
                    break
        
        if not matched:
            normalized_words.append(words[i])
            i += 1
    
    return " ".join(normalized_words)

# Function to extract standardized Bajaj model name from cleaned text
def extract_bajaj_model(text):
    """Extract standardized Bajaj model name from cleaned text"""
    if pd.isna(text) or not text:
        return "BAJAJ OTHER"
    
    # Normalize the text using the alias map
    normalized = normalize(text, bajaj_alias_map)
    
    # Check for Pulsar motorcycles
    if "PULSAR" in normalized:
        if "N160" in normalized:
            return "BAJAJ PULSAR N160"
        elif "150" in normalized:
            return "BAJAJ PULSAR 150"
        elif "180" in normalized:
            return "BAJAJ PULSAR 180"
        elif "200" in normalized:
            return "BAJAJ PULSAR 200"
        elif "220" in normalized:
            return "BAJAJ PULSAR 220"
        elif "125" in normalized:
            return "BAJAJ PULSAR 125"
        elif "NS" in normalized:
            return "BAJAJ PULSAR NS"
        elif "RS" in normalized:
            return "BAJAJ PULSAR RS"
        else:
            return "BAJAJ PULSAR"
    
    # Check for Discover motorcycles
    if "DISCOVER" in normalized:
        if "100" in normalized:
            return "BAJAJ DISCOVER 100"
        elif "110" in normalized:
            return "BAJAJ DISCOVER 110"
        elif "125" in normalized:
            return "BAJAJ DISCOVER 125"
        elif "135" in normalized:
            return "BAJAJ DISCOVER 135"
        elif "150" in normalized:
            return "BAJAJ DISCOVER 150"
        elif "DTS" in normalized:
            return "BAJAJ DISCOVER DTS-SI"
        else:
            return "BAJAJ DISCOVER"
    
    # Check for CT motorcycles
    if "CT100" in normalized or "CT 100" in normalized:
        return "BAJAJ CT100"
    if "CT110" in normalized or "CT 110" in normalized:
        return "BAJAJ CT110"
    
    # Check for other motorcycles
    if "XCD125" in normalized or "XCD 125" in normalized:
        return "BAJAJ XCD125"
    if "WIND125" in normalized or "WIND 125" in normalized:
        return "BAJAJ WIND125"
    if "BOXER" in normalized:
        return "BAJAJ BOXER"
    if "KB100" in normalized or "KB 100" in normalized:
        return "BAJAJ KB100"
    
    # Check for scooters
    if "CHETAK" in normalized:
        return "BAJAJ CHETAK"
    if "LEGEND" in normalized:
        return "BAJAJ LEGEND"
    if "SUNNY" in normalized:
        return "BAJAJ SUNNY"
    if "ASPIN" in normalized:
        return "BAJAJ ASPIN"
    
    # Check for autorickshaws
    if "AUTORICKSHAW" in normalized or "RE " in normalized:
        if "2S" in normalized:
            return "BAJAJ RE 2S"
        elif "4S" in normalized:
            if "LPG" in normalized:
                return "BAJAJ RE 4S LPG"
            elif "CNG" in normalized:
                return "BAJAJ RE CNG"
            else:
                return "BAJAJ RE 4S"
        elif "MAXIMA" in normalized:
            return "BAJAJ RE MAXIMA"
        else:
            return "BAJAJ RE AUTORICKSHAW"
    
    # Check for Tempo variants
    if "TEMPO" in normalized or "TRAX" in normalized:
        if "MINIDOR" in normalized:
            if "PICKUP" in normalized:
                return "BAJAJ TEMPO MINIDOR PICKUP"
            else:
                return "BAJAJ TEMPO MINIDOR"
        elif "TRAVELLER" in normalized:
            return "BAJAJ TEMPO TRAVELLER"
        elif "KARGO KING" in normalized:
            return "BAJAJ TEMPO KARGO KING"
        elif "TRAX JUDO" in normalized:
            return "BAJAJ TEMPO TRAX JUDO"
        elif "TRAX GAMA" in normalized:
            return "BAJAJ TEMPO TRAX GAMA"
        elif "TOFFAN" in normalized:
            return "BAJAJ TEMPO TOFFAN"
        elif "307" in normalized:
            return "BAJAJ TEMPO 307"
        else:
            return "BAJAJ TEMPO OTHER"
    
    # If no direct match, try fuzzy matching
    best_match = None
    best_score = 0
    
    for keyword in bajaj_model_keywords:
        if len(keyword) > 3:  # Skip short keywords
            score = fuzz.partial_ratio(keyword, normalized)
            if score > best_score and score >= 85:  # 85% match threshold
                best_score = score
                
                # Special handling for major model groups
                if "PULSAR" in keyword:
                    best_match = "BAJAJ PULSAR"
                elif "DISCOVER" in keyword:
                    best_match = "BAJAJ DISCOVER"
                elif keyword in ["CT", "CT100", "CT 100"]:
                    best_match = "BAJAJ CT100"
                elif keyword in ["CT110", "CT 110"]:
                    best_match = "BAJAJ CT110"
                elif keyword in ["XCD", "XCD 125"]:
                    best_match = "BAJAJ XCD125"
                elif keyword == "WIND 125":
                    best_match = "BAJAJ WIND125"
                elif keyword == "BOXER":
                    best_match = "BAJAJ BOXER"
                elif keyword == "CHETAK":
                    best_match = "BAJAJ CHETAK"
                elif keyword == "LEGEND":
                    best_match = "BAJAJ LEGEND"
                elif keyword == "SUNNY":
                    best_match = "BAJAJ SUNNY"
                elif keyword == "RE" or keyword == "AUTORICKSHAW":
                    best_match = "BAJAJ RE AUTORICKSHAW"
                elif keyword == "TEMPO" or "TRAX" in keyword:
                    best_match = "BAJAJ TEMPO OTHER"
                else:
                    best_match = f"BAJAJ {keyword}"
    
    return best_match if best_match else "BAJAJ OTHER"

# Apply normalization to get normalized_model column
bajaj_data['normalized_model'] = bajaj_data['clean_model'].apply(lambda x: normalize(x, bajaj_alias_map))

# Apply model extraction to get bajaj_model column
bajaj_data['bajaj_model'] = bajaj_data['normalized_model'].apply(extract_bajaj_model)

# Set final model (same as bajaj_model in this case)
bajaj_data['final_model'] = bajaj_data['bajaj_model']

# Create a mapping dataframe for analysis
mapping_df = bajaj_data.groupby(['clean_model', 'final_model']).size().reset_index().rename(columns={0: 'count'})
mapping_df = mapping_df.sort_values(['final_model', 'count'], ascending=[True, False])

# Save the processed data and mapping
os.makedirs('/home/bipin/Documents/kotak/car_model/clean_model/', exist_ok=True)

# Save processed data
output_file = '/home/bipin/Documents/kotak/car_model/clean_model/bajaj_processed.csv'
bajaj_data.to_csv(output_file, index=False)
print(f"\nProcessed data saved to {output_file}")

# Save mapping file
mapping_file = '/home/bipin/Documents/kotak/car_model/clean_model/bajaj_model_mapping.csv'
mapping_df.to_csv(mapping_file, index=False)
print(f"Model mapping saved to {mapping_file}")

# Print summary statistics
total_models = len(bajaj_data)
mapped_models = bajaj_data[bajaj_data['final_model'] != 'BAJAJ OTHER'].shape[0]
mapping_rate = (mapped_models / total_models) * 100

print("\nSummary Statistics:")
print(f"Total models: {total_models}")
print(f"Successfully mapped models: {mapped_models}")
print(f"Mapping rate: {mapping_rate:.2f}%")

# Count models by category
model_counts = bajaj_data['final_model'].value_counts()
print("\nModel distribution:")
for model, count in model_counts.items():
    percentage = (count / total_models) * 100
    print(f"{model}: {count} ({percentage:.2f}%)")
