import re
import pandas as pd
from rapidfuzz import process, fuzz

# Your existing keywords list
tata_model_keywords = [
    "INDICA", "INDICA V2", "INDIGO", "INDIGO MARINA", "MANZA", "VISTA", "ZEST", "BOLT",
    "TIAGO", "TIGOR", "NEXON", "ALTROZ", "PUNCH", "ARIA", "HEXA", "SAFARI", "CURVV", "NANO","HARRIER",
    "PIXEL", "MEGAPIXEL", "SIERRA", "AVINYA", "E-VISION","SUMO",
    "NEXON EV", "TIGOR EV", "TIAGO EV", "PUNCH EV", "HARRIER EV", "ALTROZ EV", "CURVV EV", "SIERRA EV",
    "ACE", "ACE ZIP", "ACE GOLD", "ACE EV", "MAGIC", "MAGIC IRIS", "SUPER ACE",
    "XENON", "YODHA", "INTRA", "INTRA V10", "INTRA V20", "INTRA V30", "INTRA V50", "INTRA V70", "WINGER",
    "407", "709", "909", "1109", "1512C", "1515C", "1615C", "1616C", "1618C",
    "1518C", "1613", "1616", "1618", "LPT", "LPT 510", "LPT 1109", "LPT 1613", "LPT 1816",
    "NOVUS", "PRIMA", "SIGNA", "SIGNA 2825K", "SIGNA 3530K", "SIGNA 4225T", "SIGNA 4623S",
    "ULTRA", "ULTRA T.6", "ULTRA T.7", "ULTRA T.18",
    "STARBUS", "CITYRIDE", "MAGNA", "DIVO",
    "JAGUAR", "LAND ROVER",
    "LPK", "LPS", "LPO", "SPACIO", "VENTURE", "VICTA", "TIPPER", "SFC", "KRYOTEC",
    "BUS", "CAB", "CHASSIS", "GOLD", "TRAILER", "TANKER", "DICOR", "EV", "LCV", "HGV",
    "HCV", "LGV", "CAR", "VAN", "MIXER", "CRANE", "SEATER"
]

# Your existing alias map
alias_map = {
    # existing corrections
    "INDGO": "INDIGO",
    "INDICO": "INDICA",
    "ZEXT": "ZEST",
    
    # new HARRIER variants
    "HARRIERXT": "HARRIER",
    "HARRIERXZ": "HARRIER",
    "HARRIERXZA": "HARRIER",
    
    # Additional aliases based on tata_keyword_frequencies.csv
    "SEIRRA": "SIERRA",
    "SAFAI": "SAFARI",
    "IDDIGO": "INDIGO",
    "TOAGO": "TIAGO",
    "VUSTA": "VISTA",
    "JAGUVAR": "JAGUAR"
}

def normalize(text):
    # Handle NaN/None values or any non-string types
    if pd.isna(text) or text is None:
        return ""
    # Convert to string if it's not already a string
    if not isinstance(text, str):
        text = str(text)
    # Then proceed with the original logic
    return re.sub(r'[^A-Z0-9 ]', '', text.upper())

def extract_model(text):
    """Extract TATA model from text using fuzzy matching"""
    txt = normalize(text)
    
    # If the text is empty after normalization, return "NOT FOUND"
    if not txt:
        return "NOT FOUND"
    
    # First, check for exact matches in aliases
    for bad, good in alias_map.items():
        if bad in txt:
            return good
    
    # Split the text into words for better matching
    words = txt.split()
    
    # Try to match each word with keywords
    for word in words:
        # Skip very short words (likely not model names)
        if len(word) < 3:
            continue
            
        # Find closest match using fuzzy matching
        match, score, _ = process.extractOne(
            word, 
            tata_model_keywords,
            scorer=fuzz.ratio,  # Use ratio for basic similarity
            score_cutoff=80    # Minimum similarity score (0-100)
        ) if word else (None, 0)
        
        if match:
            return match
    
    # If no match found in individual words, try matching with full text
    if len(txt) >= 3:  # Only try if text is substantial
        match, score, _ = process.extractOne(
            txt, 
            tata_model_keywords,
            scorer=fuzz.token_sort_ratio,  # Better for out-of-order token matching
            score_cutoff=70               # Lower threshold for full text
        )
        
        if match:
            return match
    
    return "NOT FOUND"

# Apply to DataFrame
# Assuming df['rc_maker_model'] already exists
# df['tata_model'] = df['rc_maker_model'].apply(extract_model)

# Test function with sample values
test_values = [
    "TATA INDICA V2 LS", 
    "TATA INDGO CS LS", 
    "TATA INDICO", 
    "TATA SAFAI STROME", 
    "TATA HARRIERXT", 
    "TATANANO CX",
    "TATA SEIRRA",
    "TATA VUSTA",
    "TATA TOAGO",
    "JAGUAR XF",
    "LAND ROVER DISCOVERY"
]

# Test the function
for val in test_values:
    print(f"{val} -> {extract_model(val)}")