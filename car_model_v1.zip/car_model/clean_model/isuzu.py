#!/usr/bin/env python
# Isuzu Vehicle Model Processing Script

import pandas as pd
import numpy as np
import re
from collections import Counter
from rapidfuzz import fuzz, process
import os

# Load the Isuzu dataset
isuzu_data = pd.read_csv('/home/bipin/Documents/kotak/car_model/manufacturer_data/ISUZU.csv')
print(f"Loaded {len(isuzu_data)} records from ISUZU.csv")

# Function to clean model names
def clean_model(text):
    if pd.isna(text) or text is None:
        return ""
        
    text = str(text).upper()
    
    # Remove manufacturer prefixes/suffixes
    text = re.sub(r'SML\s+ISUZU\s+LTD,?\s*', '', text)
    text = re.sub(r'ISUZU\s+MOTORS?\s+(?:INDIA\s+PVT\s+LTD|LTD\s+JAPAN),?\s*', '', text)
    text = re.sub(r'M/S\s+ISUZU\s+MOTORS?\s+INDIA\s+PRIVATE\s+LIMITED,?\s*', '', text)
    text = re.sub(r'\bISUZU\b\s*', '', text)  # Remove standalone ISUZU
    
    # Fix model name variations and spacing
    text = re.sub(r'D[-\s]*MAX', 'D-MAX', text)  # Fix D-MAX variations
    text = re.sub(r'MU[-\s]*X', 'MU-X', text)    # Fix MU-X variations
    text = re.sub(r'MU[-\s]*7', 'MU-7', text)    # Fix MU-7 variations
    text = re.sub(r'S[-\s]*CAB', 'S-CAB', text)  # Fix S-CAB variations
    
    # Standardize Swaraj Mazda variants
    text = re.sub(r'SWARAJ\s*MAZDA', 'SWARAJMAZDA', text)
    text = re.sub(r'SWARAJMAZDAÂ', 'SWARAJMAZDA', text)  # Remove special characters
    
    # Remove emission standards
    text = re.sub(r'\bBS(?:IV|VI?)\b', '', text)
    
    # Remove quotes and special characters
    text = text.replace('"', '').replace("'", "").replace("Â", "")
    
    # Remove trailing periods, commas, and spaces
    text = re.sub(r'[.,]$', '', text)
    
    return text.strip()

# Create a clean_model column with normalized data
isuzu_data['clean_model'] = isuzu_data['rc_maker_model'].apply(clean_model)

# Define known Isuzu model keywords to search for
model_keywords = [
    # Passenger vehicles
    'D-MAX', 'MU-X', 'MU-7', 'S-CAB',
    # Commercial vehicles
    'SARTAJ', 'SAMRAT', 'COSMO', 'SWARAJMAZDA',
    'T3500', 'SCHOOL BUS', 'ZT54', 'WT50TC',
    # Variants and configurations
    'FLATDECK', 'SPACECAB', '4WD', '2WD', 'AT', 
    'SUPER', 'MAXI CAB', '3.0L', 'CAB CHASSIS'
]

# Define an alias map for common misspellings or alternative notations
alias_map = {
    'D-MAX': ['DMAX', 'D MAX'],
    'MU-X': ['MUX', 'MU X'],
    'MU-7': ['MU7', 'MU 7'],
    'S-CAB': ['SCAB', 'S CAB'],
    'SWARAJMAZDA': ['SWARAJ MAZDA', 'SWARAJ', 'SM'],
    'FLATDECK': ['FLAT DECK', 'FLATBED'],
    'SPACECAB': ['SPACE CAB', 'SPACE'],
    'SCHOOL BUS': ['SCHOOLBUS']
}

# Function to normalize model variants by replacing with preferred terminology
def normalize(text):
    for key, aliases in alias_map.items():
        for alias in aliases:
            text = re.sub(r'\b' + re.escape(alias) + r'\b', key, text)
    return text

# Function to extract Isuzu model from the clean text
def extract_isuzu_model(text):
    if pd.isna(text) or not text:
        return "ISUZU OTHER"
    
    text = normalize(text)
    
    # Passenger Vehicles
    # MU-X SUV models
    if 'MU-X' in text:
        if '3.0L' in text:
            if '4WD' in text or '4X4' in text:
                return "ISUZU MU-X 3.0L 4WD"
            if '2WD' in text or '4X2' in text:
                return "ISUZU MU-X 3.0L 2WD"
            return "ISUZU MU-X 3.0L"
        return "ISUZU MU-X"
    
    # MU-7 SUV (older model)
    if 'MU-7' in text:
        return "ISUZU MU-7"
    
    # D-MAX pickup truck models
    if 'D-MAX' in text:
        if 'FLATDECK' in text:
            return "ISUZU D-MAX FLATDECK"
        if 'SPACECAB' in text:
            return "ISUZU D-MAX SPACECAB"
        return "ISUZU D-MAX"
    
    # S-CAB variant
    if 'S-CAB' in text:
        if '2WD' in text:
            return "ISUZU S-CAB 2WD"
        return "ISUZU S-CAB"
    
    # Commercial Vehicles
    # Sartaj truck models
    if 'SARTAJ' in text:
        if 'GS' in text:
            return "ISUZU SARTAJ GS"
        if 'MAXI CAB' in text:
            return "ISUZU SARTAJ MAXI CAB"
        if '3335' in text:
            return "ISUZU SARTAJ 3335"
        return "ISUZU SARTAJ"
    
    # Samrat truck models
    if 'SAMRAT' in text:
        if '2815' in text:
            if 'TIPPER' in text:
                return "ISUZU SAMRAT 2815 TIPPER"
            return "ISUZU SAMRAT 2815"
        return "ISUZU SAMRAT"
    
    # T3500 truck model
    if 'T3500' in text or 'T 3500' in text:
        return "ISUZU T3500"
    
    # Cosmo bus model
    if 'COSMO' in text:
        return "ISUZU COSMO"
    
    # ZT54 variants (typically buses)
    if 'ZT54' in text or 'ZT 54' in text:
        if 'TC' in text:
            if 'SUPER' in text:
                return "ISUZU ZT54 TC SUPER"
            return "ISUZU ZT54 TC"
        if 'SM' in text:
            return "ISUZU ZT54 SM"
        if 'AB' in text:
            return "ISUZU ZT54 AB"
        return "ISUZU ZT54"
    
    # WT50 bus models
    if 'WT50' in text or 'WT 50' in text:
        if 'TC' in text:
            if 'LMB' in text:
                return "ISUZU WT50 TC LMB BUS"
            return "ISUZU WT50 TC BUS"
        return "ISUZU WT50"
    
    # Generic school buses
    if 'SCHOOL BUS' in text:
        if 'S7' in text:
            if '4240' in text:
                return "ISUZU S7 4240 SCHOOL BUS"
            return "ISUZU S7 SCHOOL BUS"
        return "ISUZU SCHOOL BUS"
    
    # Generic Swaraj Mazda
    if 'SWARAJMAZDA' in text:
        if 'SUPER' in text:
            return "ISUZU SWARAJMAZDA SUPER"
        if 'BUS' in text:
            return "ISUZU SWARAJMAZDA BUS"
        return "ISUZU SWARAJMAZDA"
    
    # Try to match by keyword if the above specific matches failed
    for keyword in ['MU-X', 'MU-7', 'D-MAX', 'S-CAB', 'SARTAJ', 'SAMRAT', 'ZT54', 'WT50', 'COSMO']:
        if keyword in text:
            return f"ISUZU {keyword}"
    
    # Try to detect bus models
    if 'BUS' in text:
        return "ISUZU BUS"
    
    # Try to detect truck models
    if any(word in text for word in ['TRUCK', 'LKW', 'LORRY', 'TIPPER', 'DECK']):
        return "ISUZU TRUCK"
    
    # Default fallback
    return "ISUZU OTHER"

# Extract the model from the clean text
isuzu_data['isuzu_model'] = isuzu_data['clean_model'].apply(extract_isuzu_model)

# Create a final_model column with fallback to "ISUZU OTHER" if needed
isuzu_data['final_model'] = isuzu_data['isuzu_model'].apply(
    lambda x: x if x != "ISUZU OTHER" else "ISUZU OTHER"
)

# Save the processed data
output_dir = '/home/bipin/Documents/kotak/car_model/clean_model'
os.makedirs(output_dir, exist_ok=True)
isuzu_data.to_csv(f'{output_dir}/isuzu_processed.csv', index=False)

# Generate model mapping data
mapping_df = pd.DataFrame({
    'clean_model': isuzu_data['clean_model'].tolist(),
    'extracted_model': isuzu_data['final_model'].tolist()
})
mapping_df.to_csv(f'{output_dir}/isuzu_model_mapping.csv', index=False)

# Print summary statistics
total_models = len(isuzu_data)
mapped_models = len(isuzu_data[isuzu_data['final_model'] != "ISUZU OTHER"])
mapping_rate = (mapped_models / total_models) * 100

print(f"\nProcessed data saved to {output_dir}/isuzu_processed.csv")
print(f"Model mapping saved to {output_dir}/isuzu_model_mapping.csv")

print(f"\nSummary Statistics:")
print(f"Total models: {total_models}")
print(f"Successfully mapped models: {mapped_models}")
print(f"Mapping rate: {mapping_rate:.2f}%")

# Print model distribution
model_counts = Counter(isuzu_data['final_model'])
print("\nModel distribution:")
for model, count in model_counts.most_common():
    percentage = (count / total_models) * 100
    print(f"{model}: {count} ({percentage:.2f}%)")
