#!/usr/bin/env python
# Volvo Vehicle Model Processing Script

import pandas as pd
import numpy as np
import re
from collections import Counter
from rapidfuzz import fuzz, process
import os

# Load the Volvo dataset
volvo_data = pd.read_csv('/home/bipin/Documents/kotak/car_model/manufacturer_data/VOLVO.csv')
print(f"Loaded {len(volvo_data)} records from VOLVO.csv")

# Function to clean model names
def clean_model(text):
    if pd.isna(text) or text is None:
        return ""
        
    text = str(text).upper()
    
    # Remove manufacturer prefixes and common words
    text = re.sub(r'VOLVO\s+', '', text)
    text = re.sub(r'VOLOVO\s+', 'VOLVO ', text)  # Fix typo in some entries
    text = re.sub(r'CAR\s+', '', text)
    
    # Fix common model name variations and spacing
    text = re.sub(r'X\s*C', 'XC', text)  # Standardize XC models (XC 60 -> XC60)
    text = re.sub(r'S\s*(\d+)', r'S\1', text)  # Standardize S models (S 60 -> S60)
    text = re.sub(r'V\s*(\d+)', r'V\1', text)  # Standardize V models (V 40 -> V40)
    text = re.sub(r'(\d+)\s*X\s*(\d+)', r'\1X\2', text)  # Standardize axle config (6 X 4 -> 6X4)
    
    # Fix engine and trim designations
    text = re.sub(r'(\d+)\.(\d+)L', r'\1.\2L', text)  # Standardize engine displacement
    
    # Remove quotes that might be present in the data
    text = text.replace('"', '')
    
    # Remove trailing periods and commas
    text = re.sub(r'[.,]$', '', text)
    
    return text.strip()

# Create a clean_model column with normalized data
volvo_data['clean_model'] = volvo_data['rc_maker_model'].apply(clean_model)

# Define known Volvo model keywords to search for
model_keywords = [
    # Car lineup
    'XC90', 'XC60', 'XC40', 'S90', 'S60', 'V40', 'V60',
    # Trim designations
    'D3', 'D4', 'D5', 'T5', 'T6', 'T8', 'RECHARGE', 'SUMMUM', 'INSCRIPTION', 'MOMENTUM', 'R DESIGN',
    # Bus models
    '9400', 'B7R', 'B9R',
    # Truck models
    'FM', 'FMX', 'FH', 'FL'
]

# Define an alias map for common misspellings or alternative notations
alias_map = {
    'XC60': ['XC 60', 'XC60D5', 'XC 60D5'],
    'XC90': ['XC 90'],
    'S60': ['S 60'],
    '9400': ['9400 BUS'],
    'RECHARGE': ['RECHG']
}

# Function to normalize model variants by replacing with preferred terminology
def normalize(text):
    for key, aliases in alias_map.items():
        for alias in aliases:
            text = re.sub(r'\b' + re.escape(alias) + r'\b', key, text)
    return text

# Function to extract Volvo model from the clean text
def extract_volvo_model(text):
    if pd.isna(text) or not text:
        return "VOLVO OTHER"
    
    text = normalize(text)
    
    # Passenger Car Models
    # XC Series (SUVs)
    if 'XC90' in text:
        if 'D5' in text:
            return "VOLVO XC90 D5"
        if 'RECHARGE' in text or 'T8' in text:
            return "VOLVO XC90 RECHARGE"
        return "VOLVO XC90"
    
    if 'XC60' in text:
        if 'D5' in text or 'D5' in text:
            return "VOLVO XC60 D5"
        if 'D3' in text:
            return "VOLVO XC60 D3"
        if 'SUMMUM' in text:
            return "VOLVO XC60 SUMMUM"
        if 'B5' in text or 'HYBRID' in text:
            return "VOLVO XC60 HYBRID"
        return "VOLVO XC60"
    
    if 'XC40' in text:
        if 'RECHARGE' in text or 'P8' in text:
            return "VOLVO XC40 RECHARGE"
        return "VOLVO XC40"
    
    # S Series (Sedans)
    if 'S90' in text:
        if 'D4' in text:
            return "VOLVO S90 D4"
        return "VOLVO S90"
    
    if 'S60' in text:
        if 'D5' in text:
            return "VOLVO S60 D5"
        if 'D4' in text:
            return "VOLVO S60 D4"
        return "VOLVO S60"
    
    # V Series (Station Wagons)
    if 'V40' in text:
        if 'D3' in text:
            if 'R DESIGN' in text:
                return "VOLVO V40 D3 R-DESIGN"
            return "VOLVO V40 D3"
        return "VOLVO V40"
    
    # Bus Models
    if '9400' in text:
        if 'B9R' in text:
            return "VOLVO 9400 B9R"
        if 'B7R' in text:
            return "VOLVO 9400 B7R"
        return "VOLVO 9400"
    
    # Truck Models
    if 'FM' in text and not 'FMX' in text:
        if '440' in text:
            return "VOLVO FM 440"
        return "VOLVO FM"
    
    if 'FMX' in text:
        if '460' in text:
            return "VOLVO FMX 460"
        return "VOLVO FMX"
    
    if 'FH' in text:
        if '520' in text:
            return "VOLVO FH 520"
        return "VOLVO FH"
    
    # Try to match by keyword if the above specific matches failed
    for keyword in model_keywords:
        if keyword in text:
            if keyword in ['XC90', 'XC60', 'XC40', 'S90', 'S60', 'V40', 'V60']:
                return f"VOLVO {keyword}"
            elif keyword in ['9400', 'FM', 'FMX', 'FH']:
                return f"VOLVO {keyword}"
    
    # Default fallback
    return "VOLVO OTHER"

# Extract the model from the clean text
volvo_data['volvo_model'] = volvo_data['clean_model'].apply(extract_volvo_model)

# Create a final_model column with fallback to "VOLVO OTHER" if needed
volvo_data['final_model'] = volvo_data['volvo_model'].apply(
    lambda x: x if x != "VOLVO OTHER" else "VOLVO OTHER"
)

# Save the processed data
output_dir = '/home/bipin/Documents/kotak/car_model/clean_model'
os.makedirs(output_dir, exist_ok=True)
volvo_data.to_csv(f'{output_dir}/volvo_processed.csv', index=False)

# Generate model mapping data
mapping_df = pd.DataFrame({
    'clean_model': volvo_data['clean_model'].tolist(),
    'extracted_model': volvo_data['final_model'].tolist()
})
mapping_df.to_csv(f'{output_dir}/volvo_model_mapping.csv', index=False)

# Print summary statistics
total_models = len(volvo_data)
mapped_models = len(volvo_data[volvo_data['final_model'] != "VOLVO OTHER"])
mapping_rate = (mapped_models / total_models) * 100

print(f"\nProcessed data saved to {output_dir}/volvo_processed.csv")
print(f"Model mapping saved to {output_dir}/volvo_model_mapping.csv")

print(f"\nSummary Statistics:")
print(f"Total models: {total_models}")
print(f"Successfully mapped models: {mapped_models}")
print(f"Mapping rate: {mapping_rate:.2f}%")

# Print model distribution
model_counts = Counter(volvo_data['final_model'])
print("\nModel distribution:")
for model, count in model_counts.most_common():
    percentage = (count / total_models) * 100
    print(f"{model}: {count} ({percentage:.2f}%)")
