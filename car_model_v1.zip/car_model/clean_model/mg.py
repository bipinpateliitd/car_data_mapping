#!/usr/bin/env python
# MG (Morris Garages) Vehicle Model Processing Script

import pandas as pd
import numpy as np
import re
from collections import Counter
from rapidfuzz import fuzz, process
import os

# Load the MG dataset
mg_data = pd.read_csv('/home/bipin/Documents/kotak/car_model/manufacturer_data/MG.csv')
print(f"Loaded {len(mg_data)} records from MG.csv")

# Function to clean model names
def clean_model(text):
    if pd.isna(text) or text is None:
        return ""
        
    text = str(text).upper()
    
    # Remove manufacturer prefixes/suffixes and common words
    text = re.sub(r'MG\s+MOTOR\s+INDIA\s+PVT\s+LTD,?\s*', '', text)
    text = re.sub(r'JSW\s+MG\s+MOTOR\s+INDIA\s+PVT\s+LTD,?\s*', '', text)
    text = re.sub(r'M/S\s+MG\s+MOTOR\s+INDIA\s+PRIVATE\s+LIMITED,?\s*', '', text)
    text = re.sub(r',?\s*MG\b', '', text)  # Remove standalone MG
    text = re.sub(r'\bBSVI?\b', '', text)  # Remove BS6/BSVI emission standards
    
    # Standardize model names
    text = re.sub(r'HECTORPLU(?:S)?', 'HECTOR PLUS', text)  # Fix Hector Plus variations
    text = re.sub(r'HECTOR-', 'HECTOR ', text)  # Standardize hyphens
    text = re.sub(r'ZS\s*-?\s*EV', 'ZS EV', text)  # Standardize ZS EV
    text = re.sub(r'ZS\s+ASTOR', 'ASTOR', text)  # Standardize Astor (removing ZS prefix)
    
    # Standardize fuel/transmission types
    text = re.sub(r'DE(?:MT)?\b', 'DIESEL', text)  # DE/DEMT to DIESEL
    text = re.sub(r'\bPE\b', 'PETROL', text)  # PE to PETROL
    text = re.sub(r'\bCVT\b', 'AUTOMATIC', text)  # CVT to AUTOMATIC
    text = re.sub(r'\bMT\b', 'MANUAL', text)  # MT to MANUAL
    text = re.sub(r'\bDCT\b', 'AUTOMATIC', text)  # DCT to AUTOMATIC
    
    # Fix spacing and special characters
    text = re.sub(r'(\d+)\.(\d+)', r'\1.\2', text)  # Fix engine displacement spacing
    
    # Remove quotes and trailing punctuation
    text = text.replace('"', '').replace("'", "")
    text = re.sub(r'[.,]$', '', text)
    
    return text.strip()

# Create a clean_model column with normalized data
mg_data['clean_model'] = mg_data['rc_maker_model'].apply(clean_model)

# Define known MG model keywords to search for
model_keywords = [
    # Core model lineup
    'HECTOR', 'HECTOR PLUS', 'ASTOR', 'GLOSTER', 'ZS EV', 'WINDSOR',
    # Trim levels
    'SMART', 'SHARP', 'SAVVY', 'EXCLUSIVE', 'EXECUTIVE', 'SAVVYRED', 'SAVVYPRO', 'ESSENCE',
    # Engine/transmission
    'DIESEL', 'PETROL', 'HYBRID', 'MANUAL', 'AUTOMATIC', '2.0', '1.5',
    # Features
    '4X4', '4X2', '7 SEAT', '6 SEAT'
]

# Define an alias map for common misspellings or alternative notations
alias_map = {
    'HECTOR PLUS': ['HECTORPLUS', 'HECTOR+'],
    'ZS EV': ['ZS-EV', 'ZSEV'],
    'ASTOR': ['ZS ASTOR'],
    'DIESEL': ['DE', 'DEMT', 'DSL'],
    'PETROL': ['PE', 'GASOLINE'],
    'AUTOMATIC': ['CVT', 'DCT', 'AT'],
    'MANUAL': ['MT'],
    'SHARP': ['SHARPPRO']
}

# Function to normalize model variants by replacing with preferred terminology
def normalize(text):
    for key, aliases in alias_map.items():
        for alias in aliases:
            text = re.sub(r'\b' + re.escape(alias) + r'\b', key, text)
    return text

# Function to extract MG model from the clean text
def extract_mg_model(text):
    if pd.isna(text) or not text:
        return "MG OTHER"
    
    text = normalize(text)
    
    # Hector models (standard)
    if 'HECTOR' in text and 'PLUS' not in text:
        if 'DIESEL' in text:
            if 'SMART' in text:
                return "MG HECTOR DIESEL SMART"
            if 'SHARP' in text:
                return "MG HECTOR DIESEL SHARP"
            if 'SAVVY' in text:
                return "MG HECTOR DIESEL SAVVY"
            return "MG HECTOR DIESEL"
        
        if 'PETROL' in text or '1.5' in text:
            if 'HYBRID' in text:
                return "MG HECTOR HYBRID"
            if 'AUTOMATIC' in text:
                if 'SHARP' in text:
                    return "MG HECTOR PETROL AUTOMATIC SHARP"
                return "MG HECTOR PETROL AUTOMATIC"
            if 'MANUAL' in text:
                return "MG HECTOR PETROL MANUAL"
            return "MG HECTOR PETROL"
            
        if 'SMART' in text:
            return "MG HECTOR SMART"
        if 'SHARP' in text:
            return "MG HECTOR SHARP"
        if 'SAVVY' in text:
            return "MG HECTOR SAVVY"
        
        return "MG HECTOR"
    
    # Hector Plus models
    if 'HECTOR PLUS' in text:
        if '7 SEAT' in text or '7S' in text or '7SEAT' in text:
            return "MG HECTOR PLUS 7 SEATER"
        if '6 SEAT' in text or '6S' in text or '6SEAT' in text:
            return "MG HECTOR PLUS 6 SEATER"
        return "MG HECTOR PLUS"
    
    # Astor models
    if 'ASTOR' in text:
        if 'VTI-TECH' in text:
            if 'AUTOMATIC' in text or 'CVT' in text:
                if 'SMART' in text:
                    return "MG ASTOR AUTOMATIC SMART"
                if 'SAVVY' in text:
                    return "MG ASTOR AUTOMATIC SAVVY"
                if 'SAVVYRED' in text:
                    return "MG ASTOR AUTOMATIC SAVVY RED"
                return "MG ASTOR AUTOMATIC"
            if 'MANUAL' in text or 'MT' in text:
                if 'SHARP' in text:
                    return "MG ASTOR MANUAL SHARP"
                return "MG ASTOR MANUAL"
        return "MG ASTOR"
    
    # ZS EV models
    if 'ZS EV' in text:
        if 'EXCLUSIVE' in text:
            return "MG ZS EV EXCLUSIVE"
        if 'EXECUTIVE' in text:
            return "MG ZS EV EXECUTIVE"
        return "MG ZS EV"
    
    # Gloster models
    if 'GLOSTER' in text:
        if '4X4' in text:
            if '6 SEAT' in text or '6S' in text:
                return "MG GLOSTER 4X4 6 SEATER"
            if '7 SEAT' in text or '7S' in text:
                return "MG GLOSTER 4X4 7 SEATER"
            return "MG GLOSTER 4X4"
        if '4X2' in text:
            if '7 SEAT' in text or '7S' in text:
                return "MG GLOSTER 4X2 7 SEATER"
            return "MG GLOSTER 4X2"
        if 'SAVVY' in text:
            return "MG GLOSTER SAVVY"
        return "MG GLOSTER"
    
    # Windsor EV
    if 'WINDSOR' in text and 'EV' in text:
        if 'ESSENCE' in text:
            return "MG WINDSOR EV ESSENCE"
        return "MG WINDSOR EV"
    
    # Try to match by keyword if the above specific matches failed
    for keyword in ['HECTOR', 'ASTOR', 'GLOSTER', 'ZS EV', 'WINDSOR']:
        if keyword in text:
            return f"MG {keyword}"
    
    # Default fallback
    return "MG OTHER"

# Extract the model from the clean text
mg_data['mg_model'] = mg_data['clean_model'].apply(extract_mg_model)

# Create a final_model column with fallback to "MG OTHER" if needed
mg_data['final_model'] = mg_data['mg_model'].apply(
    lambda x: x if x != "MG OTHER" else "MG OTHER"
)

# Save the processed data
output_dir = '/home/bipin/Documents/kotak/car_model/clean_model'
os.makedirs(output_dir, exist_ok=True)
mg_data.to_csv(f'{output_dir}/mg_processed.csv', index=False)

# Generate model mapping data
mapping_df = pd.DataFrame({
    'clean_model': mg_data['clean_model'].tolist(),
    'extracted_model': mg_data['final_model'].tolist()
})
mapping_df.to_csv(f'{output_dir}/mg_model_mapping.csv', index=False)

# Print summary statistics
total_models = len(mg_data)
mapped_models = len(mg_data[mg_data['final_model'] != "MG OTHER"])
mapping_rate = (mapped_models / total_models) * 100

print(f"\nProcessed data saved to {output_dir}/mg_processed.csv")
print(f"Model mapping saved to {output_dir}/mg_model_mapping.csv")

print(f"\nSummary Statistics:")
print(f"Total models: {total_models}")
print(f"Successfully mapped models: {mapped_models}")
print(f"Mapping rate: {mapping_rate:.2f}%")

# Print model distribution
model_counts = Counter(mg_data['final_model'])
print("\nModel distribution:")
for model, count in model_counts.most_common():
    percentage = (count / total_models) * 100
    print(f"{model}: {count} ({percentage:.2f}%)")
