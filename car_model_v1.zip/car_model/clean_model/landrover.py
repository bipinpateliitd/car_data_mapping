#!/usr/bin/env python
# Land Rover Vehicle Model Processing Script

import pandas as pd
import numpy as np
import re
from collections import Counter
from rapidfuzz import fuzz, process
import os

# Load the Land Rover dataset
landrover_data = pd.read_csv('/home/bipin/Documents/kotak/car_model/manufacturer_data/LAND ROVER.csv')
print(f"Loaded {len(landrover_data)} records from LAND ROVER.csv")

# Function to clean model names
def clean_model(text):
    if pd.isna(text) or text is None:
        return ""
        
    text = str(text).upper()
    
    # Remove manufacturer prefixes
    text = re.sub(r'LAND\s+ROVER,?\s*', '', text)
    
    # Fix common model name variations
    text = re.sub(r'FREE\s+LANDER', 'FREELANDER', text)
    text = re.sub(r'RANGE\s+ROVER\s+EVOQUE', 'RANGE ROVER EVOQUE', text)
    text = re.sub(r'RR\s+EVOQUE', 'RANGE ROVER EVOQUE', text)
    text = re.sub(r'RANGE ROVER SPORT', 'RANGE ROVER SPORT', text)

    # Fix spacing and special characters
    text = re.sub(r'(\d+)\.(\d+)', r'\1.\2', text)  # Fix engine displacement spacing
    text = re.sub(r'(\d+)L\b', r'\1L', text)  # Standardize engine size notation
    
    # Remove trailing periods and commas
    text = re.sub(r'[.,]$', '', text)
    
    return text.strip()

# Create a clean_model column with normalized data
landrover_data['clean_model'] = landrover_data['rc_maker_model'].apply(clean_model)

# Define known Land Rover model keywords to search for
model_keywords = [
    # Range Rover lineup
    'RANGE ROVER', 'EVOQUE', 'SPORT', 'VOGUE', 'AUTOBIOGRAPHY',
    # Discovery lineup
    'DISCOVERY', 'DISCO',
    # Freelander
    'FREELANDER',
    # Engine/trim designations
    'SE', 'HSE', 'TD4', 'SD4', 'TDV6', 'V8', 'DIESEL', 'PETROL',
    # Body styles
    'COUPE', 'DYNAMIC', 'PURE'
]

# Define an alias map for common misspellings or alternative notations
alias_map = {
    'FREELANDER': ['FREE LANDER', 'FREELANDER2', 'FREE-LANDER'],
    'DISCOVERY': ['DISCO', 'DISCO4', 'DISCOVERY4', 'DISCOVERY 4'],
    'RANGE ROVER EVOQUE': ['RR EVOQUE', 'EVOQUE', 'RANGEROVER EVOQUE'],
    'RANGE ROVER SPORT': ['RR SPORT', 'RANGEROVER SPORT']
}

# Function to normalize model variants by replacing with preferred terminology
def normalize(text):
    for key, aliases in alias_map.items():
        for alias in aliases:
            text = re.sub(r'\b' + re.escape(alias) + r'\b', key, text)
    return text

# Function to extract Land Rover model from the clean text
def extract_landrover_model(text):
    if pd.isna(text) or not text:
        return "LAND ROVER OTHER"
        
    text = normalize(text)
    
    # Handle Range Rover family
    if 'RANGE ROVER EVOQUE' in text:
        if 'DYNAMIC' in text:
            return "LAND ROVER RANGE ROVER EVOQUE DYNAMIC"
        if 'PURE' in text:
            return "LAND ROVER RANGE ROVER EVOQUE PURE"
        if 'SD4' in text:
            return "LAND ROVER RANGE ROVER EVOQUE SD4"
        return "LAND ROVER RANGE ROVER EVOQUE"
    
    if 'RANGE ROVER SPORT' in text:
        if 'TDV6' in text or 'TDV 6' in text or '3.0' in text:
            return "LAND ROVER RANGE ROVER SPORT TDV6"
        return "LAND ROVER RANGE ROVER SPORT"
    
    if 'RANGE ROVER' in text:
        if '4.4' in text:
            return "LAND ROVER RANGE ROVER 4.4"
        if '5.0' in text:
            return "LAND ROVER RANGE ROVER 5.0"
        return "LAND ROVER RANGE ROVER"
    
    # Handle Discovery models
    if 'DISCOVERY' in text or 'DISCO' in text:
        if '4' in text:
            return "LAND ROVER DISCOVERY 4"
        return "LAND ROVER DISCOVERY"
    
    # Handle Freelander models
    if 'FREELANDER' in text:
        if 'TD4' in text or '2.2' in text:
            return "LAND ROVER FREELANDER TD4"
        return "LAND ROVER FREELANDER"
    
    # Try to extract model series if specific model extraction failed
    if 'RANGE ROVER' in text:
        return "LAND ROVER RANGE ROVER"
    if 'DISCOVERY' in text:
        return "LAND ROVER DISCOVERY"
    if 'FREELANDER' in text:
        return "LAND ROVER FREELANDER"
    
    # Default fallback
    return "LAND ROVER OTHER"

# Extract the model from the clean text
landrover_data['landrover_model'] = landrover_data['clean_model'].apply(extract_landrover_model)

# Create a final_model column with fallback to "LAND ROVER OTHER" if needed
landrover_data['final_model'] = landrover_data['landrover_model'].apply(
    lambda x: x if x != "LAND ROVER OTHER" else "LAND ROVER OTHER"
)

# Save the processed data
output_dir = '/home/bipin/Documents/kotak/car_model/clean_model'
os.makedirs(output_dir, exist_ok=True)
landrover_data.to_csv(f'{output_dir}/landrover_processed.csv', index=False)

# Generate model mapping data
mapping_df = pd.DataFrame({
    'clean_model': landrover_data['clean_model'].tolist(),
    'extracted_model': landrover_data['final_model'].tolist()
})
mapping_df.to_csv(f'{output_dir}/landrover_model_mapping.csv', index=False)

# Print summary statistics
total_models = len(landrover_data)
mapped_models = len(landrover_data[landrover_data['final_model'] != "LAND ROVER OTHER"])
mapping_rate = (mapped_models / total_models) * 100

print(f"\nProcessed data saved to {output_dir}/landrover_processed.csv")
print(f"Model mapping saved to {output_dir}/landrover_model_mapping.csv")

print(f"\nSummary Statistics:")
print(f"Total models: {total_models}")
print(f"Successfully mapped models: {mapped_models}")
print(f"Mapping rate: {mapping_rate:.2f}%")

# Print model distribution
model_counts = Counter(landrover_data['final_model'])
print("\nModel distribution:")
for model, count in model_counts.most_common():
    percentage = (count / total_models) * 100
    print(f"{model}: {count} ({percentage:.2f}%)")
