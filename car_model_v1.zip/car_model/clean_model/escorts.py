#!/usr/bin/env python
# Escorts Vehicle/Equipment Model Processing Script

import pandas as pd
import numpy as np
import re
from collections import Counter
from rapidfuzz import fuzz, process
import os

# Load the Escorts dataset
escorts_data = pd.read_csv('/home/bipin/Documents/kotak/car_model/manufacturer_data/ESCORTS.csv')
print(f"Loaded {len(escorts_data)} records from ESCORTS.csv")

# Function to clean model names
def clean_model(text):
    if pd.isna(text) or text is None:
        return ""
        
    text = str(text).upper()
    
    # Remove manufacturer prefixes/suffixes
    text = re.sub(r'ESCORTS\s+(?:LIMITED|LTD)(?:\s+\([^)]*\))?', '', text)
    text = re.sub(r'ESCORTS\s+KUBOTA\s+LIMITED(?:\s+\([^)]*\))?', '', text)
    text = re.sub(r'ESCORTSLTD', '', text)
    text = re.sub(r'ESCORTS[\s-]+', '', text)
    text = re.sub(r'^[\s,\-]*', '', text)  # Remove leading spaces, commas, and hyphens
    
    # Fix model name variations
    text = re.sub(r'DIGMAX\s+II', 'DIGMAX2', text)  # Standardize DIGMAX II
    text = re.sub(r'HYDRA\s+NXT', 'HYDRANXT', text)  # Standardize HYDRA NXT
    text = re.sub(r'(\d+)\s*(?:TON|T)', r'\1TON', text)  # Standardize tonnage specification
    
    # Clean specifications
    text = re.sub(r'(?:BS|BSIV?|BSVI?)\s*(?:III|IIIA|IV|VI?)?', '', text)  # Remove emission standards
    text = re.sub(r'(?:WITH|W/|W)\s+(?:OUTRIGGER|RIGGER)', 'OUTRIGGER', text)  # Standardize outrigger mention
    text = re.sub(r'(?:\d+\s*)?(?:FT|M)\s+(?:BOOM)?', '', text)  # Remove boom length specs
    text = re.sub(r'WITH\s+HELPER\s+SEAT\s+PLATF', '', text)  # Remove helper seat platform mention
    
    # Remove commas, periods, hyphens, and other punctuation
    text = re.sub(r'[,.\-\"]', ' ', text)
    text = re.sub(r'\s+', ' ', text).strip()
    
    return text

# Create a clean_model column with normalized data
escorts_data['clean_model'] = escorts_data['rc_maker_model'].apply(clean_model)

# Define known Escorts model keywords to search for
model_keywords = [
    'FT45', 'F20', 'F23', 'F15', 'DIGMAX', 'HYDRA14', 'HYDRANXT', 
    'TRX', 'JUNGLI', 'HD85', 'YAMAHA', 'FABIA'
]

# Define an alias map for common misspellings or alternative notations
alias_map = {
    # Construction equipment
    'FT45': ['FT 45', 'FT45', 'FT-45'],
    'F20': ['F 20', 'F20', 'F-20'],
    'F23': ['F 23', 'F23', 'F-23'],
    'F15': ['F 15', 'F15', 'F-15'],
    'DIGMAX2': ['DIGMAX2', 'DIGMAX II', 'DIGMAX-II', 'DIGMAX 2'],
    'HYDRA14': ['HYDRA 14', 'HYDRA14', 'HYDRA-14'],
    'HYDRANXT': ['HYDRANXT', 'HYDRA NXT', 'HYDRA-NXT'],
    'TRX15': ['TRX 15', 'TRX15', 'TRX-15'],
    'TRX17': ['TRX 17', 'TRX17', 'TRX-17'],
    'HD85': ['HD 85', 'HD85', 'HD-85', 'HD85 PLUS'],
    'JUNGLI': ['JUNGLI'],
    
    # Automotive/Motorcycle
    'YAMAHA RX100': ['YAMAHA RX100', 'RX100', 'RX 100'],
    'YAMAHA RX135': ['YAMAHA RX135', 'RX135', 'RX 135'],
    'FABIA': ['FABIA']
}

# Function to normalize model variants by replacing with preferred terminology
def normalize(text):
    for key, aliases in alias_map.items():
        for alias in aliases:
            text = re.sub(r'\b' + re.escape(alias) + r'\b', key, text)
    return text

# Function to extract Escorts model from the clean text
def extract_escorts_model(text):
    if pd.isna(text) or not text:
        return "ESCORTS OTHER"
    
    text = normalize(text)
    
    # Construction equipment models
    if 'FT45' in text:
        return "ESCORTS FT45"
    
    if 'F20' in text and '4WD' in text:
        return "ESCORTS F20 4WD"
    
    if 'F23' in text and '4WD' in text:
        return "ESCORTS F23 4WD"
    
    if 'F15' in text:
        if 'OUTRIGGER' in text:
            return "ESCORTS F15 OUTRIGGER"
        return "ESCORTS F15"
    
    if 'DIGMAX2' in text:
        if '4X4' in text:
            return "ESCORTS DIGMAX2 4X4"
        return "ESCORTS DIGMAX2"
    
    if 'HYDRA14' in text:
        return "ESCORTS HYDRA14"
    
    if 'HYDRANXT' in text:
        return "ESCORTS HYDRANXT"
    
    if 'TRX17' in text:
        return "ESCORTS TRX17"
    
    if 'TRX15' in text:
        return "ESCORTS TRX15"
    
    if 'HD85' in text:
        return "ESCORTS HD85 PLUS"
    
    if 'JUNGLI' in text and '4X4' in text:
        return "ESCORTS JUNGLI 4X4"
    
    # Automotive/Motorcycle models
    if 'YAMAHA RX100' in text:
        return "YAMAHA RX100"
    
    if 'YAMAHA RX135' in text:
        return "YAMAHA RX135"
    
    if 'FABIA' in text:
        return "SKODA FABIA"
    
    # Try fuzzy matching if direct keyword matching fails
    best_match = None
    best_score = 0
    for keyword in model_keywords:
        score = fuzz.partial_ratio(text, keyword)
        if score > best_score and score > 80:  # Only accept matches with high confidence
            best_score = score
            best_match = keyword
    
    if best_match:
        if best_match == 'YAMAHA':
            return "YAMAHA OTHER"
        if best_match == 'FABIA':
            return "SKODA FABIA"
        return f"ESCORTS {best_match}"
    
    # Default fallback
    return "ESCORTS OTHER"

# Extract the model from the clean text
escorts_data['escorts_model'] = escorts_data['clean_model'].apply(extract_escorts_model)

# Create a final_model column with fallback to "ESCORTS OTHER" if needed
escorts_data['final_model'] = escorts_data['escorts_model'].apply(
    lambda x: x if x != "ESCORTS OTHER" else "ESCORTS OTHER"
)

# Save the processed data
output_dir = '/home/bipin/Documents/kotak/car_model/clean_model'
os.makedirs(output_dir, exist_ok=True)
escorts_data.to_csv(f'{output_dir}/escorts_processed.csv', index=False)

# Generate model mapping data
mapping_df = pd.DataFrame({
    'clean_model': escorts_data['clean_model'].tolist(),
    'extracted_model': escorts_data['final_model'].tolist()
})
mapping_df.to_csv(f'{output_dir}/escorts_model_mapping.csv', index=False)

# Print summary statistics
total_models = len(escorts_data)
mapped_models = len(escorts_data[escorts_data['final_model'] != "ESCORTS OTHER"])
mapping_rate = (mapped_models / total_models) * 100

print(f"\nProcessed data saved to {output_dir}/escorts_processed.csv")
print(f"Model mapping saved to {output_dir}/escorts_model_mapping.csv")

print(f"\nSummary Statistics:")
print(f"Total models: {total_models}")
print(f"Successfully mapped models: {mapped_models}")
print(f"Mapping rate: {mapping_rate:.2f}%")

# Print model distribution
model_counts = Counter(escorts_data['final_model'])
print("\nModel distribution:")
for model, count in model_counts.most_common():
    percentage = (count / total_models) * 100
    print(f"{model}: {count} ({percentage:.2f}%)")
