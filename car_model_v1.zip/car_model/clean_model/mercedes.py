#!/usr/bin/env python
# Mercedes-Benz Vehicle Model Processing Script

import pandas as pd
import numpy as np
import re
from collections import Counter
from rapidfuzz import fuzz, process
import os

# Load the Mercedes dataset
mercedes_data = pd.read_csv('/home/bipin/Documents/kotak/car_model/manufacturer_data/MERCEDES.csv')
print(f"Loaded {len(mercedes_data)} records from MERCEDES.csv")

# Function to clean model names
def clean_model(text):
    if pd.isna(text) or text is None:
        return ""
        
    text = str(text).upper()
    
    # Remove manufacturer prefixes
    text = re.sub(r'MERCEDES-BENZ\s+INDIA\s+PVT\s+LTD\.?,?\s*', '', text)
    text = re.sub(r'MERCEDES-BENZ\s+AG\s*', '', text)
    text = re.sub(r'DAIMLER\s+AG\s+STUTTGART,?\s*', '', text)
    text = re.sub(r'MERCEDEZ\s+BENZ\s*-?\s*IMPORTED,?\s*', '', text)
    
    # Remove Mercedes prefixes but be careful with AMG models
    text = re.sub(r'^MERCEDES\s+BENZ\s+', '', text)
    text = re.sub(r'^MERCEDES[\s\-]+(?!AMG|MAYBACH)', '', text)
    text = re.sub(r'^MERCESS\s+BENZ\s+', '', text)
    text = re.sub(r'^MERCEDEZ\s+BENZ\s+', '', text)
    text = re.sub(r'^M\s+BENZ\s+', '', text)
    text = re.sub(r'^BENZ\s+', '', text)
    
    # Fix common model naming issues
    text = re.sub(r'W\s*(\d+)', r'W\1', text)  # Fix spacing in chassis codes
    text = re.sub(r'(\d+)\s*CDI', r'\1CDI', text)  # Fix spacing in engine designations
    text = re.sub(r'(\d+)\s*D\b', r'\1D', text)
    text = re.sub(r'(\d+)\s*CGI', r'\1CGI', text)
    
    return text.strip()

# Create a clean_model column with normalized data
mercedes_data['clean_model'] = mercedes_data['rc_maker_model'].apply(clean_model)

# Define known Mercedes model keywords to search for
model_keywords = [
    # C-Class models
    'C180', 'C200', 'C220', 'C250', 'C300', 'C350', 'C43', 'C63',
    # E-Class models
    'E200', 'E220', 'E230', 'E250', 'E300', 'E320', 'E350', 'E400', 'E63',
    # S-Class models
    'S350', 'S400', 'S450', 'S500', 'S560', 'S580', 'S600', 'S63', 'S65',
    # GLA-Class models
    'GLA180', 'GLA200', 'GLA220', 'GLA250', 'GLA35', 'GLA45',
    # GLC-Class models
    'GLC200', 'GLC220', 'GLC250', 'GLC300', 'GLC43', 'GLC63',
    # GLE-Class (and former ML-Class) models
    'GLE250', 'GLE300', 'GLE350', 'GLE400', 'GLE450', 'GLE500', 'GLE53', 'GLE63',
    'ML250', 'ML270', 'ML280', 'ML300', 'ML320', 'ML350', 'ML400', 'ML500', 'ML63',
    # GL/GLS-Class models
    'GL350', 'GL400', 'GL450', 'GL500', 'GL63',
    'GLS350', 'GLS400', 'GLS450', 'GLS500', 'GLS580', 'GLS600', 'GLS63',
    # Other models
    'A180', 'A200', 'A220', 'A250', 'A35', 'A45',
    'B180', 'B200', 'B220',
    'CLA180', 'CLA200', 'CLA220', 'CLA250', 'CLA35', 'CLA45',
    'CLS350', 'CLS400', 'CLS450', 'CLS500', 'CLS53', 'CLS63',
    # Special designations
    'AMG', 'MAYBACH', '4MATIC', 'BLUETEC', 'CABRIOLET', 'COUPE', 'SALOON'
]

# Define an alias map for common misspellings or alternative notations
alias_map = {
    'CDI': ['DIESEL', 'D'],
    'CGI': ['PETROL'],
    '4MATIC': ['4M', '4-MATIC'],
    'BLUETEC': ['BLUE EFFICIENCY', 'BLUE EFFICIEN', 'BE'],
    'MAYBACH': ['MAYBAC', 'MAYBCH'],
    'C 180': ['C180'],
    'C 200': ['C200'],
    'C 220': ['C220'],
    'C 250': ['C250'],
    'C 300': ['C300'],
    'C 350': ['C350'],
    'E 200': ['E200'],
    'E 220': ['E220'],
    'E 230': ['E230'],
    'E 250': ['E250'],
    'E 320': ['E320'],
    'E 350': ['E350'],
    'S 350': ['S350'],
    'S 400': ['S400'],
    'S 500': ['S500'],
    'S 560': ['S560'],
    'S 580': ['S580'],
    'ML 250': ['ML250'],
    'ML 350': ['ML350'],
    'GLA 200': ['GLA200'],
    'GLA 250': ['GLA250'],
    'GLC 300': ['GLC300'],
    'GLE 250': ['GLE250'],
    'GLE 350': ['GLE350'],
    'GL 350': ['GL350'],
    'GLS 350': ['GLS350']
}

# Function to normalize model variants by replacing with preferred terminology
def normalize(text):
    for key, aliases in alias_map.items():
        for alias in aliases:
            text = re.sub(r'\b' + re.escape(alias) + r'\b', key, text)
    return text

# Function to extract Mercedes model from the clean text
def extract_mercedes_model(text):
    if pd.isna(text) or not text:
        return "MERCEDES OTHER"
        
    text = normalize(text)
    
    # Look for specific model patterns
    
    # C-Class
    if re.search(r'\bC\s*(\d+)', text):
        model_num = re.search(r'\bC\s*(\d+)', text).group(1)
        if 'AMG' in text and ('43' in text or '63' in text):
            return f"MERCEDES AMG C{model_num}"
        return f"MERCEDES C{model_num}"
    
    # E-Class
    if re.search(r'\bE\s*(\d+)', text):
        model_num = re.search(r'\bE\s*(\d+)', text).group(1)
        if 'AMG' in text and ('43' in text or '53' in text or '63' in text):
            return f"MERCEDES AMG E{model_num}"
        return f"MERCEDES E{model_num}"
    
    # S-Class
    if re.search(r'\bS\s*(\d+)', text):
        model_num = re.search(r'\bS\s*(\d+)', text).group(1)
        if 'MAYBACH' in text:
            return f"MERCEDES MAYBACH S{model_num}"
        if 'AMG' in text and ('63' in text or '65' in text):
            return f"MERCEDES AMG S{model_num}"
        return f"MERCEDES S{model_num}"
    
    # GLA-Class
    if re.search(r'\bGLA\s*(\d+)', text):
        model_num = re.search(r'\bGLA\s*(\d+)', text).group(1)
        if 'AMG' in text:
            return f"MERCEDES AMG GLA{model_num}"
        return f"MERCEDES GLA{model_num}"
    
    # GLC-Class
    if re.search(r'\bGLC\s*(\d+)', text):
        model_num = re.search(r'\bGLC\s*(\d+)', text).group(1)
        if 'AMG' in text:
            return f"MERCEDES AMG GLC{model_num}"
        return f"MERCEDES GLC{model_num}"
    
    # GLE-Class (and former ML-Class)
    if re.search(r'\b(GLE|ML)\s*(\d+)', text):
        prefix = re.search(r'\b(GLE|ML)\s*(\d+)', text).group(1)
        model_num = re.search(r'\b(GLE|ML)\s*(\d+)', text).group(2)
        if prefix == 'ML':
            if 'AMG' in text:
                return f"MERCEDES AMG ML{model_num}"
            return f"MERCEDES ML{model_num}"
        else:
            if 'AMG' in text:
                return f"MERCEDES AMG GLE{model_num}"
            return f"MERCEDES GLE{model_num}"
    
    # GL/GLS-Class
    if re.search(r'\b(GLS|GL)\s*(\d+)', text):
        prefix = re.search(r'\b(GLS|GL)\s*(\d+)', text).group(1)
        model_num = re.search(r'\b(GLS|GL)\s*(\d+)', text).group(2)
        if 'AMG' in text:
            return f"MERCEDES AMG {prefix}{model_num}"
        return f"MERCEDES {prefix}{model_num}"
    
    # A-Class
    if re.search(r'\bA\s*(\d+)', text):
        model_num = re.search(r'\bA\s*(\d+)', text).group(1)
        if 'AMG' in text:
            return f"MERCEDES AMG A{model_num}"
        return f"MERCEDES A{model_num}"
    
    # B-Class
    if re.search(r'\bB\s*(\d+)', text):
        model_num = re.search(r'\bB\s*(\d+)', text).group(1)
        return f"MERCEDES B{model_num}"
    
    # CLA-Class
    if re.search(r'\bCLA\s*(\d+)', text):
        model_num = re.search(r'\bCLA\s*(\d+)', text).group(1)
        if 'AMG' in text:
            return f"MERCEDES AMG CLA{model_num}"
        return f"MERCEDES CLA{model_num}"
    
    # CLS-Class
    if re.search(r'\bCLS\s*(\d+)', text):
        model_num = re.search(r'\bCLS\s*(\d+)', text).group(1)
        if 'AMG' in text:
            return f"MERCEDES AMG CLS{model_num}"
        return f"MERCEDES CLS{model_num}"
    
    # If no specific pattern matched but we have keywords
    for keyword in model_keywords:
        if keyword in text:
            if keyword == 'AMG':
                return "MERCEDES AMG OTHER"
            if keyword == 'MAYBACH':
                return "MERCEDES MAYBACH OTHER"
            if keyword == '4MATIC' or keyword == 'BLUETEC' or keyword == 'CABRIOLET' or keyword == 'COUPE' or keyword == 'SALOON':
                continue
            return f"MERCEDES {keyword}"
    
    # Default fallback
    return "MERCEDES OTHER"

# Extract the model from the clean text
mercedes_data['mercedes_model'] = mercedes_data['clean_model'].apply(extract_mercedes_model)

# Create a final_model column with fallback to "MERCEDES OTHER" if needed
mercedes_data['final_model'] = mercedes_data['mercedes_model'].apply(
    lambda x: x if x != "MERCEDES OTHER" else "MERCEDES OTHER"
)

# Save the processed data
output_dir = '/home/bipin/Documents/kotak/car_model/clean_model'
os.makedirs(output_dir, exist_ok=True)
mercedes_data.to_csv(f'{output_dir}/mercedes_processed.csv', index=False)

# Generate model mapping data
mapping_df = pd.DataFrame({
    'clean_model': mercedes_data['clean_model'].tolist(),
    'extracted_model': mercedes_data['final_model'].tolist()
})
mapping_df.to_csv(f'{output_dir}/mercedes_model_mapping.csv', index=False)

# Print summary statistics
total_models = len(mercedes_data)
mapped_models = len(mercedes_data[mercedes_data['final_model'] != "MERCEDES OTHER"])
mapping_rate = (mapped_models / total_models) * 100

print(f"\nProcessed data saved to {output_dir}/mercedes_processed.csv")
print(f"Model mapping saved to {output_dir}/mercedes_model_mapping.csv")

print(f"\nSummary Statistics:")
print(f"Total models: {total_models}")
print(f"Successfully mapped models: {mapped_models}")
print(f"Mapping rate: {mapping_rate:.2f}%")

# Print model distribution
model_counts = Counter(mercedes_data['final_model'])
print("\nModel distribution:")
for model, count in model_counts.most_common():
    percentage = (count / total_models) * 100
    print(f"{model}: {count} ({percentage:.2f}%)")