#!/usr/bin/env python
# Hyundai Vehicle Model Processing Script

import pandas as pd
import numpy as np
import re
from collections import Counter
from rapidfuzz import fuzz, process
import os

# Load the Hyundai dataset
hyundai_data = pd.read_csv('/home/bipin/Documents/kotak/car_model/manufacturer_data/HYUNDAI.csv')
print(f"Loaded {len(hyundai_data)} records from HYUNDAI.csv")

# Function to clean model names
def clean_model(text):
    if pd.isna(text) or text is None:
        return ""
        
    text = str(text).upper()
    
    # Remove manufacturer prefixes/suffixes
    text = re.sub(r'HYUNDAI\s+MOTOR(?:\s+INDIA)?\s+(?:LTD|LIMITED),?\s*', '', text)
    text = re.sub(r'M/S\s+HYUNDAI\s+MOTOR\s+INDIA\s+PRIVATE\s+LIMITED,?\s*', '', text)
    text = re.sub(r'\bHYUNDAI(?:MOT)?\b\s*', '', text)  # Remove standalone HYUNDAI
    
    # Fix model name variations and spacing
    text = re.sub(r'\bI[-\s]*10\b', 'I10', text)  # Fix I10 variations
    text = re.sub(r'\bI[-\s]*20\b', 'I20', text)  # Fix I20 variations
    text = re.sub(r'\bI[-\s]*30\b', 'I30', text)  # Fix I30 variations
    text = re.sub(r'GRAND\s*I\s*10', 'GRAND I10', text)  # Fix Grand i10 variations
    text = re.sub(r'H\s*N\s*I\s*20', 'I20', text)  # Fix HN I20 variants
    
    # Common typos in the data
    text = re.sub(r'GETX', 'GETZ', text)  # Fix GETZ typo
    text = re.sub(r'MAHGNA', 'MAGNA', text)  # Fix MAGNA typo
    
    # Remove emission standards
    text = re.sub(r'\bBS[-\s]*(?:IV|VI?)\b', '', text)
    
    # Standardize trim levels
    text = re.sub(r'ASTA\s*\(\s*O(?:PTION)?\s*\)', 'ASTA O', text)  # Fix ASTA (O) variations
    text = re.sub(r'SPORTZ\s*\(\s*O(?:PTION)?\s*\)', 'SPORTZ O', text)  # Fix SPORTZ (O) variations
    text = re.sub(r'SX\s*\(\s*O(?:PTION)?\s*\)', 'SX O', text)  # Fix SX (O) variations
    
    # Remove quotes, special characters, and trailing punctuation
    text = text.replace('"', '').replace("'", "")
    text = text.replace('(', '').replace(')', '')
    text = re.sub(r'[.,]$', '', text)
    
    return text.strip()

# Create a clean_model column with normalized data
hyundai_data['clean_model'] = hyundai_data['rc_maker_model'].apply(clean_model)

# Define known Hyundai model keywords to search for
model_keywords = [
    # Hatchbacks
    'I10', 'GRAND I10', 'I20', 'NEW I20', 'SANTRO', 'EON',
    # Sedans
    'VERNA', 'XCENT', 'ACCENT', 'ELANTRA', 'SONATA',
    # SUVs & Crossovers
    'CRETA', 'VENUE', 'TUCSON', 'KONA', 'ALCAZAR',
    # Trim Levels
    'SPORTZ', 'MAGNA', 'ASTA', 'ERA', 'ELITE', 'MAGNA+', 'SX', 'S',
    # Engine/Transmission variants
    'VTVT', 'CRDI', 'KAPPA', 'AT', 'MT', 'AMT', 'DCT', 'GDI'
]

# Define an alias map for common misspellings or alternative notations
alias_map = {
    'I10': ['I 10', 'I-10'],
    'I20': ['I 20', 'I-20', 'HN I20', 'HNI20'],
    'GRAND I10': ['GRAND I 10', 'GRAND-I10', 'GRANDI10'],
    'VERNA': ['VERNA FL', 'FL VERNA'],
    'SANTRO': ['SANTRO XP', 'XING'],
    'ASTA O': ['ASTA (O)', 'ASTAO'],
    'SPORTZ O': ['SPORTZ (O)', 'SPORTZO'],
    'SX O': ['SX (O)', 'SXO'],
    'MAGNA+': ['MAGNA PLUS', 'MAGNA +'],
    'CRDI': ['CRDi', 'CRD-I'],
    'VTVT': ['VTVT', 'VT-VT'],
    'KAPPA': ['KAPA']
}

# Function to normalize model variants by replacing with preferred terminology
def normalize(text):
    for key, aliases in alias_map.items():
        for alias in aliases:
            text = re.sub(r'\b' + re.escape(alias) + r'\b', key, text)
    return text

# Function to extract Hyundai model from the clean text
def extract_hyundai_model(text):
    if pd.isna(text) or not text:
        return "HYUNDAI OTHER"
    
    text = normalize(text)
    
    # i10 variants
    if 'I10' in text and 'GRAND' not in text:
        if 'SPORTS' in text:
            return "HYUNDAI I10 SPORTS"
        if 'ERA' in text:
            return "HYUNDAI I10 ERA"
        if 'MAGNA' in text:
            return "HYUNDAI I10 MAGNA"
        if 'SPORTZ' in text:
            return "HYUNDAI I10 SPORTZ"
        if 'ASTA' in text:
            return "HYUNDAI I10 ASTA"
        return "HYUNDAI I10"
    
    # Grand i10 variants
    if 'GRAND I10' in text:
        if 'NIOS' in text:
            if 'SPORTZ' in text:
                if 'AMT' in text:
                    return "HYUNDAI GRAND I10 NIOS SPORTZ AMT"
                return "HYUNDAI GRAND I10 NIOS SPORTZ"
            if 'MAGNA' in text:
                return "HYUNDAI GRAND I10 NIOS MAGNA"
            if 'ASTA' in text:
                return "HYUNDAI GRAND I10 NIOS ASTA"
            return "HYUNDAI GRAND I10 NIOS"
        
        if 'CRDI' in text:
            if 'ASTA' in text:
                return "HYUNDAI GRAND I10 CRDI ASTA"
            if 'SPORTZ' in text:
                return "HYUNDAI GRAND I10 CRDI SPORTZ"
            return "HYUNDAI GRAND I10 CRDI"
            
        if 'SPORTZ' in text:
            return "HYUNDAI GRAND I10 SPORTZ"
        if 'MAGNA' in text:
            return "HYUNDAI GRAND I10 MAGNA"
        if 'ASTA' in text:
            if 'O' in text:
                return "HYUNDAI GRAND I10 ASTA O"
            return "HYUNDAI GRAND I10 ASTA"
        return "HYUNDAI GRAND I10"
    
    # i20 variants
    if 'I20' in text and 'ELITE' not in text:
        if 'NEW' in text:
            return "HYUNDAI NEW I20"
        
        if 'CRDI' in text:
            if 'ASTA' in text:
                return "HYUNDAI I20 CRDI ASTA"
            if 'SPORTZ' in text:
                return "HYUNDAI I20 CRDI SPORTZ"
            return "HYUNDAI I20 CRDI"
            
        if 'SPORTZ' in text:
            if 'O' in text:
                return "HYUNDAI I20 SPORTZ O"
            return "HYUNDAI I20 SPORTZ"
        if 'MAGNA' in text:
            return "HYUNDAI I20 MAGNA"
        if 'ASTA' in text:
            if 'O' in text:
                return "HYUNDAI I20 ASTA O"
            return "HYUNDAI I20 ASTA"
        return "HYUNDAI I20"
    
    # i20 Elite variants
    if 'ELITE' in text and 'I20' in text:
        if 'SPORTZ' in text:
            return "HYUNDAI I20 ELITE SPORTZ"
        if 'ASTA' in text:
            return "HYUNDAI I20 ELITE ASTA"
        if 'MAGNA' in text:
            return "HYUNDAI I20 ELITE MAGNA"
        return "HYUNDAI I20 ELITE"
    
    # Creta variants
    if 'CRETA' in text:
        if '1.4' in text and 'TURBO' in text:
            if 'DCT' in text:
                if 'SX' in text:
                    return "HYUNDAI CRETA 1.4 TURBO DCT SX"
                return "HYUNDAI CRETA 1.4 TURBO DCT"
            return "HYUNDAI CRETA 1.4 TURBO"
        
        if 'SX' in text:
            if 'O' in text:
                return "HYUNDAI CRETA SX O"
            return "HYUNDAI CRETA SX"
        if 'S' in text:
            return "HYUNDAI CRETA S"
        if 'E' in text:
            return "HYUNDAI CRETA E"
        return "HYUNDAI CRETA"
    
    # Verna variants
    if 'VERNA' in text:
        if 'CRDI' in text:
            if 'EX' in text:
                return "HYUNDAI VERNA CRDI EX"
            if 'SX' in text:
                if 'O' in text:
                    return "HYUNDAI VERNA CRDI SX O"
                return "HYUNDAI VERNA CRDI SX"
            return "HYUNDAI VERNA CRDI"
            
        if 'VTVT' in text:
            if 'SX' in text:
                if 'O' in text:
                    if 'AT' in text:
                        return "HYUNDAI VERNA VTVT SX O AT"
                    return "HYUNDAI VERNA VTVT SX O"
                return "HYUNDAI VERNA VTVT SX"
            return "HYUNDAI VERNA VTVT"
            
        if 'GLS' in text:
            return "HYUNDAI VERNA GLS"
        
        if 'AT' in text or 'AUTO' in text:
            return "HYUNDAI VERNA AT"
            
        return "HYUNDAI VERNA"
    
    # Santro variants
    if 'SANTRO' in text:
        if 'XP' in text:
            return "HYUNDAI SANTRO XP"
        if 'AMT' in text:
            if 'CORPORATE' in text:
                return "HYUNDAI SANTRO AMT CORPORATE"
            return "HYUNDAI SANTRO AMT"
        if 'GLS' in text:
            return "HYUNDAI SANTRO GLS"
        if 'ERA' in text:
            return "HYUNDAI SANTRO ERA"
        if 'MAGNA' in text:
            return "HYUNDAI SANTRO MAGNA"
        return "HYUNDAI SANTRO"
    
    # EON variants
    if 'EON' in text:
        if 'ERA' in text:
            return "HYUNDAI EON ERA"
        if 'MAGNA' in text:
            if '+' in text:
                return "HYUNDAI EON MAGNA+"
            return "HYUNDAI EON MAGNA"
        return "HYUNDAI EON"
    
    # Try to match by keyword if the above specific matches failed
    for keyword in ['I10', 'GRAND I10', 'I20', 'CRETA', 'VERNA', 'SANTRO', 'EON', 'TUCSON', 'VENUE', 'XCENT', 'ELANTRA', 'ALCAZAR']:
        if keyword in text:
            return f"HYUNDAI {keyword}"
    
    # Default fallback
    return "HYUNDAI OTHER"

# Extract the model from the clean text
hyundai_data['hyundai_model'] = hyundai_data['clean_model'].apply(extract_hyundai_model)

# Create a final_model column with fallback to "HYUNDAI OTHER" if needed
hyundai_data['final_model'] = hyundai_data['hyundai_model'].apply(
    lambda x: x if x != "HYUNDAI OTHER" else "HYUNDAI OTHER"
)

# Save the processed data
output_dir = '/home/bipin/Documents/kotak/car_model/clean_model'
os.makedirs(output_dir, exist_ok=True)
hyundai_data.to_csv(f'{output_dir}/hyundai_processed.csv', index=False)

# Generate model mapping data
mapping_df = pd.DataFrame({
    'clean_model': hyundai_data['clean_model'].tolist(),
    'extracted_model': hyundai_data['final_model'].tolist()
})
mapping_df.to_csv(f'{output_dir}/hyundai_model_mapping.csv', index=False)

# Print summary statistics
total_models = len(hyundai_data)
mapped_models = len(hyundai_data[hyundai_data['final_model'] != "HYUNDAI OTHER"])
mapping_rate = (mapped_models / total_models) * 100

print(f"\nProcessed data saved to {output_dir}/hyundai_processed.csv")
print(f"Model mapping saved to {output_dir}/hyundai_model_mapping.csv")

print(f"\nSummary Statistics:")
print(f"Total models: {total_models}")
print(f"Successfully mapped models: {mapped_models}")
print(f"Mapping rate: {mapping_rate:.2f}%")

# Print model distribution
model_counts = Counter(hyundai_data['final_model'])
print("\nModel distribution:")
for model, count in model_counts.most_common():
    percentage = (count / total_models) * 100
    print(f"{model}: {count} ({percentage:.2f}%)")
