#!/usr/bin/env python
# Rolls Royce Vehicle Model Processing Script

import pandas as pd
import numpy as np
import re
from collections import Counter
from rapidfuzz import fuzz, process
import os

# Load both Rolls Royce datasets and merge them
rollsroyce_data1 = pd.read_csv('/home/bipin/Documents/kotak/car_model/manufacturer_data/ROLLS ROYCE.csv')
print(f"Loaded {len(rollsroyce_data1)} records from 'ROLLS ROYCE.csv'")

try:
    rollsroyce_data2 = pd.read_csv('/home/bipin/Documents/kotak/car_model/manufacturer_data/ROLLS-ROYCE.csv')
    print(f"Loaded {len(rollsroyce_data2)} records from 'ROLLS-ROYCE.csv'")
    # Combine datasets
    rollsroyce_data = pd.concat([rollsroyce_data1, rollsroyce_data2], ignore_index=True)
    print(f"Combined dataset has {len(rollsroyce_data)} records")
except FileNotFoundError:
    print("ROLLS-ROYCE.csv not found, proceeding with just ROLLS ROYCE.csv")
    rollsroyce_data = rollsroyce_data1

# Function to clean model names
def clean_model(text):
    if pd.isna(text) or text is None:
        return ""
        
    text = str(text).upper()
    
    # Remove manufacturer prefixes/suffixes
    text = re.sub(r'ROLLS[\s-]*ROYCE(?:E)?(?:S)?(?:\s+MOTOR(?:\s+CARS)?)?', '', text)
    text = re.sub(r'\(IMPORTER:.*?\)', '', text)  # Remove importer information
    text = re.sub(r'^[\s,]*', '', text)  # Remove leading spaces and commas
    
    # Fix model name variations and spacing
    text = re.sub(r'\bRR\b', 'ROLLS ROYCE', text)  # Fix RR abbreviation
    text = re.sub(r'\bEWB\b', 'EXTENDED WHEELBASE', text)  # Expand EWB
    text = re.sub(r'\bSWB\b', 'STANDARD WHEELBASE', text)  # Expand SWB
    
    # Remove chassis/spec codes
    text = re.sub(r'\b(?:FK|FJ|TV|XZ|TT)[-\s]*\d+(?:[-\s]*RHD|[-\s]*RDH)?\b', '', text)
    text = re.sub(r'\([^)]*\d+[^)]*\)', '', text)  # Remove codes in parentheses
    
    # Remove quotes, special characters, and trailing punctuation
    text = text.replace('"', '').replace("'", "")
    text = re.sub(r'[\(\),.]', ' ', text)  # Replace brackets and punctuation with spaces
    
    # Fix multiple spaces
    text = re.sub(r'\s+', ' ', text).strip()
    
    return text

# Create a clean_model column with normalized data
rollsroyce_data['clean_model'] = rollsroyce_data['rc_maker_model'].apply(clean_model)

# Define known Rolls Royce model keywords to search for
model_keywords = [
    'GHOST', 'PHANTOM', 'CULLINAN', 'SILVER CLOUD',
    'WRAITH', 'DAWN', 'BLACK BADGE',
    'EXTENDED WHEELBASE', 'STANDARD WHEELBASE'
]

# Define an alias map for common misspellings or alternative notations
alias_map = {
    'GHOST': ['GHOST'],
    'PHANTOM': ['PHANTOM'],
    'CULLINAN': ['CULLINAN'],
    'SILVER CLOUD': ['SILVER CLOUD'],
    'EXTENDED WHEELBASE': ['EWB', 'EXTENDED'],
    'STANDARD WHEELBASE': ['SWB', 'STANDARD']
}

# Function to normalize model variants by replacing with preferred terminology
def normalize(text):
    for key, aliases in alias_map.items():
        for alias in aliases:
            text = re.sub(r'\b' + re.escape(alias) + r'\b', key, text)
    return text

# Function to extract Rolls Royce model from the clean text
def extract_rollsroyce_model(text):
    if pd.isna(text) or not text:
        return "ROLLS ROYCE OTHER"
    
    text = normalize(text)
    
    # Ghost variants
    if 'GHOST' in text:
        if 'EXTENDED WHEELBASE' in text:
            return "ROLLS ROYCE GHOST EXTENDED WHEELBASE"
        if 'BLACK BADGE' in text:
            return "ROLLS ROYCE GHOST BLACK BADGE"
        return "ROLLS ROYCE GHOST"
    
    # Phantom variants
    if 'PHANTOM' in text:
        if 'EXTENDED WHEELBASE' in text:
            return "ROLLS ROYCE PHANTOM EXTENDED WHEELBASE"
        if 'STANDARD WHEELBASE' in text:
            return "ROLLS ROYCE PHANTOM STANDARD WHEELBASE"
        if 'COUPE' in text:
            return "ROLLS ROYCE PHANTOM COUPE"
        if 'DROPHEAD' in text:
            return "ROLLS ROYCE PHANTOM DROPHEAD"
        return "ROLLS ROYCE PHANTOM"
    
    # Cullinan variants
    if 'CULLINAN' in text:
        if 'BLACK BADGE' in text:
            return "ROLLS ROYCE CULLINAN BLACK BADGE"
        return "ROLLS ROYCE CULLINAN"
    
    # Other distinct models
    if 'SILVER CLOUD' in text:
        return "ROLLS ROYCE SILVER CLOUD"
    
    if 'WRAITH' in text:
        if 'BLACK BADGE' in text:
            return "ROLLS ROYCE WRAITH BLACK BADGE"
        return "ROLLS ROYCE WRAITH"
    
    if 'DAWN' in text:
        if 'BLACK BADGE' in text:
            return "ROLLS ROYCE DAWN BLACK BADGE"
        return "ROLLS ROYCE DAWN"
    
    # Try to match by keyword if the above specific matches failed
    for keyword in ['GHOST', 'PHANTOM', 'CULLINAN', 'SILVER CLOUD', 'WRAITH', 'DAWN']:
        if keyword in text:
            return f"ROLLS ROYCE {keyword}"
    
    # Default fallback
    return "ROLLS ROYCE OTHER"

# Extract the model from the clean text
rollsroyce_data['rollsroyce_model'] = rollsroyce_data['clean_model'].apply(extract_rollsroyce_model)

# Create a final_model column with fallback to "ROLLS ROYCE OTHER" if needed
rollsroyce_data['final_model'] = rollsroyce_data['rollsroyce_model'].apply(
    lambda x: x if x != "ROLLS ROYCE OTHER" else "ROLLS ROYCE OTHER"
)

# Save the processed data
output_dir = '/home/bipin/Documents/kotak/car_model/clean_model'
os.makedirs(output_dir, exist_ok=True)
rollsroyce_data.to_csv(f'{output_dir}/rollsroyce_processed.csv', index=False)

# Generate model mapping data
mapping_df = pd.DataFrame({
    'clean_model': rollsroyce_data['clean_model'].tolist(),
    'extracted_model': rollsroyce_data['final_model'].tolist()
})
mapping_df.to_csv(f'{output_dir}/rollsroyce_model_mapping.csv', index=False)

# Print summary statistics
total_models = len(rollsroyce_data)
mapped_models = len(rollsroyce_data[rollsroyce_data['final_model'] != "ROLLS ROYCE OTHER"])
mapping_rate = (mapped_models / total_models) * 100

print(f"\nProcessed data saved to {output_dir}/rollsroyce_processed.csv")
print(f"Model mapping saved to {output_dir}/rollsroyce_model_mapping.csv")

print(f"\nSummary Statistics:")
print(f"Total models: {total_models}")
print(f"Successfully mapped models: {mapped_models}")
print(f"Mapping rate: {mapping_rate:.2f}%")

# Print model distribution
model_counts = Counter(rollsroyce_data['final_model'])
print("\nModel distribution:")
for model, count in model_counts.most_common():
    percentage = (count / total_models) * 100
    print(f"{model}: {count} ({percentage:.2f}%)")
