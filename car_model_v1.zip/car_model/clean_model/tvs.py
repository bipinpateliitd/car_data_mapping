#!/usr/bin/env python
# TVS Vehicle Model Processing Script

import pandas as pd
import numpy as np
import re
from collections import Counter
from rapidfuzz import fuzz, process
import os

# Load the TVS dataset
tvs_data = pd.read_csv('/home/bipin/Documents/kotak/car_model/manufacturer_data/TVS.csv')
print(f"Loaded {len(tvs_data)} records from TVS.csv")

# Function to clean model names
def clean_model(text):
    if pd.isna(text) or text is None or text == 'Not Available' or text == 'OTHER':
        return ""
        
    text = str(text).upper()
    
    # Remove manufacturer prefixes/suffixes
    text = re.sub(r'TVS\s+MOTOR\s+COMPANY\s+(?:LTD|LIMITED),?\s*', '', text)
    text = re.sub(r'TVS\s+SUZUKI\s+LIMITED,?\s*', '', text)
    text = re.sub(r'\bTVS\s+', '', text)  # Remove TVS prefix from model names
    text = re.sub(r'^[\s,]*', '', text)  # Remove leading spaces and commas
    
    # Fix model name variations
    text = re.sub(r'XL\s*(?:SUPER|HD|100\s+HD)', 'XL100', text)  # Standardize XL100/XL Super variants
    text = re.sub(r'APACHE\s+(?:RTR\s+)?(\d+)', r'APACHE RTR \1', text)  # Standardize Apache naming
    text = re.sub(r'STAR\s+CITY', 'STARCITY', text)  # Standardize Star City
    text = re.sub(r'KING.*AUTORIK(?:SHAW)?', 'KING', text)  # Standardize King autorickshaw
    text = re.sub(r'KING.*(?:LPG|4S|A/R)', 'KING', text)  # Standardize King variants
    text = re.sub(r'SCOOTY\s+', 'SCOOTY ', text)  # Ensure space after SCOOTY
    text = re.sub(r'NTORQ', 'NTORQ', text)  # Standardize NTorq spelling
    
    # Clean specifications
    text = re.sub(r'(?:BS|BSIV?|BSVI?)\s*(?:III|IV|VI?)?', '', text)  # Remove emission standards
    text = re.sub(r'\b(?:I-?TOUCH|START|DRUM|DISC|DISK|HBS|ES|MG|MAGWEEL)\b', '', text)  # Remove feature specs
    text = re.sub(r'3\s+WHL', '', text)  # Remove wheel count
    text = re.sub(r'(\d+)\s*CC', r'\1', text)  # Standardize engine displacement
    
    # Remove multiple spaces, commas, and other punctuation
    text = re.sub(r'[,.]', ' ', text)
    text = re.sub(r'\s+', ' ', text).strip()
    
    return text

# Create a clean_model column with normalized data
tvs_data['clean_model'] = tvs_data['rc_maker_model'].apply(clean_model)

# Define known TVS model keywords to search for
model_keywords = [
    'JUPITER', 'APACHE', 'SCOOTY', 'NTORQ', 'XL100', 'KING',
    'STARCITY', 'VICTOR', 'PHOENIX', 'MAX', 'RADEON', 'WEGO',
    'SPORT', 'ZEST', 'PEP', 'STREAK', 'HEAVY DUTY', 'ITOUCH'
]

# Define an alias map for common misspellings or alternative notations
alias_map = {
    'JUPITER': ['JUPITER'],
    'APACHE RTR 160': ['APACHE RTR 160', 'APACHE 160', 'APACHE RTR160'],
    'APACHE RTR 180': ['APACHE RTR 180', 'APACHE 180', 'APACHE RTR180'],
    'APACHE RTR 200': ['APACHE RTR 200', 'APACHE 200', 'APACHE RTR200'],
    'APACHE': ['APACHE'],
    'SCOOTY PEP': ['SCOOTY PEP', 'SCOOTY PEP+'],
    'SCOOTY STREAK': ['SCOOTY STREAK'],
    'SCOOTY ZEST': ['SCOOTY ZEST'],
    'SCOOTY': ['SCOOTY'],
    'NTORQ': ['NTORQ'],
    'XL100': ['XL100', 'XL SUPER', 'XL 100', 'XL HD', 'XL'],
    'KING': ['KING'],
    'STARCITY': ['STARCITY', 'STAR CITY'],
    'VICTOR': ['VICTOR'],
    'PHOENIX': ['PHOENIX'],
    'MAX': ['MAX'],
    'RADEON': ['RADEON'],
    'WEGO': ['WEGO'],
    'SPORT': ['SPORT']
}

# Function to normalize model variants by replacing with preferred terminology
def normalize(text):
    for key, aliases in alias_map.items():
        for alias in aliases:
            text = re.sub(r'\b' + re.escape(alias) + r'\b', key, text)
    return text

# Function to extract TVS model from the clean text
def extract_tvs_model(text):
    if pd.isna(text) or not text:
        return "TVS OTHER"
    
    text = normalize(text)
    
    # Check for specific models by priority (more specific first)
    
    # Apache series
    if re.search(r'APACHE\s+RTR\s+160', text):
        return "TVS APACHE RTR 160"
    if re.search(r'APACHE\s+RTR\s+180', text):
        return "TVS APACHE RTR 180"
    if re.search(r'APACHE\s+RTR\s+200', text):
        return "TVS APACHE RTR 200"
    if 'APACHE' in text:
        return "TVS APACHE"
    
    # Scooty variants
    if 'SCOOTY PEP' in text:
        return "TVS SCOOTY PEP"
    if 'SCOOTY ZEST' in text:
        return "TVS SCOOTY ZEST"
    if 'SCOOTY STREAK' in text:
        return "TVS SCOOTY STREAK"
    if 'SCOOTY' in text:
        return "TVS SCOOTY"
    
    # Jupiter
    if 'JUPITER GRANDE' in text:
        return "TVS JUPITER GRANDE"
    if 'JUPITER' in text:
        return "TVS JUPITER"
    
    # XL series
    if 'XL100 HEAVY DUTY' in text:
        return "TVS XL100 HEAVY DUTY"
    if 'XL100' in text:
        return "TVS XL100"
    
    # Other common models
    if 'NTORQ' in text:
        return "TVS NTORQ"
    
    if 'KING' in text:
        return "TVS KING"
    
    if 'STARCITY' in text:
        return "TVS STARCITY"
    
    if 'VICTOR' in text:
        return "TVS VICTOR"
    
    if 'PHOENIX' in text:
        return "TVS PHOENIX"
    
    if 'MAX' in text:
        return "TVS MAX"
    
    if 'RADEON' in text:
        return "TVS RADEON"
    
    if 'WEGO' in text:
        return "TVS WEGO"
    
    if 'SPORT' in text:
        return "TVS SPORT"
    
    # Try fuzzy matching if direct keyword matching fails
    best_match = None
    best_score = 0
    for keyword in model_keywords:
        score = fuzz.partial_ratio(text, keyword)
        if score > best_score and score > 80:  # Only accept matches with high confidence
            best_score = score
            best_match = keyword
    
    if best_match:
        return f"TVS {best_match}"
    
    # Default fallback
    return "TVS OTHER"

# Extract the model from the clean text
tvs_data['tvs_model'] = tvs_data['clean_model'].apply(extract_tvs_model)

# Create a final_model column with fallback to "TVS OTHER" if needed
tvs_data['final_model'] = tvs_data['tvs_model'].apply(
    lambda x: x if x != "TVS OTHER" else "TVS OTHER"
)

# Save the processed data
output_dir = '/home/bipin/Documents/kotak/car_model/clean_model'
os.makedirs(output_dir, exist_ok=True)
tvs_data.to_csv(f'{output_dir}/tvs_processed.csv', index=False)

# Generate model mapping data
mapping_df = pd.DataFrame({
    'clean_model': tvs_data['clean_model'].tolist(),
    'extracted_model': tvs_data['final_model'].tolist()
})
mapping_df.to_csv(f'{output_dir}/tvs_model_mapping.csv', index=False)

# Print summary statistics
total_models = len(tvs_data)
mapped_models = len(tvs_data[tvs_data['final_model'] != "TVS OTHER"])
mapping_rate = (mapped_models / total_models) * 100

print(f"\nProcessed data saved to {output_dir}/tvs_processed.csv")
print(f"Model mapping saved to {output_dir}/tvs_model_mapping.csv")

print(f"\nSummary Statistics:")
print(f"Total models: {total_models}")
print(f"Successfully mapped models: {mapped_models}")
print(f"Mapping rate: {mapping_rate:.2f}%")

# Print model distribution
model_counts = Counter(tvs_data['final_model'])
print("\nModel distribution:")
for model, count in model_counts.most_common():
    percentage = (count / total_models) * 100
    print(f"{model}: {count} ({percentage:.2f}%)")
