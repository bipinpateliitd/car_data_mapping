#!/usr/bin/env python
# Jaguar and Land Rover Vehicle Model Processing Script

import pandas as pd
import numpy as np
import re
from collections import Counter
from rapidfuzz import fuzz, process
import os

# Load the Jaguar dataset (contains both Jaguar and Land Rover vehicles)
jaguar_data = pd.read_csv('/home/bipin/Documents/kotak/car_model/manufacturer_data/JAGUAR.csv')
print(f"Loaded {len(jaguar_data)} records from JAGUAR.csv")

# Function to clean model names
def clean_model(text):
    if pd.isna(text) or text is None:
        return ""
        
    text = str(text).upper()
    
    # Remove manufacturer prefixes/suffixes
    text = re.sub(r'JAGUAR\s+(?:LAND\s+ROVER|CARS)\s+(?:INDIA\s+LIMITED|LTD)', '', text)
    text = re.sub(r'M/S\s+JAGUAR\s+LANDROVER\s+LTD', '', text)
    text = re.sub(r'(?:JAGUAR|LAND\s+ROVER)\s+(?:INDIA\s+LIMITED|LTD)', '', text)
    text = re.sub(r'^[\s,]*', '', text)  # Remove leading spaces and commas
    
    # Standardize Range Rover mentions
    text = re.sub(r'(?:LAND\s+ROVER\s+)?RANGE\s+ROVER', 'RANGE ROVER', text)
    text = re.sub(r'RANGEROVER', 'RANGE ROVER', text)
    text = re.sub(r'RR\s+(?=VELAR|EVOQUE|SPORT)', 'RANGE ROVER ', text)  # Replace RR with RANGE ROVER
    text = re.sub(r'L\s+R\s+R\s+R', 'RANGE ROVER', text)  # Fix "L R R R" notation
    
    # Standardize JAGUAR mentions
    text = re.sub(r'JAGUAR\s+', '', text)  # Remove JAGUAR prefix from model names
    
    # Clean specifications
    text = re.sub(r'(\d\.\d)L?\s+(V\d|I|DSL|DIESEL|PETROL|TD\d)', r'\1L \2', text)  # Standardize engine specs
    text = re.sub(r'\s+\d+KW', '', text)  # Remove kilowatt ratings
    text = re.sub(r'\s+\d+\s*S\s*BSVI', '', text)  # Remove emission standards
    text = re.sub(r'\s+BSVI', '', text)  # Remove emission standards
    text = re.sub(r'\d+WD', '4WD', text)  # Standardize 4WD/AWD
    text = re.sub(r'\s+\d+DO(?:OR)?', '', text)  # Remove door counts
    
    # Remove trim levels temporarily (we'll add them back in the extraction phase)
    text = re.sub(r'\s+(?:PRESTIGE|PORTFOLIO|HSE|SE|VOGUE|PURE|R-DY|BASE)', ' TRIM ', text)
    
    # Fix hyphenated model names
    text = re.sub(r'F-PACE', 'FPACE', text)
    text = re.sub(r'E-PACE', 'EPACE', text)
    text = re.sub(r'I-PACE', 'IPACE', text)
    
    # Remove multiple spaces, commas, and other punctuation
    text = re.sub(r'[,"]', ' ', text)
    text = re.sub(r'\s+', ' ', text).strip()
    
    return text

# Create a clean_model column with normalized data
jaguar_data['clean_model'] = jaguar_data['rc_maker_model'].apply(clean_model)

# Define known Jaguar and Land Rover model keywords to search for
model_keywords = [
    # Jaguar models
    'XE', 'XF', 'XJ', 'FPACE', 'EPACE', 'IPACE', 'XK', 'FTYPE',
    # Land Rover models
    'RANGE ROVER', 'EVOQUE', 'VELAR', 'SPORT', 'DISCOVERY', 'DEFENDER'
]

# Define an alias map for common misspellings or alternative notations
alias_map = {
    # Jaguar models
    'XE': ['XE'],
    'XF': ['XF'],
    'XJ': ['XJ'],
    'FPACE': ['F PACE', 'F-PACE', 'FPACE'],
    'EPACE': ['E PACE', 'E-PACE', 'EPACE'],
    'IPACE': ['I PACE', 'I-PACE', 'IPACE'],
    'FTYPE': ['F TYPE', 'F-TYPE'],
    # Land Rover models
    'RANGE ROVER': ['RANGE ROVER', 'RANGEROVER', 'RR'],
    'EVOQUE': ['EVOQUE'],
    'VELAR': ['VELAR'],
    'DISCOVERY': ['DISCOVERY'],
    'DEFENDER': ['DEFENDER'],
}

# Function to normalize model variants by replacing with preferred terminology
def normalize(text):
    for key, aliases in alias_map.items():
        for alias in aliases:
            text = re.sub(r'\b' + re.escape(alias) + r'\b', key, text)
    return text

# Function to extract Jaguar/Land Rover model from the clean text
def extract_jlr_model(text):
    if pd.isna(text) or not text:
        return "JLR OTHER"
    
    text = normalize(text)
    
    # Check if it's a Range Rover vehicle (major Land Rover brand)
    if 'RANGE ROVER' in text:
        # Range Rover variants
        if 'SPORT' in text:
            return "LAND ROVER RANGE ROVER SPORT"
        if 'VELAR' in text:
            return "LAND ROVER RANGE ROVER VELAR"
        if 'EVOQUE' in text:
            return "LAND ROVER RANGE ROVER EVOQUE"
        if 'VOGUE' in text:
            return "LAND ROVER RANGE ROVER VOGUE"
        # Default Range Rover (standard model)
        return "LAND ROVER RANGE ROVER"
    
    # Check for other Land Rover models
    if 'DISCOVERY' in text:
        if 'SPORT' in text:
            return "LAND ROVER DISCOVERY SPORT"
        return "LAND ROVER DISCOVERY"
    
    if 'DEFENDER' in text:
        return "LAND ROVER DEFENDER"
    
    # Check for Jaguar models
    if 'XE' in text:
        return "JAGUAR XE"
    
    if 'XF' in text:
        return "JAGUAR XF"
    
    if 'XJ' in text:
        return "JAGUAR XJ"
    
    if 'XK' in text:
        return "JAGUAR XK"
    
    if 'FPACE' in text:
        return "JAGUAR F-PACE"
    
    if 'EPACE' in text:
        return "JAGUAR E-PACE"
    
    if 'IPACE' in text:
        return "JAGUAR I-PACE"
    
    if 'FTYPE' in text or 'F TYPE' in text:
        return "JAGUAR F-TYPE"
    
    # Try to determine brand based on keywords if specific model not identified
    if any(keyword in text for keyword in ['RANGE', 'DISCOVERY', 'EVOQUE', 'VELAR', 'DEFENDER']):
        return "LAND ROVER OTHER"
    
    if any(keyword in text for keyword in ['XE', 'XF', 'XJ', 'PACE', 'TYPE']):
        return "JAGUAR OTHER"
    
    # Default fallback
    return "JLR OTHER"

# Extract the model from the clean text
jaguar_data['jlr_model'] = jaguar_data['clean_model'].apply(extract_jlr_model)

# Create a final_model column with fallback to "JLR OTHER" if needed
jaguar_data['final_model'] = jaguar_data['jlr_model'].apply(
    lambda x: x if x != "JLR OTHER" else "JLR OTHER"
)

# Save the processed data
output_dir = '/home/bipin/Documents/kotak/car_model/clean_model'
os.makedirs(output_dir, exist_ok=True)
jaguar_data.to_csv(f'{output_dir}/jaguar_processed.csv', index=False)

# Generate model mapping data
mapping_df = pd.DataFrame({
    'clean_model': jaguar_data['clean_model'].tolist(),
    'extracted_model': jaguar_data['final_model'].tolist()
})
mapping_df.to_csv(f'{output_dir}/jaguar_model_mapping.csv', index=False)

# Print summary statistics
total_models = len(jaguar_data)
mapped_models = len(jaguar_data[jaguar_data['final_model'] != "JLR OTHER"])
mapping_rate = (mapped_models / total_models) * 100

print(f"\nProcessed data saved to {output_dir}/jaguar_processed.csv")
print(f"Model mapping saved to {output_dir}/jaguar_model_mapping.csv")

print(f"\nSummary Statistics:")
print(f"Total models: {total_models}")
print(f"Successfully mapped models: {mapped_models}")
print(f"Mapping rate: {mapping_rate:.2f}%")

# Print model distribution
model_counts = Counter(jaguar_data['final_model'])
print("\nModel distribution:")
for model, count in model_counts.most_common():
    percentage = (count / total_models) * 100
    print(f"{model}: {count} ({percentage:.2f}%)")
